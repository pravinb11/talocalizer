#include <string>
#include <vector>
#include <Eigen/Core>
#include "open3d/Open3D.h"
#include "dataStructure.h"
#include "geometry_msgs/msg/polygon_stamped.hpp"
#include "geometry_msgs/msg/point32.h"
#include "geometry_msgs/msg/transform_stamped.hpp"

// #include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2/LinearMath/Transform.h>

namespace stair_utils
{

    void visualize_pointcloud(open3d::geometry::PointCloud &, std::string);
    std::pair<double, double> calculateGoodnessOfFit(const Plane &);
    double calculateMeanSquareError(const Plane &);
    float getSlopeZaxisDegree(Plane &);
    float getSlopeYaxisDegree(Plane &);
    float getSlopeXaxisDegree(Plane &);
    Eigen::Vector3d vector_to_eigen(std::vector<double>);
    geometry_msgs::msg::PolygonStamped plane_to_rosmsg(Plane &);
    Point3D transform_point(const Point3D &point, const geometry_msgs::msg::TransformStamped &transform_msg);
    Eigen::Vector3d transform_point(const Eigen::Vector3d &point, const geometry_msgs::msg::TransformStamped &transform_msg);
    double distancePointToLine(const Eigen::Vector3d &point,
                               const Eigen::Vector3d &linePoint,
                               const Eigen::Vector3d &lineDirection);
    double angleBetweenVectors(const Eigen::Vector3d &v1, const Eigen::Vector3d &v2);
    double pointToSegmentDistance(const Eigen::Vector3d &p, const Eigen::Vector3d &a, const Eigen::Vector3d &b, Eigen::Vector3d &projection);
    Eigen::Vector3d computeQuadNormal(const std::vector<Eigen::Vector3d> &quad);
    Eigen::Vector2d projectToPlane(const Eigen::Vector3d &pt, const Eigen::Vector3d &origin, const Eigen::Vector3d &u, const Eigen::Vector3d &v);
    bool isPointInPolygon2D(const std::vector<Eigen::Vector2d> &polygon, const Eigen::Vector2d &point);
    void extendQuadEdgeToPoint(std::vector<Eigen::Vector3d> &quad, const Eigen::Vector3d &point);
    bool isPointInPolygon2D(std::vector<Eigen::Vector3d> &quad, const Eigen::Vector3d &point);
    double point_to_line_distance(const Eigen::Vector3d &p, const Eigen::Vector3d &a, const Eigen::Vector3d &b);
    void extend_edge_3d(std::vector<Eigen::Vector3d> &boundary_points_, size_t idx1, size_t idx2, const Eigen::Vector3d &push_dir);
    tf2::Matrix3x3 getRotationFromQuaternion(geometry_msgs::msg::TransformStamped&);
}