#ifndef ROSHANDLER_H
#define ROSHANDLER_H

#include <memory>
#include <mutex>
#include <thread>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "geometry_msgs/msg/polygon_stamped.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "autonovus_msgs/srv/transition_area_detail.hpp"

#include "tf2_ros/transform_listener.h"
#include "tf2_ros/buffer.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"
#include "tf2_eigen/tf2_eigen.hpp"

#include "open3d/Open3D.h"
#include "open3d_conversions/open3d_conversions.hpp"

#include "stair.h"  // Include the new Stair class
#include "ramp.h"   // Include the new Ramp class
#include "utils.h"
#include "stopWatch.hpp"

class RosHandler : public rclcpp::Node
{
public:
    using Request = autonovus_msgs::srv::TransitionAreaDetail::Request;
    using Response = autonovus_msgs::srv::TransitionAreaDetail::Response;

    RosHandler();
    ~RosHandler() = default;

private:
    // Core Object detection
    std::unique_ptr<Stair> stair_detector_;
    std::unique_ptr<Ramp> ramp_detector_;
    
    // ROS2 interfaces
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr sub_lidar_;
    rclcpp::Service<autonovus_msgs::srv::TransitionAreaDetail>::SharedPtr serv_stair_;
    rclcpp::Service<autonovus_msgs::srv::TransitionAreaDetail>::SharedPtr serv_ramp_;
    
    // Debug publishers 
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pub_segmt_;
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pub_clust_;
    rclcpp::Publisher<geometry_msgs::msg::PolygonStamped>::SharedPtr pub_plane_;
    
    // TF2 for coordinate transformations
    std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    
    // Callback groups for multithreading
    rclcpp::CallbackGroup::SharedPtr service_cb_group_;
    rclcpp::CallbackGroup::SharedPtr subscriber_cb_group_;
    
    // Timing and state
    std::unique_ptr<StopWatch<std::chrono::seconds>> stop_watch_ptr_;
    bool start_estimation_stair_;
    bool start_estimation_ramp_;
    bool debug_mode_;
    std::string input_topic_;
    std::string lidar_frame_;
    std::string target_frame_;
    
    // Thread safety for results
    std::mutex result_mutex_;
    StairResult last_valid_stair_result_;
    RampResult last_valid_ramp_result_;

    // Initialization and configuration
    void initializeStairDetector();
    void initializeRampDetector();

    // Callback methods
    void service_stair_callback(const std::shared_ptr<Request> request, 
                         std::shared_ptr<Response> response);
    void service_ramp_callback(const std::shared_ptr<Request> request, 
                         std::shared_ptr<Response> response);
    void lidar_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg);
    
    // Helper methods
    bool populateServiceResponse(std::shared_ptr<Response> response);
    void publishDebugInfo(const StairResult& result, const std::string& frame_id);
    void publishDebugInfo(const RampResult& result, const std::string& frame_id);
    
    // Transform helper methods
    bool transformPlaneInfoToOdom(PlaneInfo& plane_info, const std::string& source_frame);
    Eigen::Vector3d transformPoint(const Eigen::Vector3d& point, const geometry_msgs::msg::TransformStamped& transform);
    Eigen::Vector3d transformVector(const Eigen::Vector3d& vector, const geometry_msgs::msg::TransformStamped& transform);
    Eigen::Vector4d transformPlaneEquation(const Eigen::Vector4d& plane_eq, const geometry_msgs::msg::TransformStamped& transform);
};

#endif // ROSHANDLER_H