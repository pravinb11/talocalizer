#pragma once
#include "dataStructure.h"
#include "open3d/Open3D.h"
#include "utils.h"
#include <iostream>

class PlanEstimation{

public:

PlanEstimation();
PlanEstimation(plane_est_param&);

std::vector<Plane> DetectMultiPlanes(const open3d::geometry::PointCloud &pcd);
std::pair<open3d::geometry::PointCloud, std::pair<Eigen::Vector3d, std::vector<Eigen::Vector3d>>> RemoveGivenPointSet(const open3d::geometry::PointCloud &pcd, std::vector<size_t> index_set);
std::tuple<Eigen::Vector4d, std::vector<size_t>> PlaneRegression(open3d::geometry::PointCloud &pcd, float threshold, int init_n, int iter);
Plane estimateSlopeParam();
PlaneInfo getAggregatedPlaneInfo(Plane&, double offset);
bool ifStair(float,std::pair<double,double>&);
bool ifRamp(float,std::pair<double,double>&);
void calSlopeCandidatesPcd(std::vector<Plane>& candidates);
open3d::geometry::PointCloud slope_point_candidates;

private:

plane_est_param plnest_param_;


};