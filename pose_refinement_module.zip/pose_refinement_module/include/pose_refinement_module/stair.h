#ifndef STAIR_H
#define STAIR_H

#include <memory>
#include <vector>
#include <iostream>
#include <thread>
#include <mutex>

#include "open3d/Open3D.h"
#include "open3d_conversions/open3d_conversions.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <geometry_msgs/msg/polygon_stamped.hpp>
#include <autonovus_msgs/srv/transition_area_detail.hpp>

#include "planeEstimation.h"
#include "clustering.h"
#include "utils.h"

using namespace std::placeholders;

enum class StairState {
    Unknown,
    Estimating,
    Confident,
    UnderConfident
};

struct StairResult {
    bool is_valid;
    StairState state;
    PlaneInfo plane_info;
    open3d::geometry::PointCloud segmented_pcd;
    open3d::geometry::PointCloud clustered_pcd;
    geometry_msgs::msg::PolygonStamped plane_msg;
    
    StairResult() : is_valid(false), state(StairState::Unknown) {}
};

class Stair {
public:
    // ructor with default parameters
    Stair();
    
    // ructor with custom parameters
    Stair( plane_est_param& plane_params, 
           preprocess_param& preprocess_params, 
           cluster_param& cluster_params);
    
    // Destructor
    ~Stair() = default;
    
    // Main processing function
    StairResult processPointCloud( open3d::geometry::PointCloud& input_pcd);
    
    // Reset internal state
    void reset();
    
    // Configuration methods
    void setDebugMode(bool debug) { debug_mode_ = debug; }
    void setSloperToleranceDegrees(double tolerance) { slope_tolerance_ = tolerance; }
    void setAlignmentToleranceDegrees(double tolerance) { alignment_tolerance_ = tolerance; }
    void setMinCandidatesBeforeEstimation(int min_candidates) { min_candidates_for_estimation_ = min_candidates; }
    void setStartOffset(double offset) { start_offset_ = offset; }

    // State management
    StairState getCurrentState() ;
    bool isConfident()  { return getCurrentState() == StairState::Confident; }
    
    // Getters for debug information
     std::vector<Plane>& getSlopeCandidates()  { return slope_plane_candidates_; }
     open3d::geometry::PointCloud& getSlopePointCandidates()  { return slope_point_candidates_; }
    int getCandidateCount()  { return slope_plane_candidates_.size(); }
    
private:
    // Core algorithm components
    std::unique_ptr<PlanEstimation> plane_estimator_;
    std::unique_ptr<Clustering> clustering_;
    
    // Algorithm state
    std::vector<Plane> slope_plane_candidates_;
    open3d::geometry::PointCloud slope_point_candidates_;
    PlaneInfo current_plane_info_;
    StairState current_state_;
    
    // Configuration parameters
    bool debug_mode_;
    double slope_tolerance_;        // Tolerance for slope alignment in degrees
    double alignment_tolerance_;    // Tolerance for plane alignment in degrees
    int min_candidates_for_estimation_;  // Minimum candidates before estimation
    double start_offset_; // Start offset for stair detection

    // Thread safety
    mutable std::mutex state_mutex_;
    
    // Helper methods
    bool isValidStairPlane( Plane& plane,  std::pair<double, double>& fitness);
    bool isPlaneAligned( Eigen::Vector3d& normal_line, double tolerance) ;
    void aggregateSlopeCandidates(std::vector<Plane>& candidates);
    Plane estimateFinalStairPlane();
    PlaneInfo calculatePlaneInfo( Plane& plane);
    bool validateFinalPlane( PlaneInfo& plane_info,  Eigen::Vector3d& seed_line_vector);
    void setState(StairState new_state);
    
    // Debug helpers
    void debugPrint( std::string message) ;
    void debugPrintPlaneDetails( Plane& plane,  std::pair<double, double>& fitness) ;
    void debugPrintFinalResults( PlaneInfo& plane_info, double slope_val, 
                                std::pair<double, double>& fitness) ;
};

#endif // STAIR_H