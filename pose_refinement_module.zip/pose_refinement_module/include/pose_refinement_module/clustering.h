#pragma once
#include "open3d/Open3D.h"
#include "dataStructure.h"
#include "utils.h"
#include <Eigen/Dense>

class Clustering{

public:

Clustering();
Clustering(preprocess_param&, cluster_param&);
void preProcessPcd(open3d::geometry::PointCloud &pcd);
void dbscanCluster(open3d::geometry::PointCloud &pcd);
void getSlopePcdFromCluster(open3d::geometry::PointCloud& pcd);
void findSeedLines();
std::pair<int,double> getBestSeedLine();
void getLineInformation(open3d::geometry::PointCloud& pcd, std::shared_ptr<std::vector<std::vector<size_t>>> clust_idx);
std::vector<Line> slope_line_candidates_;
std::vector<std::pair<Eigen::Vector3d,int>> seed_line_candidates_;
Eigen::Vector3d getThetaEstimate();

private:
preprocess_param pproc_param_;
cluster_param clust_param_;

};