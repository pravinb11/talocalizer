#pragma once
#include <Eigen/Core>
#include <vector>
#include "open3d/Open3D.h"

enum State
{
    NoPlanes = 0,
    Confident = 1,
    Estimating = 2,
    UnderConfident = 3,
    Unknown = 4
};

struct preprocess_param
{
    bool enable_preprocessing;
    Eigen::Vector3d crop_min_bound;
    Eigen::Vector3d crop_max_bound;
    int outlier_nb_neighbours;
    float outlier_std_ratio;
    float voxel_dim;
};

struct cluster_param
{
    double eps; // Maximum distance between points in a cluster
	size_t min_points; //Minimum number of points to inside a cluster
};

struct plane_est_param
{
    float detect_min_ratio;
	int detect_max_cnt;
    float detect_dist_threshold;
    int ransac_nb_sample;
    int ransac_max_iter;

};

struct Plane
{
    int id;
    Eigen::Vector3d center;                   // Center of the plane
    Eigen::Vector4d equation;                 // Equation of the plane (ax + by + cz + d = 0)
    std::vector<Eigen::Vector3d> point_coord; // Coordinates of points in the plane
    Eigen::Vector3d extent;                   // extent of the planes in OBB
    std::vector<Eigen::Vector3d> bbox_points; // OBB points in lidar frame
    Eigen::Vector3d normal;                   // Plane normal in lidar frame
};

struct Line
{
    int id;
    Eigen::Vector3d center;                   // Center of the Line
    Eigen::Vector3d eigen_vector;             // Vector along 1st principal axis (x = x0 + r(t)) for t = ai + bj + ck
    Eigen::Vector3d extent;                   // extent of the planes in Line (max-min)
    open3d::geometry::PointCloud line_pcd;    // The pointcloud belonging to the line
    bool onSlope;
};

struct Point3D {
    double x, y, z;
};


struct PlaneInfo
{
    Eigen::Vector3d orientationXYZ;
    Eigen::Vector3d midpointXYZ;
    Eigen::Vector4d equation;  
    float theta;
    std::pair<Eigen::Vector3d,Eigen::Vector3d> edge_vectors;
    std::vector<Eigen::Vector3d> boundary;
    Eigen::Vector3d direction_vec;
    float plane_width;
};