#ifndef RAMP_H
#define RAMP_H

#include <memory>
#include <vector>
#include <iostream>
#include <thread>
#include <mutex>

#include "open3d/Open3D.h"
#include "open3d_conversions/open3d_conversions.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <geometry_msgs/msg/polygon_stamped.hpp>
#include <autonovus_msgs/srv/transition_area_detail.hpp>

#include "planeEstimation.h"
#include "clustering.h"
#include "utils.h"

using namespace std::placeholders;

enum class RampState {
    Unknown,
    Estimating,
    Confident,
    UnderConfident
};

struct RampResult {
    bool is_valid;
    RampState state;
    PlaneInfo plane_info;
    open3d::geometry::PointCloud segmented_pcd;
    open3d::geometry::PointCloud clustered_pcd;
    geometry_msgs::msg::PolygonStamped plane_msg;
    
    RampResult() : is_valid(false), state(RampState::Unknown) {}
};

class Ramp {
public:
    // ructor with default parameters
    Ramp();
    
    // ructor with custom parameters
    Ramp( plane_est_param& plane_params, 
           preprocess_param& preprocess_params, 
           cluster_param& cluster_params);
    
    // Destructor
    ~Ramp() = default;
    
    // Main processing function
    RampResult processPointCloud( open3d::geometry::PointCloud& input_pcd);
    
    // Reset internal state
    void reset();
    
    // Configuration methods
    void setDebugMode(bool debug) { debug_mode_ = debug; }
    void setSloperToleranceDegrees(double tolerance) { slope_tolerance_ = tolerance; }
    void setAlignmentToleranceDegrees(double tolerance) { alignment_tolerance_ = tolerance; }
    void setMinCandidatesBeforeEstimation(int min_candidates) { min_candidates_for_estimation_ = min_candidates; }
    void setStartOffset(double offset) { start_offset_ = offset; }

    // State management
    RampState getCurrentState() ;
    bool isConfident()  { return getCurrentState() == RampState::Confident; }
    
    // Getters for debug information
     std::vector<Plane>& getSlopeCandidates()  { return slope_plane_candidates_; }
     open3d::geometry::PointCloud& getSlopePointCandidates()  { return slope_point_candidates_; }
    int getCandidateCount()  { return slope_plane_candidates_.size(); }
    
private:
    // Core algorithm components
    std::unique_ptr<PlanEstimation> plane_estimator_;
    std::unique_ptr<Clustering> clustering_;
    
    // Algorithm state
    std::vector<Plane> slope_plane_candidates_;
    open3d::geometry::PointCloud slope_point_candidates_;
    PlaneInfo current_plane_info_;
    RampState current_state_;
    
    // Configuration parameters
    bool debug_mode_;
    double slope_tolerance_;        // Tolerance for slope alignment in degrees
    double alignment_tolerance_;    // Tolerance for plane alignment in degrees
    int min_candidates_for_estimation_;  // Minimum candidates before estimation
    double start_offset_; // Start offset for ramp detection

    // Thread safety
    mutable std::mutex state_mutex_;
    
    // Helper methods
    bool isValidRampPlane( Plane& plane,  std::pair<double, double>& fitness);
    bool isPlaneAligned( Eigen::Vector3d& normal_line, double tolerance) ;
    void aggregateSlopeCandidates(std::vector<Plane>& candidates);
    Plane estimateFinalRampPlane();
    PlaneInfo calculatePlaneInfo( Plane& plane);
    bool validateFinalPlane( PlaneInfo& plane_info,  Eigen::Vector3d& seed_line_vector);
    void setState(RampState new_state);
    
    // Debug helpers
    void debugPrint( std::string message) ;
    void debugPrintPlaneDetails( Plane& plane,  std::pair<double, double>& fitness) ;
    void debugPrintFinalResults( PlaneInfo& plane_info, double slope_val, 
                                std::pair<double, double>& fitness) ;
};

#endif // RAMP_H