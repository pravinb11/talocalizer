#include "planeEstimation.h"

/* TO DO

1. Put the code estimateSlopeParam using the param estimation class
2. add the mid point detection in the param estimation class
3. Add stair detection and other hardcode as params
4. Change the theta to tan something (mid point detected - (0,0,0))
5. Plane intersection code have to add
6. remove unecessary things from ros handler service call


*/
PlanEstimation::PlanEstimation()
{
    plnest_param_.detect_min_ratio = 0.05;
    plnest_param_.detect_max_cnt = 15;
    plnest_param_.detect_dist_threshold = 0.005;
    plnest_param_.ransac_nb_sample = 6;
    plnest_param_.ransac_max_iter = 200;
}

PlanEstimation::PlanEstimation(plane_est_param &plnest_param)
{
    plnest_param_ = plnest_param;
}

std::tuple<Eigen::Vector4d, std::vector<size_t>> PlanEstimation::PlaneRegression(open3d::geometry::PointCloud &pcd, float threshold, int init_n, int iter)
{
    return pcd.SegmentPlane(threshold, init_n, iter);
}

bool PlanEstimation::ifStair(float slope_val, std::pair<double, double> &fitness_pair)
{
    return (slope_val > 10.0 && slope_val < 35 && abs(fitness_pair.second) > 0.95 && abs(fitness_pair.second) < 1.0); //TO DO: add area constrain 
}

bool PlanEstimation::ifRamp(float slope_val, std::pair<double, double> &fitness_pair)
{
    return (slope_val > 5.0 && slope_val < 25.0 && abs(fitness_pair.second) > 0.95 && abs(fitness_pair.second) < 1.0); //TO DO: add area constrain
}

std::vector<Plane> PlanEstimation::DetectMultiPlanes(const open3d::geometry::PointCloud &pcd)
{
    std::vector<Plane> plane_list;
    int size = (int)pcd.points_.size();
    auto target = pcd;
    int count = 0;
    int plane_count = 0;
    open3d::geometry::PointCloud pcd_seg;

    // visualize_pointcloud(pcd,"Original");
    int cnt = 0;
    double max_tol_angle = 40.0; // sin(plane_params_.max_align_tol * (3.14 / 180.0));
    double min_tol_angle = 3.0;  // sin(5.0 * (3.14 / 180.0));

    while (count < (1 - plnest_param_.detect_min_ratio) * size && plane_count < plnest_param_.detect_max_cnt)
    {
        std::tuple<Eigen::Vector4d, std::vector<size_t>> plane = PlaneRegression(target, plnest_param_.detect_dist_threshold, plnest_param_.ransac_nb_sample, plnest_param_.ransac_max_iter);

        pcd_seg = *target.SelectByIndex(std::get<1>(plane));
        auto bbox = pcd_seg.GetOrientedBoundingBox();
        // visualize_pointcloud(pcd_seg,"Segment"+ std::to_string(cnt));

        Plane planeObj;
        Eigen::Vector4d plane_eq = std::get<0>(plane);
        std::vector<size_t> index = std::get<1>(plane);

        count += (int)index.size();
        plane_count++;
        auto res = RemoveGivenPointSet(target, index);

        Eigen::Vector3d plane_normal;
        plane_normal.x() = plane_eq.x();
        plane_normal.y() = plane_eq.y();
        plane_normal.z() = plane_eq.z();
        plane_normal.normalize();

        double plane_angle_with_x = plane_normal.x();
        double plane_angle_with_y = plane_normal.y();
        // std::cout<<"angle with x:"<< abs(plane_angle_with_x*(180/3.14)) <<"\n";
        // std::cout<<"max_tol_angle: "<<max_tol_angle<<"min_tol_angle: "<<min_tol_angle<<"\n";
        // std::cout<<"cond1:"<< (abs(plane_angle_with_x*(180/3.14)) < max_tol_angle) << "cond2: "<< (abs(plane_angle_with_x*(180/3.14)) > min_tol_angle) << "\n";
        if (abs(plane_angle_with_x * (180 / 3.14)) < max_tol_angle || abs(plane_angle_with_y * (180 / 3.14)) < max_tol_angle)
        {
            target = res.first;
            planeObj.id = cnt;
            planeObj.center = res.second.first;
            planeObj.point_coord = res.second.second;
            planeObj.equation = plane_eq;
            planeObj.bbox_points = bbox.GetBoxPoints();
            planeObj.extent = bbox.extent_;
            planeObj.normal = plane_normal;
            plane_list.push_back(planeObj);
        }
        cnt++;
    }

    return plane_list;
}

std::pair<open3d::geometry::PointCloud, std::pair<Eigen::Vector3d, std::vector<Eigen::Vector3d>>> PlanEstimation::RemoveGivenPointSet(const open3d::geometry::PointCloud &pcd, std::vector<size_t> index_set)
{
    std::vector<Eigen::Vector3d> tmp_points;
    tmp_points.reserve(pcd.points_.size() - index_set.size());
    std::vector<Eigen::Vector3d> tmp_normals;
    tmp_normals.reserve(pcd.points_.size() - index_set.size());
    std::vector<Eigen::Vector3d> tmp_colors;
    tmp_colors.reserve(pcd.points_.size() - index_set.size());
    std::vector<Eigen::Matrix3d> tmp_covariances;
    tmp_covariances.reserve(pcd.points_.size() - index_set.size());
    open3d::geometry::PointCloud out;

    std::vector<Eigen::Vector3d> plane_coord;
    if (index_set.size() == 0)
    {
        std::cout << "Set shouldn't be empty!" << std::endl;
        return std::make_pair(pcd, std::make_pair(Eigen::Vector3d::Identity(), std::vector<Eigen::Vector3d>()));
    }

    double avg_x = 0, avg_y = 0, avg_z = 0;

    for (size_t i = 0; i < pcd.points_.size(); i++)
    {
        if (std::find(index_set.begin(), index_set.end(), i) == index_set.end())
        {
            tmp_points.push_back(pcd.points_[i]);
            if (pcd.HasNormals())
                tmp_normals.push_back(pcd.normals_[i]);
            if (pcd.HasColors())
                tmp_colors.push_back(pcd.colors_[i]);
            if (pcd.HasCovariances())
                tmp_covariances.push_back(pcd.covariances_[i]);
        }
        else
        {
            plane_coord.push_back(pcd.points_[i]);
            avg_x += pcd.points_[i].x();
            avg_y += pcd.points_[i].y();
            avg_z += pcd.points_[i].z();
        }
    }

    out.points_ = tmp_points;
    out.normals_ = tmp_normals;
    out.colors_ = tmp_colors;
    out.covariances_ = tmp_covariances;

    return std::make_pair(out, std::make_pair(Eigen::Vector3d(avg_x / index_set.size(), avg_y / index_set.size(), avg_z / index_set.size()), plane_coord));
}

void ConvertToPointCloud(const std::vector<Eigen::Vector3d> &points, open3d::geometry::PointCloud &pcd)
{
    // Resize the PointCloud to the number of points
    pcd.points_.resize(points.size());

    // Copy points from std::vector<Eigen::Vector3d> to open3d::geometry::PointCloud
    for (size_t i = 0; i < points.size(); ++i)
    {
        pcd.points_[i] = points[i];
    }
}

void PlanEstimation::calSlopeCandidatesPcd(std::vector<Plane>& candidates)
{
    std::vector<Eigen::Vector3d> points;
    int cnt = 0;
    for (Plane pl : candidates)
    {
        points.insert(points.end(), pl.point_coord.begin(), pl.point_coord.end());
        cnt++;
    }

    // std::cout << "itr" << cnt << " size of aggregate points: " << points.size() << "\n";
    
    ConvertToPointCloud(points, slope_point_candidates);
    slope_point_candidates.RemoveStatisticalOutliers(20,0.5);

}

Plane PlanEstimation::estimateSlopeParam()
{
    open3d::geometry::PointCloud pcd_seg;

    std::cout<<"size of pointcloud:"<<slope_point_candidates.points_.size()<<" \n";
    std::tuple<Eigen::Vector4d, std::vector<size_t>> plane = PlaneRegression(slope_point_candidates, plnest_param_.detect_dist_threshold + 0.05, plnest_param_.ransac_nb_sample, plnest_param_.ransac_max_iter);
    // Add goodness of fit, and publish the final pcd once.

    pcd_seg = *slope_point_candidates.SelectByIndex(std::get<1>(plane));
    // pcd_seg = *std::get<0>(pcd_seg.RemoveStatisticalOutliers(50, 1));
    auto bbox = pcd_seg.GetMinimalOrientedBoundingBox();
    // auto bbox = pcd_seg.GetOrientedBoundingBox();

    // visualize_pointcloud(pcd_seg,"Segment"+ std::to_string(cnt));

    Plane planeObj;
    Eigen::Vector4d plane_eq = std::get<0>(plane);
    std::vector<size_t> index = std::get<1>(plane);

    auto res = RemoveGivenPointSet(slope_point_candidates, index);

    Eigen::Vector3d plane_normal;
    plane_normal.x() = plane_eq.x();
    plane_normal.y() = plane_eq.y();
    plane_normal.z() = plane_eq.z();
    plane_normal.normalize();

    planeObj.center = res.second.first;
    planeObj.point_coord = res.second.second;
    planeObj.equation = plane_eq;
    planeObj.bbox_points = bbox.GetBoxPoints();
    planeObj.extent = bbox.extent_;
    planeObj.normal = plane_normal;

    return planeObj;
}

    /// Returns the eight points that define the bounding box.
    /// 
    ///      ------- x
    ///     /|
    ///    / |
    ///   /  | z
    ///  y
    ///      0 ------------------- 1
    ///       /|                /|
    ///      / |               / |
    ///     /  |              /  |
    ///    /   |             /   |
    /// 2 ------------------- 7  |
    ///   |    |____________|____| 6
    ///   |   /3            |   /
    ///   |  /              |  /
    ///   | /               | /
    ///   |/                |/
    /// 5 ------------------- 4
    /// 

PlaneInfo PlanEstimation::getAggregatedPlaneInfo(Plane& plane, double offset=0.0)
{
    PlaneInfo out;
    Eigen::Vector3d mid_point1 = {(plane.bbox_points[0].x() + plane.bbox_points[1].x()) / 2, (plane.bbox_points[0].y() + plane.bbox_points[1].y()) / 2, (plane.bbox_points[0].z() + plane.bbox_points[1].z()) / 2};
    Eigen::Vector3d mid_point2 = {(plane.bbox_points[2].x() + plane.bbox_points[7].x()) / 2, (plane.bbox_points[2].y() + plane.bbox_points[7].y()) / 2, (plane.bbox_points[2].z() + plane.bbox_points[7].z()) / 2};
    float pi2degree = 180/3.14;

    if (mid_point1.x() < mid_point2.x())
    {
        out.midpointXYZ = mid_point1;
        out.plane_width = sqrt(pow((plane.bbox_points[0].x() - plane.bbox_points[1].x()),2) + pow((plane.bbox_points[0].y() - plane.bbox_points[1].y()),2) + pow((plane.bbox_points[0].z() - plane.bbox_points[1].z()),2));
        out.theta = atan((mid_point2.y()- mid_point1.y())/(mid_point2.x()- mid_point1.x()))* pi2degree;
        out.edge_vectors.first = plane.bbox_points[0] - plane.bbox_points[1];
        out.edge_vectors.second = plane.bbox_points[2] - plane.bbox_points[0];

         if(offset != 0.0)
        {
            Eigen::Vector3d direction = mid_point1 - mid_point2;
            Eigen::Vector3d unit_direction = direction.normalized();
            out.midpointXYZ += unit_direction * offset;
        }
    }
    else
    {
        out.midpointXYZ  = mid_point2;
        out.plane_width = sqrt(pow((plane.bbox_points[0].x() - plane.bbox_points[1].x()),2) + pow((plane.bbox_points[0].y() - plane.bbox_points[1].y()),2) + pow((plane.bbox_points[0].z() - plane.bbox_points[1].z()),2));
        out.theta = atan((mid_point1.y()- mid_point2.y())/(mid_point1.x()- mid_point2.x()))* pi2degree;
        out.edge_vectors.first = plane.bbox_points[0] - plane.bbox_points[1];
        out.edge_vectors.second = plane.bbox_points[0] - plane.bbox_points[2];

        if(offset != 0.0)
        {
            Eigen::Vector3d direction = mid_point2 - mid_point1;
            Eigen::Vector3d unit_direction = direction.normalized();
            out.midpointXYZ += unit_direction * offset;
        }
    }

    out.boundary.push_back(Eigen::Vector3d((plane.bbox_points[2].x() + plane.bbox_points[5].x()) / 2, (plane.bbox_points[2].y() + plane.bbox_points[5].y()) / 2, (plane.bbox_points[2].z() + plane.bbox_points[5].z())));
    out.boundary.push_back(Eigen::Vector3d((plane.bbox_points[7].x() + plane.bbox_points[4].x()) / 2, (plane.bbox_points[7].y() + plane.bbox_points[4].y()) / 2, (plane.bbox_points[7].z() + plane.bbox_points[4].z())));
    out.boundary.push_back(Eigen::Vector3d((plane.bbox_points[1].x() + plane.bbox_points[6].x()) / 2, (plane.bbox_points[1].y() + plane.bbox_points[6].y()) / 2, (plane.bbox_points[1].z() + plane.bbox_points[6].z())));
    out.boundary.push_back(Eigen::Vector3d((plane.bbox_points[0].x() + plane.bbox_points[3].x()) / 2, (plane.bbox_points[0].y() + plane.bbox_points[3].y()) / 2, (plane.bbox_points[0].z() + plane.bbox_points[3].z())));

    
    out.orientationXYZ.x() = stair_utils::getSlopeXaxisDegree(plane);
    out.orientationXYZ.y() = stair_utils::getSlopeYaxisDegree(plane);
    out.orientationXYZ.z() = stair_utils::getSlopeZaxisDegree(plane);

    out.equation = plane.equation;
    return out;

}