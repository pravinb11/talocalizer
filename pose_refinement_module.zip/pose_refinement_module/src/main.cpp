#include "rosHandler.h"
#include <signal.h>

// Signal handler for graceful shutdown
void signalHandler(int signum) {
    RCLCPP_INFO(rclcpp::get_logger("main"), "Interrupt signal (%d) received. Shutting down...", signum);
    rclcpp::shutdown();
}

int main(int argc, char *argv[])
{
    try {
        // Initialize ROS2
        rclcpp::init(argc, argv);
        
        // Set up signal handling for graceful shutdown
        signal(SIGINT, signalHandler);
        signal(SIGTERM, signalHandler);
        
        // Create multi-threaded executor for handling service and subscription callbacks
        rclcpp::executors::MultiThreadedExecutor executor;
        
        // Create and add the stair detector node
        auto stair_node = std::make_shared<RosHandler>();
        executor.add_node(stair_node);
        
        RCLCPP_INFO(rclcpp::get_logger("main"), "Starting Pose Refinement node...");
        
        // Spin the executor
        executor.spin();
        
    } catch (const std::exception& e) {
        RCLCPP_ERROR(rclcpp::get_logger("main"), "Exception in main: %s", e.what());
        return 1;
    }
    
    // Clean shutdown
    RCLCPP_INFO(rclcpp::get_logger("main"), "Stair detection node shutdown complete");
    rclcpp::shutdown();
    return 0;
}