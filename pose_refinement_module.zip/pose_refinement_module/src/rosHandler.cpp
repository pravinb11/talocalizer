#include "rosHandler.h"
#include "stair.h" // Include the new Stair class
#include "ramp.h"  // Include the new Ramp class

RosHandler::RosHandler()
    : Node("pose_refinement")
{
    input_topic_ = "/velodyne_points";
    debug_mode_ = true;
    start_estimation_stair_ = false;
    start_estimation_ramp_ = false;
    lidar_frame_ = "laser_link";  // Default lidar frame
    target_frame_ = "odom";       // Target frame for transformation
    
    service_cb_group_ = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    subscriber_cb_group_ = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    stop_watch_ptr_ = std::make_unique<StopWatch<std::chrono::seconds>>();

    // Initialize TF2
    tf_buffer_ = std::make_unique<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

    // Initialize the Stair detector
    initializeStairDetector();

    // Initialize the Ramp detector
    initializeRampDetector();

    rclcpp::SubscriptionOptions subscription_options = rclcpp::SubscriptionOptions();
    subscription_options.callback_group = subscriber_cb_group_;
    sub_lidar_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
        input_topic_, 10, std::bind(&RosHandler::lidar_callback, this, _1), subscription_options);

    serv_stair_ = this->create_service<autonovus_msgs::srv::TransitionAreaDetail>(
        "get_stair_details",
        std::bind(&RosHandler::service_stair_callback, this, _1, _2),
        rclcpp::ServicesQoS().get_rmw_qos_profile(),
        service_cb_group_);

    serv_ramp_ = this->create_service<autonovus_msgs::srv::TransitionAreaDetail>(
        "get_ramp_details",
        std::bind(&RosHandler::service_ramp_callback, this, _1, _2),
        rclcpp::ServicesQoS().get_rmw_qos_profile(),
        service_cb_group_);

    if (debug_mode_)
    {
        pub_segmt_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("segment_pcd", 1);
        pub_clust_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("cluster_pcd", 1);
        pub_plane_ = this->create_publisher<geometry_msgs::msg::PolygonStamped>("segment_plane", 1);
    }

    RCLCPP_INFO(this->get_logger(), "ROShandler initialized with TF2 support");
}

void RosHandler::initializeStairDetector()
{
    // Configure plane estimation parameters
    plane_est_param plane_params;
    plane_params.detect_min_ratio = 0.05;
    plane_params.detect_max_cnt = 15;
    plane_params.detect_dist_threshold = 0.005;
    plane_params.ransac_nb_sample = 6;
    plane_params.ransac_max_iter = 200;

    // Configure preprocessing parameters
    preprocess_param preprocess_params;
    preprocess_params.crop_min_bound = {0.0, -3.5, -0.5};
    preprocess_params.crop_max_bound = {10.0, 3.5, 10.0};
    preprocess_params.outlier_nb_neighbours = 50;
    preprocess_params.outlier_std_ratio = 1;
    preprocess_params.voxel_dim = 0.04;

    // Configure clustering parameters
    cluster_param cluster_params;
    cluster_params.eps = 0.05;
    cluster_params.min_points = 10;

    // Create stair detector with parameters
    stair_detector_ = std::make_unique<Stair>(plane_params, preprocess_params, cluster_params);

    // Configure stair detector settings
    stair_detector_->setDebugMode(debug_mode_);
    stair_detector_->setSloperToleranceDegrees(15.0);
    stair_detector_->setAlignmentToleranceDegrees(15.0);
    stair_detector_->setMinCandidatesBeforeEstimation(10);
    stair_detector_->setStartOffset(2.5);
}

void RosHandler::initializeRampDetector()
{
    // Configure plane estimation parameters
    plane_est_param plane_params;
    plane_params.detect_min_ratio = 0.05;
    plane_params.detect_max_cnt = 15;
    plane_params.detect_dist_threshold = 0.005;
    plane_params.ransac_nb_sample = 6;
    plane_params.ransac_max_iter = 200;

    // Configure preprocessing parameters
    preprocess_param preprocess_params;
    preprocess_params.crop_min_bound = {0.0, -3.5, -0.5};
    preprocess_params.crop_max_bound = {10.0, 3.5, 10.0};
    preprocess_params.outlier_nb_neighbours = 50;
    preprocess_params.outlier_std_ratio = 1;
    preprocess_params.voxel_dim = 0.04;

    // Configure clustering parameters
    cluster_param cluster_params;
    cluster_params.eps = 0.05;
    cluster_params.min_points = 10;

    // Create ramp detector with parameters
    ramp_detector_ = std::make_unique<Ramp>(plane_params, preprocess_params, cluster_params);

    // Configure ramp detector settings
    ramp_detector_->setDebugMode(debug_mode_);
    ramp_detector_->setSloperToleranceDegrees(50.0);
    ramp_detector_->setAlignmentToleranceDegrees(50.0);
    ramp_detector_->setMinCandidatesBeforeEstimation(10);
    ramp_detector_->setStartOffset(2.5);
}

void RosHandler::service_ramp_callback(const std::shared_ptr<Request> request, std::shared_ptr<Response> response)
{
    float max_time = request->search_time;
    start_estimation_ramp_ = true;

    // Reset ramp detector state
    ramp_detector_->reset();

    stop_watch_ptr_->tic("service_time");
    RCLCPP_INFO(this->get_logger(), "Starting ramp detection service with max search time: %f", max_time);

    float time_elapsed = 0;
    RampState current_state = RampState::Unknown;

    while (time_elapsed < max_time || max_time == -1.0)
    {
        time_elapsed = stop_watch_ptr_->toc("service_time");
        current_state = ramp_detector_->getCurrentState();

        if (current_state == RampState::Confident)
        {
            // Get the latest ramp detection results
            if (populateServiceResponse(response))
            {
                RCLCPP_INFO(this->get_logger(), "Ramp detection successful");
                break;
            }
        }

        // Small sleep to prevent busy waiting
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    if (current_state == RampState::Unknown)
    {
        response->state = "No Plane Found";
        RCLCPP_INFO(this->get_logger(), "Ramp detection unsuccessful - no plane found");
    }

    start_estimation_ramp_ = false;
    RCLCPP_INFO(this->get_logger(), "Ramp detection service completed");
}

void RosHandler::service_stair_callback(const std::shared_ptr<Request> request, std::shared_ptr<Response> response)
{
    float max_time = request->search_time;
    start_estimation_stair_ = true;

    // Reset stair detector state
    stair_detector_->reset();

    stop_watch_ptr_->tic("service_time");
    RCLCPP_INFO(this->get_logger(), "Starting stair detection service with max search time: %f", max_time);

    float time_elapsed = 0;
    StairState current_state = StairState::Unknown;

    while (time_elapsed < max_time || max_time == -1.0)
    {
        time_elapsed = stop_watch_ptr_->toc("service_time");
        current_state = stair_detector_->getCurrentState();

        if (current_state == StairState::Confident)
        {
            // Get the latest stair detection results
            if (populateServiceResponse(response))
            {
                RCLCPP_INFO(this->get_logger(), "Stair detection successful");
                break;
            }
        }

        // Small sleep to prevent busy waiting
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    if (current_state == StairState::Unknown)
    {
        response->state = "No Plane Found";
        RCLCPP_INFO(this->get_logger(), "Stair detection unsuccessful - no plane found");
    }

    start_estimation_stair_ = false;
    RCLCPP_INFO(this->get_logger(), "Stair detection service completed");
}

bool RosHandler::populateServiceResponse(std::shared_ptr<Response> response)
{
    std::lock_guard<std::mutex> lock(result_mutex_);

    if(!last_valid_stair_result_.is_valid && !last_valid_ramp_result_.is_valid)
        return false;

    PlaneInfo plane_info;
    
    if (last_valid_stair_result_.is_valid)
    {
        plane_info = last_valid_stair_result_.plane_info;
    }

    if (last_valid_ramp_result_.is_valid)
    {
        plane_info = last_valid_ramp_result_.plane_info;
    }

    // Transform plane info from lidar frame to odom frame
    if (!transformPlaneInfoToOdom(plane_info, lidar_frame_))
    {
        RCLCPP_WARN(this->get_logger(), "Failed to transform plane info to odom frame");
        return false;
    }

    response->state = "Confident";
    response->slope = plane_info.orientationXYZ.z();

    // Populate start pose (now in odom frame)
    response->start_pose.clear();
    response->start_pose.push_back(plane_info.midpointXYZ.x());
    response->start_pose.push_back(plane_info.midpointXYZ.y());
    response->start_pose.push_back(plane_info.midpointXYZ.z());
    response->start_pose.push_back(plane_info.theta);

    // Populate plane equation (now in odom frame)
    response->plane_eq.clear();
    response->plane_eq.push_back(plane_info.equation[0]);
    response->plane_eq.push_back(plane_info.equation[1]);
    response->plane_eq.push_back(plane_info.equation[2]);
    response->plane_eq.push_back(plane_info.equation[3]);

    // Populate boundary points (now in odom frame)
    response->boundary.points.clear();
    for (const auto &boundary_point : plane_info.boundary)
    {
        geometry_msgs::msg::Point32 p;
        p.x = boundary_point.x();
        p.y = boundary_point.y();
        p.z = boundary_point.z();
        response->boundary.points.push_back(p);
    }

    // Populate direction (now in odom frame)
    response->direction.clear();
    response->direction.push_back(plane_info.direction_vec.x());
    response->direction.push_back(plane_info.direction_vec.y());
    response->direction.push_back(plane_info.direction_vec.z());

    // Populate plane width (unchanged)
    response->ta_width = plane_info.plane_width;

    return true;
}

void RosHandler::lidar_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
{
    if (!start_estimation_stair_ && !start_estimation_ramp_)
    {
        return;
    }

    // Store the frame_id from the message for later use in transformations
    lidar_frame_ = msg->header.frame_id;
    std::cout<<"inside lidar callback"<<std::endl;
    
    try
    {
        if (start_estimation_stair_)
        { 
            // Convert ROS message to Open3D point cloud
            open3d::geometry::PointCloud pcd;
            open3d_conversions::rosToOpen3d(msg, pcd);

            // Process point cloud with Stair detector
            StairResult result = stair_detector_->processPointCloud(pcd);

            // Update stored result if valid
            if (result.is_valid)
            {
                std::lock_guard<std::mutex> lock(result_mutex_);
                last_valid_stair_result_ = result;
            }

            // Publish debug information if enabled
            if (debug_mode_)
            {
                publishDebugInfo(result, msg->header.frame_id);
            }
        }

        if (start_estimation_ramp_)
        { 
            // Convert ROS message to Open3D point cloud
            open3d::geometry::PointCloud pcd;
            open3d_conversions::rosToOpen3d(msg, pcd);

            // Process point cloud with Ramp detector
            RampResult result = ramp_detector_->processPointCloud(pcd);

            // Update stored result if valid
            if (result.is_valid)
            {
                std::lock_guard<std::mutex> lock(result_mutex_);
                last_valid_ramp_result_ = result;
            }

            // Publish debug information if enabled
            if (debug_mode_)
            {
                publishDebugInfo(result, msg->header.frame_id);
            }
        }
    }
    catch (const std::exception &e)
    {
        RCLCPP_ERROR(this->get_logger(), "Error in lidar callback: %s", e.what());
    }
}

bool RosHandler::transformPlaneInfoToOdom(PlaneInfo& plane_info, const std::string& source_frame)
{
    try
    {
        // Get the transform from lidar_link to odom
        geometry_msgs::msg::TransformStamped transform_stamped;
        transform_stamped = tf_buffer_->lookupTransform(
            target_frame_, source_frame, tf2::TimePointZero, tf2::durationFromSec(1.0));

        // Transform midpoint (start pose position)
        plane_info.midpointXYZ = transformPoint(plane_info.midpointXYZ, transform_stamped);

        // Transform orientation vector
        plane_info.orientationXYZ = transformVector(plane_info.orientationXYZ, transform_stamped);

        // Transform direction vector
        plane_info.direction_vec = transformVector(plane_info.direction_vec, transform_stamped);

        // Transform boundary points
        for (auto& boundary_point : plane_info.boundary)
        {
            boundary_point = transformPoint(boundary_point, transform_stamped);
        }

        // Transform plane equation
        plane_info.equation = transformPlaneEquation(plane_info.equation, transform_stamped);

        // Transform theta (orientation angle) - this needs special handling
        // Extract rotation from transform and apply to theta
        tf2::Quaternion q_tf2;
        tf2::fromMsg(transform_stamped.transform.rotation, q_tf2);
        tf2::Matrix3x3 m(q_tf2);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        plane_info.theta += yaw;  // Add the yaw rotation to the existing theta

        RCLCPP_DEBUG(this->get_logger(), "Successfully transformed plane info to odom frame");
        return true;
    }
    catch (const tf2::TransformException &ex)
    {
        RCLCPP_ERROR(this->get_logger(), "Transform lookup failed: %s", ex.what());
        return false;
    }
}

Eigen::Vector3d RosHandler::transformPoint(const Eigen::Vector3d& point, const geometry_msgs::msg::TransformStamped& transform)
{
    geometry_msgs::msg::PointStamped point_in, point_out;
    
    point_in.point.x = point.x();
    point_in.point.y = point.y();
    point_in.point.z = point.z();
    point_in.header.frame_id = lidar_frame_;
    
    tf2::doTransform(point_in, point_out, transform);
    
    return Eigen::Vector3d(point_out.point.x, point_out.point.y, point_out.point.z);
}

Eigen::Vector3d RosHandler::transformVector(const Eigen::Vector3d& vector, const geometry_msgs::msg::TransformStamped& transform)
{
    geometry_msgs::msg::Vector3Stamped vector_in, vector_out;
    
    vector_in.vector.x = vector.x();
    vector_in.vector.y = vector.y();
    vector_in.vector.z = vector.z();
    vector_in.header.frame_id = lidar_frame_;
    
    tf2::doTransform(vector_in, vector_out, transform);
    
    return Eigen::Vector3d(vector_out.vector.x, vector_out.vector.y, vector_out.vector.z);
}

Eigen::Vector4d RosHandler::transformPlaneEquation(const Eigen::Vector4d& plane_eq, const geometry_msgs::msg::TransformStamped& transform)
{
    // Plane equation: ax + by + cz + d = 0
    // Normal vector is (a, b, c)
    // Point on plane can be found, then both normal and point are transformed
    
    // Extract normal vector
    Eigen::Vector3d normal(plane_eq[0], plane_eq[1], plane_eq[2]);
    
    // Find a point on the plane (using the closest point to origin)
    Eigen::Vector3d point_on_plane = -plane_eq[3] * normal;
    
    // Transform both normal and point
    Eigen::Vector3d transformed_normal = transformVector(normal, transform);
    Eigen::Vector3d transformed_point = transformPoint(point_on_plane, transform);
    
    // Normalize the normal vector
    transformed_normal.normalize();
    
    // Calculate new d: d = -(ax + by + cz) for the transformed point
    double new_d = -(transformed_normal.dot(transformed_point));
    
    return Eigen::Vector4d(transformed_normal.x(), transformed_normal.y(), transformed_normal.z(), new_d);
}

void RosHandler::publishDebugInfo(const StairResult &result, const std::string &frame_id)
{
    try
    {
        // Publish segmented point cloud
        if (!result.segmented_pcd.points_.empty())
        {
            sensor_msgs::msg::PointCloud2 segmented_msg;
            open3d_conversions::open3dToRos(result.segmented_pcd, segmented_msg, frame_id);
            pub_segmt_->publish(segmented_msg);
        }

        // Publish clustered point cloud
        if (!result.clustered_pcd.points_.empty())
        {
            sensor_msgs::msg::PointCloud2 clustered_msg;
            open3d_conversions::open3dToRos(result.clustered_pcd, clustered_msg, frame_id);
            pub_clust_->publish(clustered_msg);
        }

        // Publish plane visualization
        if (result.is_valid)
        {
            geometry_msgs::msg::PolygonStamped plane_msg = result.plane_msg;
            plane_msg.header.frame_id = frame_id;
            plane_msg.header.stamp = this->get_clock()->now();
            pub_plane_->publish(plane_msg);
        }
    }
    catch (const std::exception &e)
    {
        RCLCPP_WARN(this->get_logger(), "Error publishing debug info: %s", e.what());
    }
}

void RosHandler::publishDebugInfo(const RampResult &result, const std::string &frame_id)
{
    try
    {
        // Publish segmented point cloud
        if (!result.segmented_pcd.points_.empty())
        {
            sensor_msgs::msg::PointCloud2 segmented_msg;
            open3d_conversions::open3dToRos(result.segmented_pcd, segmented_msg, frame_id);
            pub_segmt_->publish(segmented_msg);
        }

        // Publish clustered point cloud
        if (!result.clustered_pcd.points_.empty())
        {
            sensor_msgs::msg::PointCloud2 clustered_msg;
            open3d_conversions::open3dToRos(result.clustered_pcd, clustered_msg, frame_id);
            pub_clust_->publish(clustered_msg);
        }

        // Publish plane visualization
        if (result.is_valid)
        {
            geometry_msgs::msg::PolygonStamped plane_msg = result.plane_msg;
            plane_msg.header.frame_id = frame_id;
            plane_msg.header.stamp = this->get_clock()->now();
            pub_plane_->publish(plane_msg);
        }
    }
    catch (const std::exception &e)
    {
        RCLCPP_WARN(this->get_logger(), "Error publishing debug info: %s", e.what());
    }
}