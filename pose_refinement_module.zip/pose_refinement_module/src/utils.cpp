#include "utils.h"


void stair_utils::visualize_pointcloud(open3d::geometry::PointCloud &pcd, std::string name)
{
	auto vis = std::make_shared<open3d::visualization::Visualizer>();
	std::shared_ptr<open3d::geometry::PointCloud> vis_pcd = std::make_shared<open3d::geometry::PointCloud>();
	*vis_pcd = pcd;
	vis->CreateVisualizerWindow(name, 800, 600);
	vis->AddGeometry(vis_pcd);
	vis->Run();
}

std::pair<double, double> stair_utils::calculateGoodnessOfFit(const Plane &plane)
{
    double totalSquaredError = 0.0;
    double totalVariance = 0.0;
    double meanZ = 0.0;
    int N = plane.point_coord.size();

    // Calculate mean of z-coordinates
    for (const auto &point : plane.point_coord)
    {
        meanZ += point.z();
    }
    meanZ /= N;

    // Calculate total variance (SST) and residuals (SSR)
    for (const auto &point : plane.point_coord)
    {
        double predictedZ = (-plane.equation[0] * point.x() - plane.equation[1] * point.y() - plane.equation[3]) / plane.equation[2];
        double error = point.z() - predictedZ;

        totalSquaredError += error * error;                         // SSR
        totalVariance += (point.z() - meanZ) * (point.z() - meanZ); // SST
    }

    double mse = totalSquaredError / N;                          // Mean Squared Error
    double rSquared = 1.0 - (totalSquaredError / totalVariance); // R-squared

    return {mse, rSquared}; // Return MSE and R-squared
}


Eigen::Vector3d stair_utils::vector_to_eigen(std::vector<double> in){

    Eigen::Vector3d out = {in[0],in[1],in[2]};
    return out;
}

geometry_msgs::msg::PolygonStamped stair_utils::plane_to_rosmsg(Plane& in){
    geometry_msgs::msg::PolygonStamped out;
    geometry_msgs::msg::Point32 point;

    out.polygon.points.clear();
        for (auto p : in.bbox_points)
        {
            point.x = p.x();
            point.y = p.y();
            point.z = p.z();
            out.polygon.points.push_back(point);
        }
    return out;
}


double stair_utils::calculateMeanSquareError(const Plane &plane)
{
    double a = plane.equation[0];
    double b = plane.equation[1];
    double c = plane.equation[2];
    double d = plane.equation[3];

    double normal_length = std::sqrt(a * a + b * b + c * c);
    if (normal_length == 0)
    {
        throw std::invalid_argument("Invalid plane equation: normal vector length is zero.");
    }

    double mse = 0.0;
    for (const auto &point : plane.point_coord)
    {
        // Distance of the point from the plane
        double distance = std::abs(a * point.x() + b * point.y() + c * point.z() + d) / normal_length;
        mse += distance * distance;
    }

    if (!plane.point_coord.empty())
    {
        mse /= plane.point_coord.size(); // Calculate the mean
    }
    return mse;
}


double stair_utils::angleBetweenVectors(const Eigen::Vector3d& v1, const Eigen::Vector3d& v2) {
    double dot_product = v1.dot(v2);
    double magnitude_product = v1.norm() * v2.norm();

    if (magnitude_product == 0) {
        throw std::runtime_error("Cannot compute angle with zero-length vector.");
    }

    double cosine_theta = dot_product / magnitude_product;

    // Clamp the value to avoid precision errors
    cosine_theta = std::max(-1.0, std::min(1.0, cosine_theta));

    return std::acos(cosine_theta)*57.2958; // Returns angle in degrees
}

double stair_utils::distancePointToLine(const Eigen::Vector3d& point, 
    const Eigen::Vector3d& linePoint, 
    const Eigen::Vector3d& lineDirection) {
Eigen::Vector3d diff = point - linePoint;
Eigen::Vector3d crossProduct = diff.cross(lineDirection);

double distance = crossProduct.norm() / lineDirection.norm();

return distance;
}


float stair_utils::getSlopeZaxisDegree(Plane& pl)
{
    float pi2degree = 180.0/M_PI;
    return acos(pl.normal.z()/sqrt(pow(pl.normal.x(),2)+pow(pl.normal.y(),2)+pow(pl.normal.z(),2)))*pi2degree;
}

float stair_utils::getSlopeXaxisDegree(Plane& pl)
{
    float pi2degree = 180/M_PI;
    return acos(pl.normal.x()/sqrt(pow(pl.normal.x(),2)+pow(pl.normal.y(),2)+pow(pl.normal.z(),2)))*pi2degree;
}

float stair_utils::getSlopeYaxisDegree(Plane& pl)
{
    float pi2degree = 180/M_PI;
    return acos(pl.normal.y()/sqrt(pow(pl.normal.x(),2)+pow(pl.normal.y(),2)+pow(pl.normal.z(),2)))*pi2degree;
}

Point3D stair_utils::transform_point(const Point3D &point, const geometry_msgs::msg::TransformStamped &transform_msg) {
    // Convert TransformStamped to tf2::Transform
    tf2::Transform transform;
    tf2::Quaternion rotation;
    tf2::Vector3 translation;

    rotation.setX(transform_msg.transform.rotation.x);
    rotation.setY(transform_msg.transform.rotation.y);
    rotation.setZ(transform_msg.transform.rotation.z);
    rotation.setW(transform_msg.transform.rotation.w);

    translation.setX(transform_msg.transform.translation.x);
    translation.setY(transform_msg.transform.translation.y);
    translation.setZ(transform_msg.transform.translation.z);

    transform.setOrigin(translation);
    transform.setRotation(rotation);

    // Convert point to tf2::Vector3
    tf2::Vector3 point_in_laser(point.x, point.y, point.z);

    // Transform the point
    tf2::Vector3 point_in_odom = transform * point_in_laser;

    // Return transformed point
    return {point_in_odom.x(), point_in_odom.y(), point_in_odom.z()};
}



Eigen::Vector3d stair_utils::transform_point(const Eigen::Vector3d &point, const geometry_msgs::msg::TransformStamped &transform_msg) {
    // Convert TransformStamped to tf2::Transform
    tf2::Transform transform;
    tf2::Quaternion rotation;
    tf2::Vector3 translation;

    rotation.setX(transform_msg.transform.rotation.x);
    rotation.setY(transform_msg.transform.rotation.y);
    rotation.setZ(transform_msg.transform.rotation.z);
    rotation.setW(transform_msg.transform.rotation.w);

    translation.setX(transform_msg.transform.translation.x);
    translation.setY(transform_msg.transform.translation.y);
    translation.setZ(transform_msg.transform.translation.z);

    transform.setOrigin(translation);
    transform.setRotation(rotation);

    // Convert point to tf2::Vector3
    tf2::Vector3 point_in_laser(point.x(), point.y(), point.z());

    // Transform the point
    tf2::Vector3 point_in_odom = transform * point_in_laser;
    Eigen::Vector3d out(point_in_odom.x(), point_in_odom.y(), point_in_odom.z());
    return out;
}


double stair_utils::pointToSegmentDistance(const Eigen::Vector3d &p, const Eigen::Vector3d &a, const Eigen::Vector3d &b, Eigen::Vector3d &projection)
{
    Eigen::Vector3d ab = b - a;
    double t = (p - a).dot(ab) / ab.squaredNorm();
    t = std::max(0.0, std::min(1.0, t));
    projection = a + t * ab;
    return (p - projection).norm();
}

Eigen::Vector3d stair_utils::computeQuadNormal(const std::vector<Eigen::Vector3d> &quad)
{
    Eigen::Vector3d v1 = quad[1] - quad[0];
    Eigen::Vector3d v2 = quad[2] - quad[1];
    return v1.cross(v2).normalized();
}

Eigen::Vector2d stair_utils::projectToPlane(const Eigen::Vector3d &pt, const Eigen::Vector3d &origin, const Eigen::Vector3d &u, const Eigen::Vector3d &v)
{
    Eigen::Vector3d relative = pt - origin;
    return Eigen::Vector2d(relative.dot(u), relative.dot(v));
}

bool stair_utils::isPointInPolygon2D(const std::vector<Eigen::Vector2d> &polygon, const Eigen::Vector2d &point)
{
    int crossings = 0;
    int n = polygon.size();
    for (int i = 0; i < n; ++i)
    {
        const Eigen::Vector2d &a = polygon[i];
        const Eigen::Vector2d &b = polygon[(i + 1) % n];

        bool cond1 = (a.y() <= point.y()) && (b.y() > point.y());
        bool cond2 = (b.y() <= point.y()) && (a.y() > point.y());
        if (cond1 || cond2)
        {
            double t = (point.y() - a.y()) / (b.y() - a.y());
            if (point.x() < a.x() + t * (b.x() - a.x()))
                ++crossings;
        }
    }
    return (crossings % 2) == 1;
}

void stair_utils::extendQuadEdgeToPoint(std::vector<Eigen::Vector3d> &quad, const Eigen::Vector3d &point)
{
    if (quad.size() != 4)
    {
        std::cerr << "Quadrilateral must have 4 points." << std::endl;
        return;
    }

    Eigen::Vector3d normal = computeQuadNormal(quad);
    Eigen::Vector3d u = (quad[1] - quad[0]).normalized();
    Eigen::Vector3d v = normal.cross(u).normalized();

    std::vector<Eigen::Vector2d> quad2D;
    for (const auto &p : quad)
        quad2D.push_back(projectToPlane(p, quad[0], u, v));
    Eigen::Vector2d point2D = projectToPlane(point, quad[0], u, v);

    if (isPointInPolygon2D(quad2D, point2D))
    {
        return;
    }

    double minDist = std::numeric_limits<double>::max();
    int closestEdgeIdx = -1;
    Eigen::Vector3d proj_on_edge;

    for (int i = 0; i < 4; ++i)
    {
        Eigen::Vector3d temp_proj;
        double dist = stair_utils::pointToSegmentDistance(point, quad[i], quad[(i + 1) % 4], temp_proj);
        if (dist < minDist)
        {
            minDist = dist;
            closestEdgeIdx = i;
            proj_on_edge = temp_proj;
        }
    }

    int i1 = closestEdgeIdx;
    int i2 = (closestEdgeIdx + 1) % 4;
    Eigen::Vector3d edge = quad[i2] - quad[i1];
    Eigen::Vector3d edge_dir = edge.normalized();
    Eigen::Vector3d edge_normal = normal.cross(edge_dir).normalized();
    Eigen::Vector3d to_point = point - proj_on_edge;
    double offset = to_point.dot(edge_normal);

    quad[i1] += offset * edge_normal;
    quad[i2] += offset * edge_normal;

}

bool stair_utils::isPointInPolygon2D(std::vector<Eigen::Vector3d> &quad, const Eigen::Vector3d &point)
{
    if (quad.size() != 4)
    {
        std::cerr << "Quadrilateral must have 4 points." << std::endl;
        return false;
    }

    Eigen::Vector3d normal = computeQuadNormal(quad);
    Eigen::Vector3d u = (quad[1] - quad[0]).normalized();
    Eigen::Vector3d v = normal.cross(u).normalized();

    std::vector<Eigen::Vector2d> quad2D;
    for (const auto &p : quad)
        quad2D.push_back(projectToPlane(p, quad[0], u, v));
    Eigen::Vector2d point2D = projectToPlane(point, quad[0], u, v);

    if (isPointInPolygon2D(quad2D, point2D))
    {
        return true;
    }
    else
        return false;
}

double stair_utils::point_to_line_distance(const Eigen::Vector3d &p, const Eigen::Vector3d &a, const Eigen::Vector3d &b)
{
    Eigen::Vector3d ab = b - a;
    Eigen::Vector3d ap = p - a;
    double t = ap.dot(ab) / ab.squaredNorm();
    t = std::max(std::min(t, 0.0), 1.0);
    Eigen::Vector3d closest = a + t * ab;
    return (p - closest).norm();
}

void stair_utils::extend_edge_3d(std::vector<Eigen::Vector3d> &boundary_points_, size_t idx1, size_t idx2, const Eigen::Vector3d &push_dir)
{

    double edge_push_distance_ = 0.5;
    boundary_points_[idx1] += push_dir * edge_push_distance_;
    boundary_points_[idx2] += push_dir * edge_push_distance_;

    // RCLCPP_INFO(this->get_logger(), "Edge (%ld-%ld) pushed outward in 3D.", idx1, idx2);
}

tf2::Matrix3x3 stair_utils::getRotationFromQuaternion(geometry_msgs::msg::TransformStamped& transform)
{

    tf2::Matrix3x3 rotation;
    tf2::Quaternion q(transform.transform.rotation.x, transform.transform.rotation.y,
                      transform.transform.rotation.z, transform.transform.rotation.w);
    rotation.setRotation(q);
    return rotation;

}