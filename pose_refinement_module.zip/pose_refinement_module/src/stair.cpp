#include "stair.h"

Stair::Stair() 
    : debug_mode_(false)
    , slope_tolerance_(15.0)
    , alignment_tolerance_(15.0) 
    , min_candidates_for_estimation_(10)
    , current_state_(StairState::Unknown)
{
    // Initialize with default parameters
    plane_est_param default_plane_params;
    default_plane_params.detect_min_ratio = 0.05;
    default_plane_params.detect_max_cnt = 15;
    default_plane_params.detect_dist_threshold = 0.005;
    default_plane_params.ransac_nb_sample = 6;
    default_plane_params.ransac_max_iter = 200;
    
    preprocess_param default_preprocess_params;
    default_preprocess_params.crop_min_bound = {0.0, -3.5, -0.5};
    default_preprocess_params.crop_max_bound = {10.0, 3.5, 10.0};
    default_preprocess_params.outlier_nb_neighbours = 50;
    default_preprocess_params.outlier_std_ratio = 1;
    default_preprocess_params.voxel_dim = 0.04;
    
    cluster_param default_cluster_params;
    default_cluster_params.eps = 0.05;
    default_cluster_params.min_points = 10;
    
    plane_estimator_ = std::make_unique<PlanEstimation>(default_plane_params);
    clustering_ = std::make_unique<Clustering>(default_preprocess_params, default_cluster_params);
    
    debugPrint("Stair detector initialized with default parameters");
}

Stair::Stair( plane_est_param& plane_params, 
              preprocess_param& preprocess_params, 
              cluster_param& cluster_params)
    : debug_mode_(false)
    , slope_tolerance_(15.0)
    , alignment_tolerance_(15.0)
    , min_candidates_for_estimation_(10)
    , current_state_(StairState::Unknown)
{
    plane_estimator_ = std::make_unique<PlanEstimation>(plane_params);
    clustering_ = std::make_unique<Clustering>(preprocess_params, cluster_params);
    
    debugPrint("Stair detector initialized with custom parameters");
}

StairResult Stair::processPointCloud( open3d::geometry::PointCloud& input_pcd)
{
    StairResult result;
    
    try {
        // Step 1: Preprocess point cloud
        open3d::geometry::PointCloud processed_pcd = input_pcd;
        clustering_->preProcessPcd(processed_pcd);
        result.segmented_pcd = processed_pcd;
        
        // Step 2: Detect multiple planes
        std::vector<Plane> detected_planes = plane_estimator_->DetectMultiPlanes(processed_pcd);
        
        debugPrint("Detected " + std::to_string(detected_planes.size()) + " planes");
        
        // Step 3: Filter for potential stair planes
        for (auto& plane : detected_planes) {
            std::pair<double, double> fitness = stair_utils::calculateGoodnessOfFit(plane);
            float slope_val = stair_utils::getSlopeZaxisDegree(plane);
            
            debugPrintPlaneDetails(plane, fitness);
            
            if (isValidStairPlane(plane, fitness)) {
                setState(StairState::Estimating);
                slope_plane_candidates_.push_back(plane);
                
                // Step 4: Check if we have enough candidates for estimation
                if (slope_plane_candidates_.size() > min_candidates_for_estimation_) {
                    // Aggregate slope candidates
                    aggregateSlopeCandidates(slope_plane_candidates_);
                    
                    if (slope_point_candidates_.points_.size() < 1) {
                        debugPrint("Insufficient points after clustering");
                        continue;
                    }
                    
                    // Cluster the aggregated points
                    clustering_->dbscanCluster(slope_point_candidates_);
                    clustering_->getSlopePcdFromCluster(slope_point_candidates_);
                    result.clustered_pcd = slope_point_candidates_;
                    
                    if (slope_point_candidates_.points_.size() < 1) {
                        debugPrint("No valid clusters found");
                        continue;
                    }
                    
                    // Step 5: Estimate final stair plane
                    Plane final_plane = estimateFinalStairPlane();
                    PlaneInfo plane_info = calculatePlaneInfo(final_plane);
                    
                    // Step 6: Get directional estimate from clustering
                    Eigen::Vector3d plane_line_normal = clustering_->getThetaEstimate();
                    
                    // Step 7: Validate final plane
                    current_plane_info_ = plane_info;
                    if (validateFinalPlane(plane_info, plane_line_normal)) {
                            if (plane_line_normal.norm() > 0) {
                            current_plane_info_.direction_vec = plane_line_normal;
                            current_plane_info_.theta = atan2(plane_line_normal.y(), plane_line_normal.x());
                        }
                        
                        // Create plane message for visualization
                        result.plane_msg = stair_utils::plane_to_rosmsg(final_plane);
                        
                        setState(StairState::Confident);
                        result.is_valid = true;
                        result.state = StairState::Confident;
                        result.plane_info = current_plane_info_;
                        
                        std::pair<double, double> final_fitness = stair_utils::calculateGoodnessOfFit(final_plane);
                        float final_slope = abs(atan(sqrt(pow(final_plane.normal.x(), 2) + 
                                                         pow(final_plane.normal.y(), 2)) / 
                                                    final_plane.normal.z())) * 57.2958;
                        
                        debugPrintFinalResults(current_plane_info_, final_slope, final_fitness);
                        
                        // Clear candidates for next detection
                        slope_plane_candidates_.clear();
                        break;
                    }
                    
                    // Clear candidates if validation failed
                    slope_plane_candidates_.clear();
                }
            }
        }
        
        // If no valid stair found, set appropriate state
        if (!result.is_valid) {
            result.state = getCurrentState();
        }
        
    } catch ( std::exception& e) {
        debugPrint("Error in stair processing: " + std::string(e.what()));
        setState(StairState::Unknown);
        result.is_valid = false;
        result.state = StairState::Unknown;
    }
    
    return result;
}

void Stair::reset()
{
    std::lock_guard<std::mutex> lock(state_mutex_);
    slope_plane_candidates_.clear();
    slope_point_candidates_.Clear();
    current_plane_info_ = PlaneInfo();
    current_state_ = StairState::Unknown;
    
    debugPrint("Stair detector reset");
}

StairState Stair::getCurrentState() 
{
    std::lock_guard<std::mutex> lock(state_mutex_);
    return current_state_;
}

bool Stair::isValidStairPlane(Plane& plane,std::pair<double, double>& fitness)
{
    float slope_val = stair_utils::getSlopeZaxisDegree(plane);
    return plane_estimator_->ifStair(abs(slope_val), fitness);
}

bool Stair::isPlaneAligned( Eigen::Vector3d& normal_line, double tolerance) 
{
    double angle1 = stair_utils::angleBetweenVectors(normal_line, current_plane_info_.edge_vectors.first);
    double angle2 = stair_utils::angleBetweenVectors(normal_line, current_plane_info_.edge_vectors.second);
    
    debugPrint("Angle between normal_line & plane_info: " + std::to_string(angle1) + " " + std::to_string(angle2));
    
    // Check various angle alignments
    std::vector<double> angles = {angle1, angle2};
    std::vector<double> target_angles = {0, 90, 180, 270};
    
    for (double angle : angles) {
        for (double target : target_angles) {
            if (abs(fmod(abs(angle - target), 90)) < tolerance) {
                return true;
            }
        }
    }
    
    return false;
}

void Stair::aggregateSlopeCandidates(std::vector<Plane>& candidates)
{
    plane_estimator_->calSlopeCandidatesPcd(candidates);
    slope_point_candidates_ = plane_estimator_->slope_point_candidates;
    
    debugPrint("Aggregated slope candidates: " + std::to_string(slope_point_candidates_.points_.size()) + " points");
}

Plane Stair::estimateFinalStairPlane()
{
    return plane_estimator_->estimateSlopeParam();
}

PlaneInfo Stair::calculatePlaneInfo( Plane& plane)
{
    return plane_estimator_->getAggregatedPlaneInfo(plane,start_offset_);
}

bool Stair::validateFinalPlane( PlaneInfo& plane_info,  Eigen::Vector3d& plane_line_normal)
{
    double tolerance = alignment_tolerance_;
    
    if (plane_line_normal.norm() <= 0) {
        // If no seed line vector, check theta alignment
        return abs(plane_info.theta) < slope_tolerance_;
    } else {
        // Check alignment with seed line vector
        return isPlaneAligned(plane_line_normal, tolerance);
    }
}

void Stair::setState(StairState new_state)
{
    std::lock_guard<std::mutex> lock(state_mutex_);
    current_state_ = new_state;
}

void Stair::debugPrint( std::string message) 
{   
    if (debug_mode_) {
        std::cout << "[Stair] " << message << std::endl;
    }
}

void Stair::debugPrintPlaneDetails( Plane& plane,  std::pair<double, double>& fitness) 
{
    if (debug_mode_) {
        float slope_x = stair_utils::getSlopeXaxisDegree(plane);
        float slope_y = stair_utils::getSlopeYaxisDegree(plane);
        float slope_z = stair_utils::getSlopeZaxisDegree(plane);
        
        std::cout << "[Stair] Plane normal angles - X: " << slope_x 
                  << "° Y: " << slope_y << "° Z: " << slope_z 
                  << "° MSE: " << fitness.first << " R²: " << fitness.second << std::endl;
    }
}

void Stair::debugPrintFinalResults( PlaneInfo& plane_info, double slope_val, 
                                   std::pair<double, double>& fitness) 
{
    if (debug_mode_) {
        std::cout << "\n" << std::string(80, '-') << std::endl;
        std::cout << "[Stair] Final Results:" << std::endl;
        std::cout << "  Slope angles - X: " << plane_info.orientationXYZ.x() 
                  << "° Y: " << plane_info.orientationXYZ.y() 
                  << "° Z: " << plane_info.orientationXYZ.z() << "°" << std::endl;
        std::cout << "  Slope value: " << slope_val << "°" << std::endl;
        std::cout << "  Fitness - MSE: " << fitness.first << " R²: " << fitness.second << std::endl;
        std::cout << "  Start point (x,y,z): (" << plane_info.midpointXYZ.x() 
                  << ", " << plane_info.midpointXYZ.y() 
                  << ", " << plane_info.midpointXYZ.z() << ")" << std::endl;
        std::cout << "  Plane equation (a,b,c,d): (" << plane_info.equation[0] 
                  << ", " << plane_info.equation[1] 
                  << ", " << plane_info.equation[2] 
                  << ", " << plane_info.equation[3] << ")" << std::endl;
        std::cout << "  Theta: " << plane_info.theta << "°" << std::endl;
        
        for (size_t i = 0; i < plane_info.boundary.size(); ++i) {
            std::cout << "  Boundary point " << i << " (x,y,z): (" 
                      << plane_info.boundary[i].x() << ", " 
                      << plane_info.boundary[i].y() << ", " 
                      << plane_info.boundary[i].z() << ")" << std::endl;
        }
        std::cout << std::string(80, '-') << std::endl;
    }
}