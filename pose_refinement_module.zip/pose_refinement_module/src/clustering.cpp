#include "clustering.h"

Clustering::Clustering()
{
	pproc_param_.crop_min_bound = {0.0, -3.5, -0.5}; //{-10.0, -10.0, -0.4};   //{0.0, -3.5, -0.5}; //{-3.5,-10.0, -0.5}; 
	pproc_param_.crop_max_bound = {10.0, 3.5, 10.0}; //{10.0, 10.0, 5.0}; //{3.5, 0.0, 10.0}; 
	pproc_param_.outlier_nb_neighbours = 50;
	pproc_param_.outlier_std_ratio = 1;
	pproc_param_.voxel_dim = 0.04;
	clust_param_.eps = 0.05; //distance to the neighbours
	clust_param_.min_points = 10;
    // slope_line_candidates_ = std::make_shared<std::vector<Line>>();
    // std::shared_ptr<std::vector<std::pair<Eigen::Vector3d,int>>> seed_line_candidates_ = std::make_shared<std::vector<std::pair<Eigen::Vector3d,int>>>();
}

Clustering::Clustering(preprocess_param &pproc_param, cluster_param &clust_param)
{
	pproc_param_ = pproc_param;
	clust_param_ = clust_param;
}

void Clustering::preProcessPcd(open3d::geometry::PointCloud &pcd)
{
	pcd = pcd.RemoveNonFinitePoints();
	pcd = *pcd.Crop(open3d::geometry::AxisAlignedBoundingBox(pproc_param_.crop_min_bound, pproc_param_.crop_max_bound));
	pcd = *std::get<0>(pcd.RemoveStatisticalOutliers(pproc_param_.outlier_nb_neighbours, pproc_param_.outlier_std_ratio));
	pcd = *pcd.VoxelDownSample(pproc_param_.voxel_dim);
}

std::pair<Eigen::Vector3d,Eigen::Vector3d> ComputeMeanAndExtent(const std::vector<Eigen::Vector3d>& points) {
    Eigen::Vector3d mean(0, 0, 0);
    Eigen::Vector3d max_point = points[0];
    Eigen::Vector3d min_point = points[0];

    for (const auto& p : points) {
        mean += p;    
        if(p.norm()>max_point.norm())
            max_point = p;
        if(p.norm()<min_point.norm())
            min_point = p;
    }
    mean /= points.size();
    std::pair<Eigen::Vector3d,Eigen::Vector3d> out;
    out.first = mean;
    out.second = max_point-min_point;
    // std::cout<<"max point: "<<max_point.x()<<" "<<max_point.y()<<" "<<max_point.z()<<" min point:"<<min_point.x()<<" "<<min_point.y()<<" "<<min_point.z()<<" Length of line:"<<out.second.norm()<<std::endl ;
    
    return out;
}

std::pair<std::pair<Eigen::Vector3d,Eigen::Vector3d>, Eigen::Vector3d> Fit3DLine(const open3d::geometry::PointCloud& pcd) {
    // Convert Open3D point cloud to Eigen vector
    std::vector<Eigen::Vector3d> points;
    for (const auto& p : pcd.points_) {
        points.push_back(p);
    }

    // Compute mean of points
    std::pair<Eigen::Vector3d,Eigen::Vector3d> mean_extent = ComputeMeanAndExtent(points);

    // Compute covariance matrix
    Eigen::Matrix3d covariance = Eigen::Matrix3d::Zero();
    for (const auto& p : points) {
        Eigen::Vector3d diff = p - mean_extent.first;
        covariance += diff * diff.transpose();
    }
    covariance /= points.size();

    // Perform Eigen decomposition
    Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> solver(covariance);
    Eigen::Vector3d direction = solver.eigenvectors().col(2).normalized(); // Largest eigenvector

    return {mean_extent, direction};
}

void Clustering::getSlopePcdFromCluster(open3d::geometry::PointCloud& pcd)
{
    pcd.Clear();
    // std::cout<<"P0"<<std::endl;
    findSeedLines();
    // std::cout<<"P1"<<std::endl;
    int best_idx = getBestSeedLine().first;
    // std::cout<<"P2:"<<best_idx<<std::endl;
    
    if(best_idx < 0)
        return;
    
    for(int i=0 ; i < slope_line_candidates_.size(); i++)
    {
        //if parallel to seed line, distance from normal seed line in extent/2, withing polygon
        double angle_diff = stair_utils::angleBetweenVectors(slope_line_candidates_.at(i).eigen_vector,seed_line_candidates_.at(best_idx).first);
        double dist_diff = stair_utils::distancePointToLine(slope_line_candidates_.at(i).center,slope_line_candidates_.at(seed_line_candidates_.at(best_idx).second).center ,seed_line_candidates_.at(best_idx).first);
        double tol = 40.0;
        //if( (int(abs(abs(angle_diff) -90)) % 90) < tol || (int(abs(abs(angle_diff) -270)) % 270) < tol)
        if(abs(abs(angle_diff) -90) < tol  )
        {
          if(dist_diff < (slope_line_candidates_.at(seed_line_candidates_.at(best_idx).second).extent.norm())/2)
          {
            //if( line center fall inside the boundary)
            std::cout<<"Line"<<i<<" added to the ramp pointcloud\n";
            pcd += slope_line_candidates_.at(i).line_pcd;
          }
        }
        // std::cout<<"P2.4"<<std::endl;
    }
    // std::cout<<"pointcloud size inside:"<< pcd.points_.size()<<"\n";
    // std::cout<<"P2.5"<<std::endl;
    // fit a ransac with alignement or take 2 extrements find the plane that fits for slope similar to predicted.
    // Add initial boundary to check too
}

void Clustering::getLineInformation(open3d::geometry::PointCloud& pcd, std::shared_ptr<std::vector<std::vector<size_t>>> clust_idx)
{
    for(int i=0; i < clust_idx->size() ; i++)
	{
        open3d::geometry::PointCloud pcd_clust = *pcd.SelectByIndex(clust_idx->at(i));
	    std::pair<std::pair<Eigen::Vector3d,Eigen::Vector3d>,Eigen::Vector3d> line_detail = Fit3DLine(pcd_clust);
        Line l;
        l.id = i;
        l.line_pcd = pcd_clust;
        l.center = line_detail.first.first;
        l.eigen_vector = line_detail.second;
        l.extent = line_detail.first.second;
        slope_line_candidates_.push_back(l);
        std::cout<<"Cluster"<<i<<" Center of Centroid: "<<line_detail.first.first.x()<<" "<<line_detail.first.first.y()<<" "<<line_detail.first.first.z()<<" Eigen Vector:"<<line_detail.second.x()<<" "<<line_detail.second.y()<<" "<<line_detail.second.z()<<" Length of line:"<<line_detail.first.second.norm()<<std::endl ;
    }

}

Eigen::Vector3d getPlaneLineNormal(const Eigen::Vector3d& v1, const Eigen::Vector3d& v2) {
   if(v1.norm() < v2.norm())
   {
        return v2-v1;
   }
   else
    return v1-v2;
}

void Clustering::findSeedLines()
{
    seed_line_candidates_.clear();
    for(int i=0; i<slope_line_candidates_.size(); i++)
    {
        for(int j=i+1; j<slope_line_candidates_.size(); j++)
        {
            double dir_diff = stair_utils::angleBetweenVectors(slope_line_candidates_.at(i).eigen_vector,slope_line_candidates_.at(j).eigen_vector);
            std::cout<<"Clusters:"<<i<<" "<<j<<" dir_diff:"<<dir_diff<<std::endl;

            if((abs(dir_diff) < 5 || abs(abs(dir_diff) - 180) > 5) && slope_line_candidates_.at(i).extent.norm() > 0.5 && slope_line_candidates_.at(j).extent.norm() > 0.5)
            {
                Eigen::Vector3d plane_line_normal_candidate = getPlaneLineNormal(slope_line_candidates_.at(i).center,slope_line_candidates_.at(j).center);
                plane_line_normal_candidate = plane_line_normal_candidate/plane_line_normal_candidate.norm();
                std::cout<<"plane_line_normal_candidate:"<<plane_line_normal_candidate.x()<<" "<<plane_line_normal_candidate.y()<<" "<<plane_line_normal_candidate.z()<<std::endl;
                    
                for (int k = 0; k < slope_line_candidates_.size(); k++)
                {
                    if(k == i || k == j)
                        continue;
                    else
                    {
                        dir_diff = stair_utils::angleBetweenVectors(plane_line_normal_candidate,slope_line_candidates_.at(k).eigen_vector);
                        std::cout<<"Clusters:"<<k<<" dir_diff:"<<dir_diff<<std::endl;
                        if(abs(dir_diff) > 50)
                        {
                            std::cout << " Found A seed line " << dir_diff << " clusters: "<< i <<" "<<j <<" "<< k<< " normal line: "<<plane_line_normal_candidate.x()<<" "<<plane_line_normal_candidate.y()<<" "<<plane_line_normal_candidate.z()<< std::endl;
                            std::pair<Eigen::Vector3d,int> seed_line_candidate;
                            seed_line_candidate.first = plane_line_normal_candidate;
                            seed_line_candidate.second = i;
                            // std::cout<<"P0.1"<<std::endl;
                            seed_line_candidates_.push_back(seed_line_candidate);
                            slope_line_candidates_.at(i).onSlope = true;
                            slope_line_candidates_.at(j).onSlope = true;
                            slope_line_candidates_.at(k).onSlope = true;
                            // std::cout<<"P0.2"<<std::endl;
                        }
                    }
                    // std::cout<<"P0.3"<<std::endl;
                }
                
            }
        }
    }

}

std::pair<int,double> Clustering::getBestSeedLine()
{
    int best_idx = -1;
    std::pair<int,double> best_fit(-1,10000000.0);
        if(seed_line_candidates_.size() > 1)
        {
            
            for(int i=0; i<seed_line_candidates_.size(); i++)
            {
                double sum = 0;
                for(int j=0; j<slope_line_candidates_.size(); j++)
                {   
                    
                    if(slope_line_candidates_.at(j).onSlope)
                    {
            
                        sum += stair_utils::distancePointToLine(slope_line_candidates_.at(j).center,slope_line_candidates_.at(seed_line_candidates_.at(i).second).center,seed_line_candidates_.at(i).first);
                    
                    }
                }
                // std::cout<<"seed line candidate"<<i<<" total sum of distance:"<<sum<<std::endl;
                if(sum < best_fit.second)
                {
                    best_fit.second = sum;
                    best_fit.first = i;
                }
            }

            best_idx = best_fit.first;
            std::cout<<"Best seed line candidate"<<best_idx<<" :"<<seed_line_candidates_.at(best_idx).first.x()<<" "<<seed_line_candidates_.at(best_idx).first.y()<<" "<<seed_line_candidates_.at(best_idx).first.z()<<std::endl;
            return best_fit;
        }
        else
            return best_fit;
}

Eigen::Vector3d Clustering::getThetaEstimate()
{
    std::cout<<"Slope Line cadidate size:"<<slope_line_candidates_.size()<<"\n";
    if(slope_line_candidates_.size() <= 3)
    {
        return Eigen::Vector3d(0,0,0);
    }
    else
    {
        findSeedLines();
        std::pair<int,double> best_fit = getBestSeedLine();

        int best_idx = best_fit.first;
        std::cout<<"Best seed line candidate"<<best_idx<<" :"<<seed_line_candidates_.at(best_idx).first.x()<<" "<<seed_line_candidates_.at(best_idx).first.y()<<" "<<seed_line_candidates_.at(best_idx).first.z()<<std::endl;
        int best_line_idx = seed_line_candidates_.at(best_idx).second;
        std::cout<<"Best plane line candidate center"<<best_line_idx<<": "<<slope_line_candidates_.at(best_line_idx).center.x()<<" "<<slope_line_candidates_.at(best_line_idx).center.y()<<" "<<slope_line_candidates_.at(best_line_idx).center.z()<<std::endl;
        if(best_idx >= 0)
            return seed_line_candidates_.at(best_idx).first;
    }
    
    return Eigen::Vector3d(0,0,0);
}

void Clustering::dbscanCluster(open3d::geometry::PointCloud &pcd)
{
    slope_line_candidates_.clear();
	std::vector<int> cluster_labels = pcd.ClusterDBSCAN(clust_param_.eps, clust_param_.min_points, false);
	int max_label = *std::max_element(cluster_labels.begin(), cluster_labels.end());
	std::cout << "Point cloud has " << max_label + 1 << " clusters." << std::endl;
    // slope_line_candidates_.resize(max_label+1);
	std::vector<Eigen::Vector3d> cluster_colors;
    for (int i = 0; i <= max_label; ++i) {
        cluster_colors.push_back(Eigen::Vector3d::Random().cwiseAbs());  // Generate random color
    }

	std::shared_ptr<std::vector<std::vector<size_t>>> clust_idx = std::make_shared<std::vector<std::vector<size_t>>>(max_label+1);
    std::vector<Eigen::Vector3d> colors(pcd.points_.size());
    for (size_t i = 0; i < cluster_labels.size(); ++i) {
        if (cluster_labels[i] < 0) {
            colors[i] = {0, 0, 0}; // Noise points are black
        } else {
			clust_idx->at(cluster_labels[i]).push_back(i);
            colors[i] = cluster_colors[cluster_labels[i]]; //Eigen::Vector3d::Random().cwiseAbs(); //{static_cast<double>(cluster_labels[i]) / max_label, 0.5, 0.5}; // Color based on cluster label
        }
    }
    pcd.colors_ = colors;
    getLineInformation(pcd,clust_idx);


}
