# Object Detection Module

This repository contains a ROS2-based object detection package that leverages the YOLOv8 model for real-time object detection from image streams. Below are details on the package structure, execution instructions, and debugging guidelines.

---

## Package Structure

The module follows a standard ROS2 directory structure:

- **Package Name**: `object_detection_python`
  - `object_detection_node.py`: The main executable script containing the ROS2 node for object detection.
  - `object_detector.py`: Includes the YOLOv8 module responsible for inference on ROS2 image topics and publishing object detection results.
  - `utils.py`: Provides utility functions for the object detection module.

---

## Execution Instructions

### Dependencies
- `OpenCV`
- `Ultralytics`
- `autonovus_msgs`

### Build Process
```bash
cd <ros2_workspace_directory>
colcon build --packages-select autonovus_msgs
colcon build --packages-select object_detection_python
source install/setup.bash
```
### Launch Process
```bash
ros2 launch object_detection_python object_detection.launch.py
```