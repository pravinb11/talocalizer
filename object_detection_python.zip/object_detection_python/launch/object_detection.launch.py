from launch import LaunchDescription
from launch_ros.actions import Node

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='object_detection_python',
            namespace='cam1',
            executable='object_detection',
            name='object_detection',
            output='screen',
            emulate_tty=True,
            parameters=[
            {"debug_mode": True},
            {"model_path": '/home/hitech/ros2/perception_ws/src/ta_localizer_modules/transition_localizer/model/simulation_model_open_nav2.pt'},
            {"camera_subscriber": '/left_camera/image_raw'},
            {"target_class_list": ['Barbed-fence', 'Bridge', 'Building', 'Bus', 'Car', 'Chair', 'Concertina-fence', 'Cupboard', 'Door', 'Fire', 'Fire-extinguisher', 'Gate', 'Gun', 'Hand-grenade', 'Hill', 'Jeep', 'Knife', 'Lunch-box', 'Person', 'Person-in-uniform', 'Person-with-gun', 'Plastic-fence', 'Pressure-cooker', 'Small-gun', 'Smoke', 'Sofa', 'Stair', 'Storage-box', 'Table', 'Tank', 'Tent', 'Torch', 'Truck', 'Two-wheeler', 'Water-bottle', 'Water-gas-pipeline-valve', 'Window-with-grill', 'Window-without-grill', 'Entry-gate', 'Pot', 'Sphere', 'Ramp' ]}
        ]                         #       0           1          2          3      4      5               6              7        8        9                10         11      12          13         14      15      16          17        18           19                      20                 21              22              23          24       25      26          27          28     29       30       31       32           33          34                     35                      36                        37               38          39     40       41      42
        )
    ])