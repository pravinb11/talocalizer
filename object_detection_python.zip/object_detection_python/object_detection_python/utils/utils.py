import numpy as np

def create_polygon(self, bbox):
    # print(f"Boxes : {bbox} {bbox.shape}")
    rectangles = np.zeros((bbox.shape[0], 4, 2))

    for idx, i in enumerate(bbox):
        rectangles[idx] = np.array([[i[0], i[1]], [i[2], i[1]], [i[2], i[3]], [i[0], i[3]]])

        # print(f"Rectangles: {rectangles} {rectangles.shape}")
    return rectangles


def find_string_index(string_list, target_string):
    for index, string in enumerate(string_list):
        if string == target_string:
            return index
    return -1 

def if_boxes_overlap(bbox1,bbox2):
    max_width = max(bbox1.width, bbox2.width)
    max_height = max(bbox1.height, bbox2.height)
    return abs(bbox1.x -bbox2.x) < max_width and abs(bbox1.y -bbox2.y) < max_height

    

