#! /usr/bin/env python3
import rclpy
# import sys
# sys.path.append('/home/abhijeet/Documents/ros2_ws/src/object_detection_python/object_detection_python/object_detector')
from object_detection_python.object_detector.object_detector import ObjectDetector

def main(args=None):
    rclpy.init(args=args)
    obj = ObjectDetector()
    rclpy.spin(obj)
    obj.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
