import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
from geometry_msgs.msg import Point
import pyproj

class GpsToUtmNode(Node):
    def __init__(self):
        super().__init__('gps_to_utm_node')
        self.subscription = self.create_subscription(
            NavSatFix,
            '/gps',  # Change topic name as needed
            self.gps_callback,
            10
        )
        self.publisher = self.create_publisher(Point, 'utm_coordinates', 10)
        self.geodetic_to_utm = pyproj.Proj(proj='utm', zone=43, ellps='WGS84', south=False)  # Adjust UTM zone accordingly

    def gps_callback(self, msg):
        lat, lon, alt = msg.latitude, msg.longitude, msg.altitude
        x, y = self.geodetic_to_utm(lon, lat)

        utm_point = Point()
        utm_point.x = x
        utm_point.y = y
        utm_point.z = alt  # Using altitude from NavSatFix

        self.publisher.publish(utm_point)
        self.get_logger().info(f'Converted GPS ({lat}, {lon}, {alt}) to UTM ({x}, {y}, {alt})')


def main(args=None):
    rclpy.init(args=args)
    node = GpsToUtmNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
