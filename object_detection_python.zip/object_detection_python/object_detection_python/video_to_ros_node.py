import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import time

class VideoPublisherNode(Node):
    def __init__(self):
        super().__init__('video2ros')

        # Declare and fetch parameters
        self.declare_parameter('video_source','/home/abhijeet/Documents/ros2_ws/src/object_detection_python/video/street-video.mp4')  # make it 0 for camera (/video0)
        self.declare_parameter('fps', 30)
        self.declare_parameter('image_topic', '/right_camera/image_raw')

        self.video_source = self.get_parameter('video_source').get_parameter_value().string_value
        self.fps = self.get_parameter('fps').get_parameter_value().integer_value
        self.image_topic = self.get_parameter('image_topic').get_parameter_value().string_value

        # Initialize video capture
        self.cap = cv2.VideoCapture(self.video_source)
        if not self.cap.isOpened():
            self.get_logger().error(f"Failed to open video source: {self.video_source}")
            rclpy.shutdown()    

        # Set up publisher
        self.image_publisher = self.create_publisher(Image, self.image_topic, 10)
        self.bridge = CvBridge()

        # Set timer for publishing frames
        self.timer_period = 1.0 / self.fps
        self.timer = self.create_timer(self.timer_period, self.publish_frame)

    def publish_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warning("End of video stream or cannot fetch frame.")
            rclpy.shutdown()
            return

        # Convert OpenCV frame to ROS Image message
        image_msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')

        # Publish the image
        self.image_publisher.publish(image_msg)
        self.get_logger().info(f"Published frame at {time.time()}.")

    def destroy_node(self):
        self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)

    node = VideoPublisherNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down Video Publisher Node.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
