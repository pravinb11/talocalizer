import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from autonovus_msgs.msg import ObjectDetection
from autonovus_msgs.msg import BoundingBox
from ultralytics import YOLO
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np
from PIL import Image as PILImage
# import sys
# sys.path.append('/home/abhijeet/Documents/ros2_ws/src/object_detection_python/object_detection_python/utils')
from object_detection_python.utils.utils import find_string_index
from object_detection_python.utils.utils import if_boxes_overlap
import time

class ObjectDetector(Node):

    def __init__(self):
        super().__init__('object_detector')
        # Params
        self.declare_parameter('debug_mode',rclpy.Parameter.Type.BOOL)
        self.declare_parameter('model_path', rclpy.Parameter.Type.STRING)
        self.declare_parameter('camera_subscriber', rclpy.Parameter.Type.STRING)
        self.declare_parameter('target_class_list', rclpy.Parameter.Type.STRING_ARRAY)
        
        self.debug = self.get_parameter('debug_mode').value
        model_path = self.get_parameter('model_path').value
        self.camera_subscriber = self.get_parameter('camera_subscriber').value
        self.target_class_list = self.get_parameter('target_class_list').value

        self.get_logger().info("debug mode set to %s" % str(self.debug))
        self.get_logger().info("model path taken %s" % str(model_path))
        self.get_logger().info("camera subscription topic taken %s" % str(self.camera_subscriber))
        self.get_logger().info("target class list provided %s" % str(self.target_class_list))

        # Pub & Subs
        self.od_pub_ = self.create_publisher(ObjectDetection,'/object_detection',10)
        self.subscription = self.create_subscription(Image,self.camera_subscriber,self.image_callback,10)
        
        # Member Functions
        self.yolo_model = YOLO(model_path)
        self.train_class_dict = self.yolo_model.names
        self.bridge = CvBridge()
        self.cross_id_dict = self.cal_cross_id_dictionary()
        self.post_proc_person_idx = []
        self.post_proc_gun_idx = []
        
        #Debug sections
        if(self.debug):
            self.model_img_pub_ = self.create_publisher(Image,'/model_output/image_raw', 10)
    
    def cal_cross_id_dictionary(self):
        if(self.debug):
            self.get_logger().info("traget class list: %s " % str(self.target_class_list))
        cross_id_dict = {key: -1 for key in self.train_class_dict}
        for key in self.train_class_dict:
            assocated_id = find_string_index(self.target_class_list,self.train_class_dict[key])
            if(assocated_id == -1):
                self.get_logger().fatal("Unable to find %s in the target class list!!!" % self.train_class_dict[key])
                exit()
            else:
                cross_id_dict[key] = assocated_id
        if(self.debug):
            self.get_logger().info("cross_id_dictionary '{train_id:traget_id}': %s " % str(cross_id_dict))
        
        return cross_id_dict

    def post_process_od_msg(self,od_msg):
        for gun_idx in self.post_proc_gun_idx:
            for prs_idx in self.post_proc_person_idx:
                if(if_boxes_overlap(od_msg.bboxes[prs_idx],od_msg.bboxes[gun_idx])):
                    od_msg.bboxes[prs_idx].label = "Person-with-gun"
                    od_msg.bboxes[prs_idx].id = 19
        return od_msg

    def yolo_to_od_msg(self,boxes,ids,cnf,img_header):
        od_msg = ObjectDetection()
        if(len(boxes) < 1):
            return od_msg
        else:
            # box[0] = x_min, box[1] = y_min, box[2] = x_max, box[3] = y_max
            for idx, box in enumerate(boxes):
                bb_msg = BoundingBox()
                bb_msg.conf = float(cnf[idx])
                bb_msg.x = int((box[0] + box[2])/2)
                bb_msg.y = int((box[1] + box[3])/2)
                bb_msg.height = int(abs(box[1] - box[3]))
                bb_msg.width = int(abs(box[0] - box[2]))
                bb_msg.id = int(self.cross_id_dict[ids[idx]]) #int(ids[idx])
                bb_msg.label = self.train_class_dict[ids[idx]]
                od_msg.bboxes.append(bb_msg)
                od_msg.header = img_header

                if(bb_msg.id == 12 or bb_msg.id == 23): # 12 - Gun , 23 - Short-gun
                    self.post_proc_gun_idx.append(idx)

                if(bb_msg.id == 18):                    # 18 - Person
                    self.post_proc_person_idx.append(idx)
            
            if(len(self.post_proc_gun_idx) > 0):
                od_msg = self.post_process_od_msg(od_msg)

            self.post_proc_gun_idx = []
            self.post_proc_person_idx = []
       
        return od_msg

    def image_callback(self,msg):
        # p1 = time.time()
        img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
        # p2 = time.time()
        # print("msg conversion to cv2:",(p2-p1)* 10 **-3, " ms")
        results = None
        # p3 = time.time()
        if(self.debug):
            results = self.yolo_model.predict(img, verbose=True)
        else:
            results = self.yolo_model.predict(img, verbose=False)
        # p4 = time.time()
        # print("inference time:",(p4-p3)* 10 **-3, " ms")
        # p5 = time.time()
        result = results[0]
        im_array = result.plot()
        image_bgr = np.array(PILImage.fromarray(im_array))
        ros_image_msg = self.bridge.cv2_to_imgmsg(image_bgr) 
        
        boxes = result.boxes.xyxy.cpu().numpy()
        ids = result.boxes.cls.cpu().numpy()
        cnf = result.boxes.conf.cpu().numpy()
        od_msg = self.yolo_to_od_msg(boxes,ids,cnf,msg.header)
        # p6 = time.time()
        # print("yolo result to od_msg generation time:",(p6-p5)* 10 **3, " ms")
        self.od_pub_.publish(od_msg)
        if(self.debug):
            self.model_img_pub_.publish(ros_image_msg)
        
