#!/usr/bin/env python3
 
import sys
import numpy as np
import cupy as cp
import cv2
 
np.float = np.float64  # temp fix for following import suggested at https://github.com/eric-wieser/ros_numpy/issues/37
np.bool = np.bool_
import PIL
import rclpy
from rclpy.node import Node
# from rclpy.parameter import Parameter
from sensor_msgs.msg import Image, CameraInfo, CompressedImage
from cv_bridge import CvBridge
 
from semantic_sensor.image_parameters import ImageParameter
from ultralytics import YOLO
 
from autonovus_msgs.msg import TMMCameraChannelInfo
import time
import asyncio
from ament_index_python.packages import get_package_share_directory
import os


class SemanticSegmentationNode(Node):
    def __init__(self, sensor_name):
        super().__init__('semantic_segmentation_node')
        """Get parameter from server, initialize variables and semantics, register publishers and subscribers.
 
        Args:
            sensor_name (str): Name of the sensor in the ros param server.
        """
        self.param: ImageParameter = ImageParameter()
        self.param.feature_config.input_size = [80, 160]
 
        # Get parameters from ROS parameter server
 
        self.declare_parameter(sensor_name, "default_value")
        self.declare_parameter(f"{sensor_name}.channels", ['chair', 'sofa', 'person', 'book'])
        self.declare_parameter(f"{sensor_name}.fusion_methods", ['exponential', 'exponential', 'exponential'])
        self.declare_parameter(f"{sensor_name}.publish_topic", 'semantic_image')
        self.declare_parameter(f"{sensor_name}.publish_image_topic", 'semantic_image_debug')
        self.declare_parameter(f"{sensor_name}.publish_camera_info_topic", 'semantic_image_info')
        self.declare_parameter(f"{sensor_name}.publish_fusion_info_topic", 'semantic_image_fusion_info')
        self.declare_parameter(f"{sensor_name}.data_type", 'image')
        self.declare_parameter(f"{sensor_name}.semantic_segmentation", True)
        self.declare_parameter(f"{sensor_name}.feature_extractor", True)
        self.declare_parameter(f"{sensor_name}.segmentation_model", 'best.pt')
        self.declare_parameter(f"{sensor_name}.show_label_legend", False)
        self.declare_parameter(f"{sensor_name}.image_topic", '/camera/image_raw')
        self.declare_parameter(f"{sensor_name}.camera_info_topic", '/camera/image/camera_info')
        self.declare_parameter(f"{sensor_name}.resize", 1.0)
        self.declare_parameter(f"{sensor_name}.traversable_class_ids", [0, 1, 2, 3, 4])
        self.declare_parameter(f"{sensor_name}.stairs_class_id", [0])
 
 
        if self.has_parameter(sensor_name):
            config = self.get_parameters_by_prefix(sensor_name)
 
            config_dict = {}
            for param_name, param_value in config.items():
                keys = param_name.split('.')
                d = config_dict
                for key in keys[:-1]:
                    if key not in d:
                        d[key] = {}
                    d = d[key]
                d[keys[-1]] = param_value.value
 
            # Now pass this structured config_dict to ImageParameter.from_dict
            self.param = ImageParameter.from_dict(config_dict)
 
        else:
            self.get_logger().warn(f"Parameter '{sensor_name}' not found. Using default parameters.")
 
        self.semantic_model = None
        self.od_model = None   ## abhijeet added
        self.initialize_semantics()
 
        # Setup pointcloud creation
        self.cv_bridge = CvBridge()
        self.p = None
        self.header = None
        self.register_sub_pub()
        self.prediction_img = None
        self.im = None
        self.img_received = False
 
        # Buffer to store the latest compressed image message
        self.latest_compressed_msg = None
 
    def initialize_semantics(self):
        if self.param.semantic_segmentation:
            # self.semantic_model = YOLO(self.param.segmentation_model)
            __package_path = get_package_share_directory('semantic_sensor')
            __model_path = os.path.join(__package_path, self.param.segmentation_model)
            self.semantic_model = YOLO(__model_path,task = 'segment')#(self.param.segmentation_model)
            self.od_model = YOLO(__model_path,task = 'detect') ## abhijeet added


    def register_sub_pub(self):
        """Register publishers and subscribers."""
        if self.param.camera_info_topic:
            self.create_subscription(
                CameraInfo,
                "/left_camera/image/camera_info",
                self.image_info_callback,
                2
            )
        
        self.get_logger().info(f"Image topic being used: {self.param.image_topic}")
   
        if "compressed" in self.param.image_topic:
            self.compressed = True
            self.create_subscription(
                CompressedImage,
                "/left_camera/image/compressed",
                self.compressed_fast_buffer_callback,
                2
            )
            self.create_subscription(
                CompressedImage,
                "/right_camera/image/compressed_fast",
                self.image_callback,
                2
            )
        else:
            self.compressed = False
            self.create_subscription(
                Image,
                self.param.image_topic,
                self.image_callback,
                10
            )
 
        # New publisher for compressed_fast topic
        self.compressed_fast_pub = self.create_publisher(
            CompressedImage,
            "/right_camera/image/compressed_fast",
            2
        )
        # Timer for 30 Hz publishing
        self.compressed_fast_timer = self.create_timer(
            1 / 50.0,  # Period in seconds for 30 Hz
            self.compressed_fast_timer_callback)
 
        # Publishers
        if self.param.semantic_segmentation:
            self.seg_pub = self.create_publisher(
                Image,
                'semantic_image/compressed',
                2
            )  # publishes semantic image
            self.seg_im_pub = self.create_publisher(
                Image,
                'semantic_image_new',
                2
            )
            self.timer = self.create_timer(0.02, self.timer_callback)  # 50 Hz timer
 
        self.channel_info_pub = self.create_publisher(
            TMMCameraChannelInfo,
            "/channel_info",
            2
        )
    
 
    def compressed_fast_buffer_callback(self, msg):
        """Callback to store the latest /right_camera/image/compressed message."""
        self.latest_compressed_msg = msg
        print("image_recieved:")
        # print(f"msg",self.latest_compressed_msg)
 
    def compressed_fast_timer_callback(self):
        """Timer callback to publish messages at 30 Hz."""
        if self.latest_compressed_msg is not None:
            self.compressed_fast_pub.publish(self.latest_compressed_msg)
 
    def timer_callback(self):
        if self.img_received:
           
            self.process_image(self.im)
            self.publish_segmentation()
            self.publish_segmentation_image()
 
    def image_info_callback(self, msg):
        """Callback for camera info.
 
        Args:
            msg (CameraInfo):
        """
 
        self.p = np.array(msg.p).reshape(3, 4)
        self.height = int(self.param.resize * msg.height)
        self.width = int(self.param.resize * msg.width)
        self.info = msg
        self.p = np.array(msg.p).reshape(3, 4)
        self.p[:2, :3] = self.p[:2, :3] * self.param.resize
        self.info.k = self.p[:3, :3].flatten().tolist()
        self.info.p = self.p.flatten().tolist()
 
    def image_callback(self, rgb_msg):        
        start_time = time.time()  # Start timing the function
 
        if self.p is None:
            return
        if self.compressed:
            image = self.cv_bridge.compressed_imgmsg_to_cv2(rgb_msg)
 
            if self.param.resize is not None:
                image = cv2.resize(image, dsize=(self.width, self.height))
            image = cp.asarray(image)
        
        else:
            image = self.cv_bridge.imgmsg_to_cv2(rgb_msg, desired_encoding="rgb8")
            if self.param.resize is not None:
                image = cv2.resize(image, dsize=(self.width, self.height))
            image = cp.asarray(image)
        self.header = rgb_msg.header
 
        self.im = image.get()
        self.img_received = True
 
        if self.param.semantic_segmentation:
            self.publish_channel_info([f"sem_{c}" for c in self.param.channels], self.channel_info_pub)
        end_time = time.time()  # Start timing the function
 
        # print(f"image_callback took {end_time - start_time:.4f} seconds.")
 
 
 
    def publish_channel_info(self, channels, pub):
        """Publish fusion info."""
        info = TMMCameraChannelInfo()
        info.header = self.header
        info.channels = channels
        pub.publish(info)
 
 
    def process_image(self, image):
        """Depending on setting generate color, semantic segmentation or feature channels.
 
        Args:
            image:
            u:
            v:
            points:
        """
        start_time = time.time()  # Start timing the function
        if self.param.semantic_segmentation:
            self.sem_seg = self.semantic_model.predict(image, retina_masks=True, verbose=True)
            self.od_det = self.od_model.predict(image, verbose=True) ## abhijeet added

            if not self.sem_seg or len(self.sem_seg) == 0:
                raise ValueError("YOLO did not return any results.")
 
            # Extract confidence values and class IDs in a single loop
            class_ids = [int(box.data[0][-1]) for result in self.sem_seg for box in result.boxes]
            masks = [mask_xy for result in self.sem_seg if result.masks is not None for mask_xy in result.masks.data]
 
            # Ensure masks is a PyTorch tensor or handle its structure correctly
            if len(masks) > 0:  # Ensure masks list is not empty
                # Convert the first mask to numpy for shape extraction
                first_mask = masks[0].cpu().numpy()
                height, width = first_mask.shape
                # Initialize a matrix of zeros of the shape of image HxWx2, 0: traversable areas, 1 : stairs
                self.conf_matrix = np.zeros((height, width, 2), dtype=np.float32)
 
                # Iterate through the detected classes and update the confidence matrix
                for class_id, mask_xy in zip(class_ids, masks):  
                    if class_id in self.param.stairs_class_id: # check for stairs class
                        self.conf_matrix[:, :, 1] = np.maximum(self.conf_matrix[:, :, 1], mask_xy.cpu().numpy())
                    elif class_id in self.param.traversable_class_ids:
                        self.conf_matrix[:, :, 0] = np.maximum(self.conf_matrix[:, :, 0], mask_xy.cpu().numpy())
            else:
                height, width = image.shape[:2]
                self.conf_matrix = np.full((height, width, 2), 0, dtype=np.float32)
                print("No masks found in the input.")
            
            
        end_time = time.time()  # Start timing the function
 
        # print(f"process_image took {end_time - start_time:.4f} seconds.")            
 
 
    def publish_segmentation(self):
        img = self.conf_matrix
        seg_msg = self.cv_bridge.cv2_to_imgmsg(img, encoding="passthrough")
        seg_msg.header.frame_id = self.header.frame_id
        seg_msg.header.stamp = self.header.stamp
        self.seg_pub.publish(seg_msg)
 
   
    def publish_segmentation_image(self):
        im_array = self.sem_seg[0].plot()  # plot a BGR numpy array of predictions
        im = PIL.Image.fromarray(im_array[..., ::-1])  # RGB PIL image
        if im.mode != 'RGB':
            im = im.convert('RGB')  # Convert image to RGB mode if it isn't already
 
        im_array = np.array(im)
        seg_msg = self.cv_bridge.cv2_to_imgmsg(im_array, encoding="rgb8")
        seg_msg.header.frame_id = self.header.frame_id
        seg_msg.header.stamp = self.header.stamp
        self.seg_im_pub.publish(seg_msg)       
 
 
 
def main(args=None):
    rclpy.init(args=args)
    if len(sys.argv) < 2:
        print("Please provide the sensor name as an argument.")
        sys.exit(1)
    sensor_name = sys.argv[1]
    semantic_segmentation_node = SemanticSegmentationNode(sensor_name)
    rclpy.spin(semantic_segmentation_node)
    semantic_segmentation_node.destroy_node()
    rclpy.shutdown()
 
 
if __name__ == '__main__':
    main()
 