

int i = 0;
std::mutex m;


void func1()
{
    
    {   
        scoped_lock(m);
        i++;
    }
}

void func2()
{
    {
        scoped_lock(m);
        i--;
    }
}


int main()
{
    
    thre

    
}