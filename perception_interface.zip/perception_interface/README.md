# Perception Interface
This module processes object detections, tracks candidates over time, scores them based on multiple factors, and triggers actions when confidence thresholds are met. It acts as an intelligent filter between object detection and navigation systems. During exploration, it monitors for specific object classes (defined by context) and generates triggers when suitable targets are found with sufficient confidence.

## Architecture

```
Object Detections → Context Filter → Spatial Validation → CandidateTracking → Scoring → Decision → Trigger
```

### Core Components

1. **Context Manager** - Manages search contexts and target classes
2. **Spatial Validator** - Validates detections based on distance and reachability
3. **Candidate Tracker** - Tracks objects over time with state management
4. **Scoring Engine** - Evaluates candidates using multiple factors
5. **Decision Engine** - Makes trigger decisions based on scoring and conditions

## How It Works

### 1. Filtering Pipeline

#### Context Filtering
- **Primary classes**: Main target objects (e.g., "door", "stairs_up")
- **Secondary classes**: Supporting objects (e.g., "exit_sign", "arrow_up")
- **Confidence threshold**: Minimum detection confidence required
- **Class matching**: Only objects in the active context are processed

#### Spatial Validation
- **Distance filtering**: Objects beyond `max_distance` are rejected
- **Robot pose tracking**: Uses TF2 to calculate distances in real-time
- **Costmap integration**: Checks if target locations are reachable
- **Reachability scoring**: Combines distance and obstacle information

### 2. Tracking System

Objects are tracked through multiple detection frames using a state machine:

```
TENTATIVE → CONFIRMED → COASTING → DELETED
```

- **TENTATIVE**: New detections, need multiple hits to confirm
- **CONFIRMED**: Stable tracks meeting minimum hit requirements
- **COASTING**: Recently missed but still viable (handles occlusions)
- **DELETED**: Lost tracks that are removed from consideration

#### Association Logic
- Detections are associated with existing tracks based on:
  - Same object class
  - Spatial proximity (within `max_association_distance`)

### 3. Scoring System

Each confirmed track receives a composite score from four main factors:

#### Base Factors (Weighted)
1. **Confidence Factor** (weight: 0.25-0.35)
   - Average detection confidence over recent history
   - Higher confidence = higher score

2. **Distance Factor** (weight: 0.25-0.35)
   - Exponential decay: closer objects score higher
   - Formula: `exp(-2.0 * distance / max_distance)`

3. **Persistence Factor** (weight: 0.20-0.25)
   - How consistently the object has been detected
   - Based on detection rate over time

4. **Stability Factor** (weight: 0.20-0.25)
   - Position variance over recent detections
   - Lower variance = higher stability = higher score

#### Score Modifiers
- **Time-based boost**: Scores increase slightly after prolonged search
- **High confidence burst**: 10% bonus for consistently very high confidence
- **Stability bonus**: 5% bonus for extremely stable detections
- **Class penalty**: Secondary classes get 10% penalty vs primary classes

#### Final Score Calculation
```cpp
weighted_sum = (confidence_weight * confidence_factor) + 
               (distance_weight * distance_factor) + 
               (persistence_weight * persistence_factor) + 
               (stability_weight * stability_factor)

base_score = weighted_sum / total_weights
final_score = clamp(base_score * modifiers, 0.0, 1.0)
```

### 4. Decision Making

The system triggers when sufficient conditions are met (minimum 2 by default):

#### Trigger Conditions

1. **Score Threshold** 
   - Score ≥ `min_trigger_score` (default: 0.75)
   - Can use adaptive thresholds that decrease over time

2. **Urgency Condition** (Immediate Trigger)
   - Distance < `urgent_distance` (default: 1.5m)
   - Overrides other conditions for safety

3. **Consistency Condition**
   - `consistent_frames_percentage` ≥ `consistency_threshold` (default: 0.5)
   - Tracks how often recent scores were above threshold

4. **High Confidence Burst**
   - Last 5 detections all above context confidence threshold
   - Indicates very reliable detection

5. **High Persistence**
   - Persistence score > 0.8
   - Object has been consistently detected over time

#### Adaptive Thresholds (Optional)
When enabled, trigger thresholds decrease over time:
- **0-10 seconds**: 0.85 threshold
- **10-30 seconds**: 0.75 threshold  
- **30-60 seconds**: 0.65 threshold
- **60+ seconds**: 0.55 threshold

This ensures the robot makes progress even in challenging environments.

## Configuration

### Context Configuration (`perception_interface.yaml`)

```yaml
# Example context for finding doors
outdoor_to_indoor:
  primary_classes: ["door", "entrance", "main_entrance"]
  secondary_classes: ["entrance_sign", "building_name"]
  confidence_threshold: 0.7
  max_distance: 5.0
  weight_confidence: 0.3
  weight_distance: 0.3
  weight_persistence: 0.2
  weight_stability: 0.2
```

### Key Parameters

#### Global Parameters
- `min_confidence`: Global minimum confidence threshold
- `min_distance`: Global minimum distance threshold
- `boost_score_after_time`: Time after which scores get boosted

#### Tracking Parameters
- `max_association_distance`: Maximum distance for track association (1.0m)
- `max_coasting_cycles`: How long tracks survive without detections (3 cycles)
- `min_hits_to_confirm`: Detections needed to confirm a track (3)
- `detection_history_size`: Maximum history length (30)

#### Triggering Parameters
- `urgent_distance`: Distance for immediate triggers (1.5m)
- `min_trigger_score`: Minimum score for triggering (0.75)
- `consistency_threshold`: Consistency percentage needed (0.5)
- `min_conditions`: Minimum conditions that must be met (2)

## Usage

### Building the Package

```bash
# In your ROS2 workspace
colcon build --packages-select perception_interface
source install/setup.bash
```

### Using the Launch File

```bash
# Launch with perception interface launch file
ros2 launch perception_interface perception_interface.launch.py

# With custom parameters
ros2 launch perception_interface perception_interface.launch.py config_file:=/path/to/config.yaml
```

### Service Interface

#### Start Monitoring
```bash
# Start monitoring for doors
ros2 service call /perception_interface/start_monitoring autonovus_msgs/srv/StartPIMonitoring "{context_name: 'outdoor_to_indoor', timeout: 60.0}"
```

#### Stop Monitoring
```bash
# Stop current monitoring
ros2 service call /perception_interface/stop_monitoring autonovus_msgs/srv/StopPIMonitoring "{reason: 'manual_stop'}"
```

### Topics

#### Subscribed Topics
- `/object_detector/detections` (autonovus_msgs/ObjectDetection) - Object detection input
- `/local_costmap` (nav_msgs/OccupancyGrid) - Navigation costmap for reachability

#### Published Topics
- `/perception_interface/best_target` (autonovus_msgs/PITarget) - Triggered target location
- `/perception_interface/status` (autonovus_msgs/PIStatus) - Current monitoring status


## Testing

### Running Unit Tests

```bash
# Build with tests
colcon build --packages-select perception_interface 

# Run all tests
colcon test --packages-select perception_interface --event-handler=console_direct+



## Monitoring and Debugging

### Status Monitoring
```bash
# Watch current status
ros2 topic echo /perception_interface/status

# Monitor triggered targets
ros2 topic echo /perception_interface/best_target
```

### Common Issues

1. **No triggers generated**: Check confidence thresholds, ensure objects are within max_distance
2. **False triggers**: Increase min_conditions, adjust scoring weights
3. **TF errors**: Verify frame_id configurations match your robot setup
4. **Performance issues**: Reduce detection_history_size, check association distances