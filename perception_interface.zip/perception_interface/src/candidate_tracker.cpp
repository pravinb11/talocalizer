#include "perception_interface/candidate_tracker.hpp"
#include <algorithm>
#include <cmath>
#include <set>

namespace perception_interface
{

// TrackedCandidate Implementation
TrackedCandidate::TrackedCandidate(
  const Detection & detection,
  const ValidationResult & validation_data,
  const std::chrono::steady_clock::time_point & current_time,
const params::TrackingParams & config)
  : track_id_(next_track_id_++),
    class_name_(detection.class_name),
    state_(TrackState::TENTATIVE),
    first_seen_(current_time),
    last_seen_(current_time),
    persistence_score_(0.0),
    stability_score_(0.0),
    consistent_frames_perc_(0.0),
    missed_detections_(0),
    latest_detection_(detection),
    latest_validation_(validation_data),
    config_(config)
{
  // Initialize with first detection
  update(detection, validation_data, current_time);
}

void TrackedCandidate::update(
  const Detection & detection,
  const ValidationResult & validation_data,
  const std::chrono::steady_clock::time_point & current_time)
{
  last_seen_ = current_time;
  latest_detection_ = detection;
  latest_validation_ = validation_data;

  if(detection_history_.size() >= config_.detection_history_size)
  {
    // Remove oldest detection if we exceed history size
    detection_history_.pop_front();
    pose_history_.pop_front();
    confidence_history_.pop_front();
  }
  // Update history buffers
  detection_history_.push_back(detection);
  pose_history_.push_back(detection.pose);
  confidence_history_.push_back(detection.confidence);
  
  // Reset missed counter on successful update
  missed_detections_ = 0;
  
  // Update computed properties
  updatePersistence();
  updateStability();

}

void TrackedCandidate::markMissed(const std::chrono::steady_clock::time_point & current_time)
{
  last_seen_ = current_time;
  missed_detections_++;
  
  // Update state
  if (state_ == TrackState::CONFIRMED && missed_detections_ > 0)
  {
    state_ = TrackState::COASTING;
  }
  
  // Update persistence (will decrease due to miss)
  updatePersistence();
}

void TrackedCandidate::updatePersistence()
{
  if (detection_history_.size() < 2)
  {
    persistence_score_ = 0.0;
    return;
  }
  
  // Calculate persistence over recent history
  // Count how many frames had detections vs total frames
  auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
    last_seen_ - first_seen_).count() / 1000.0;  // seconds
  
  if (duration <= config_.max_time_gap)
  {
    // Detections per second
    double detection_rate = static_cast<double>(detection_history_.size()) / duration;
    // Assuming 30Hz detector, normalize to [0,1]
    persistence_score_ = std::min(1.0, detection_rate / 30.0);
  }
  else
  {
    // If too long since first detection, reset persistence
    persistence_score_ = 0.0;
  }
}

void TrackedCandidate::updateStability()
{
  if (pose_history_.size() < 3)
  {
    stability_score_ = 1.0;  // Not enough data, assume stable
    return;
  }
  
  // Calculate position variance over recent poses
  double sum_x = 0.0, sum_y = 0.0;
  double sum_x2 = 0.0, sum_y2 = 0.0;
  
  size_t n = std::min(pose_history_.size(), size_t(10));  // Last 10 poses
  for (size_t i = pose_history_.size() - n; i < pose_history_.size(); ++i)
  {
    double x = pose_history_[i].pose.position.x;
    double y = pose_history_[i].pose.position.y;
    sum_x += x;
    sum_y += y;
    sum_x2 += x * x;
    sum_y2 += y * y;
  }
  
  double mean_x = sum_x / n;
  double mean_y = sum_y / n;
  double var_x = (sum_x2 / n) - (mean_x * mean_x);
  double var_y = (sum_y2 / n) - (mean_y * mean_y);
  
  // Convert variance to stability score (lower variance = higher stability)
  double total_variance = var_x + var_y;
  stability_score_ = 1.0 / (1.0 + total_variance);
}

// CandidateTracker Implementation
CandidateTracker::CandidateTracker(const params::TrackingParams & config)
  : config_(config)
{
}

std::map<int, std::shared_ptr<TrackedCandidate>> CandidateTracker::update(
  const std::vector<std::pair<Detection, ValidationResult>> & validated_detections,
  const std::chrono::steady_clock::time_point & current_time)
{
  // Step 1: Update track states and mark all as potentially missed
  RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
    "[1] Updating tracks with %zu validated detections With Current TRackers as %zu",
    validated_detections.size(),
    tracks_.size()
    );
  for (auto & [track_id, track] : tracks_)
  {
    track->markMissed(current_time);
    RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
      "[1.1] Marking track %d as potentially missed, state: %s",
      track_id,
      trackStateToString(track->getState()).c_str());
  }
  // Step 2: For each detection, find the best matching track
  std::set<int> updated_tracks;
  
  for (const auto & [detection, validation] : validated_detections)
  {
    // Find the closest track of the same class
    int best_track_id = -1;
    double best_distance = std::numeric_limits<double>::max();
    
    for (const auto & [track_id, track] : tracks_)
    {
      // Skip if already updated this cycle
      if (updated_tracks.find(track_id) != updated_tracks.end())
      {
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
          "[2] Skipping already updated track %d for detection at (%.2f, %.2f)",
          track_id,
          validation.pose_in_map.pose.position.x,
          validation.pose_in_map.pose.position.y);
        continue;
      }
      
      // Check class compatibility
      if (track->getClassName() != detection.class_name)
      {
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
          "[2] Skipping track %d (class '%s') for detection class '%s'",
          track_id,
          track->getClassName().c_str(),
          detection.class_name.c_str());
        continue;
      }
      
      // Calculate distance in map frame
      double dx = validation.pose_in_map.pose.position.x - 
                  track->getLatestDetection().pose.pose.position.x;
      double dy = validation.pose_in_map.pose.position.y - 
                  track->getLatestDetection().pose.pose.position.y;
      double distance = std::sqrt(dx * dx + dy * dy);
      
      // Check if this is the best match so far
      if (distance < best_distance && distance < config_.max_association_distance)
      {
        best_distance = distance;
        best_track_id = track_id;
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
          "[2] Found better match: track %d (class '%s') with distance %.2f",
          best_track_id,
          track->getClassName().c_str(),
          best_distance);
      }
    }
    
    // Update the best matching track or create a new one
    if (best_track_id >= 0)
    {
      // Update existing track
      tracks_[best_track_id]->update(detection, validation, current_time);
      updated_tracks.insert(best_track_id);
      
      RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
        "[3] Updated track %d with detection at (%.2f, %.2f), distance: %.2f",
        best_track_id,
        validation.pose_in_map.pose.position.x,
        validation.pose_in_map.pose.position.y,
        best_distance);
    }
    else
    {
      // No matching track found, create a new one
      createNewTrack(detection, validation, current_time);
    }
  }
  
  // Step 3: Update states and prune dead tracks
  updateTrackStates(current_time);
  pruneDeadTracks();
  
  return tracks_;
}

void CandidateTracker::createNewTrack(
  const Detection & detection,
  const ValidationResult & validation_data,
  const std::chrono::steady_clock::time_point & current_time)
{
  auto new_track = std::make_shared<TrackedCandidate>(
    detection, validation_data, current_time, config_);

  tracks_[new_track->getTrackId()] = new_track;
  
  RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
    "[3] Created new track %d for class '%s' at position (%.2f, %.2f)",
    new_track->getTrackId(),
    detection.class_name.c_str(),
    validation_data.pose_in_map.pose.position.x,
    validation_data.pose_in_map.pose.position.y);
}

void CandidateTracker::updateTrackStates(
  const std::chrono::steady_clock::time_point & current_time)
{
  for (auto & [track_id, track] : tracks_)
  {
    // Update state based on missed detections
    RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
      "[U.1] Updating state for track %d (state: %s, missed: %d) | Detection History Size: %zu | Min Hits to Confirm: %d | Max Coasting Cycles: %d",
      track_id,
      trackStateToString(track->getState()).c_str(),
      track->missed_detections_,
      track->detection_history_.size(),
      config_.min_hits_to_confirm,
      config_.max_coasting_cycles);

    if (track->missed_detections_ == 0)
    {
      // Just updated
      if (track->getState() == TrackState::TENTATIVE && 
          track->detection_history_.size() >= config_.min_hits_to_confirm)
      {
        track->state_ = TrackState::CONFIRMED;
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"), "[U.2] Updated Confired from Tentative | detection history > min hits to confirm");
      }
      else if (track->getState() == TrackState::COASTING)
      {
        track->state_ = TrackState::CONFIRMED;
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"), "[U.2] Updated Confired from Coasting | current state was COASTING");
      }
      else
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"), "[U.2] No state change for track %d | current state was %s", 
          track_id, trackStateToString(track->getState()).c_str());
    }
    else if (track->missed_detections_ > 0)
    {
      // Missed in this cycle
      if (track->getState() == TrackState::CONFIRMED)
      {
        track->state_ = TrackState::COASTING;
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"), "[U.2] Updated to COASTING from CONFIRMED | missed detections: %d", 
          track->missed_detections_);
      }
      
      // Check if coasting too long
      if (track->missed_detections_ > config_.max_coasting_cycles)
      {
        track->state_ = TrackState::DELETED;
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"), "[U.2] Track %d marked as DELETED after %d missed detections", 
          track_id, track->missed_detections_);
      }
      else
        RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"), "[U.2] No state change for track %d | current state was %s", 
          track_id, trackStateToString(track->getState()).c_str());
      
    }
  }
}

void CandidateTracker::pruneDeadTracks()
{
  // Remove deleted tracks
  for (auto it = tracks_.begin(); it != tracks_.end();)
  {
    if (it->second->getState() == TrackState::DELETED)
    {
      RCLCPP_DEBUG(rclcpp::get_logger("CandidateTracker"),
        "[4] Removing track %d (state: DELETED, missed: %d)",
        it->first,
        it->second->missed_detections_);
      
      it = tracks_.erase(it);
    }
    else
    {
      ++it;
    }
  }
}



}  // namespace perception_interface