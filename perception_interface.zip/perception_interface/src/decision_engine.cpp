#include "perception_interface/decision_engine.hpp"

namespace perception_interface
{

  DecisionEngine::DecisionEngine(
      const params::TriggeringParams &config,
      std::shared_ptr<ContextManager> context_manager,
      rclcpp::Node::SharedPtr node)
      : context_manager_(context_manager),
        node_(node),
        triggered_(false),
        config_(config)
  {
  }

  std::optional<std::shared_ptr<TrackedCandidate>> DecisionEngine::evaluateTriggerConditions(
      const std::map<int, std::shared_ptr<TrackedCandidate>> &tracks,
      const std::map<int, double> &scores)
  {
    // Don't evaluate if already triggered
    if (triggered_)
    {
      return std::nullopt;
    }

    // Find the best scoring candidate
    if (scores.empty())
    {
      return std::nullopt;
    }

    // Get the best candidate
    auto best_it = std::max_element(scores.begin(), scores.end(),
                                    [](const auto &a, const auto &b)
                                    { return a.second < b.second; });

    if (best_it == scores.end())
    {
      return std::nullopt;
    }

    int best_track_id = best_it->first;
    double best_score = best_it->second;

    // Get the candidate
    auto track_it = tracks.find(best_track_id);
    if (track_it == tracks.end())
    {
      return std::nullopt;
    }

    auto best_candidate = track_it->second;

    // Collect trigger conditions
    std::vector<std::string> trigger_reasons;

    // 1. Check score threshold

    double required_score = config_.use_adaptive_thresholds ? getAdaptiveThreshold() : config_.min_trigger_score;
    if (config_.use_adaptive_thresholds)
      RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"),
                   "Using adaptive thresholds based on elapsed time %f | Min Threshold: %f", required_score, config_.min_trigger_score);
    else
      RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"),
                   "Using fixed threshold: %f | Min Threshold: %f", required_score, config_.min_trigger_score);
    if (best_score >= required_score)
    {
      trigger_reasons.push_back(
          "Score " + std::to_string(best_score) + " >= threshold " + std::to_string(required_score));
    }

    // 2. Check temporal consistency
    if (checkConsistencyConditions(*best_candidate)) {
        trigger_reasons.push_back(
            "Consistent frames: " + std::to_string(best_candidate->getConsistentFramesPerc()));
    }

    // 3. Check urgency conditions (very close distance)
    if (checkUrgencyConditions(*best_candidate))
    {
      trigger_reasons.push_back(
          "Urgent: distance " +
          std::to_string(best_candidate->getLatestDetection().distance_to_robot) + "m");

      // Immediate trigger for urgent cases
      RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"),
                  "Triggering due to urgency: %s", trigger_reasons.back().c_str());

      triggered_ = true;
      trigger_time_ = std::chrono::steady_clock::now();
      return best_candidate;
    }

    // 4. Check if we have high confidence burst
    if (checkHighConfidenceBurst(*best_candidate))
    {
      trigger_reasons.push_back("High confidence burst detected");
    }

    // 5. Check persistence
    if (best_candidate->getPersistenceScore() > 0.8)
    {
      trigger_reasons.push_back(
          "High persistence: " + std::to_string(best_candidate->getPersistenceScore()));
    }

    // Need at least min_conditions reasons to trigger (except for urgency)
    if (trigger_reasons.size() >= config_.min_conditions)
    {
      RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"),
                  "Triggering with %zu conditions met:", trigger_reasons.size());
      for (const auto &reason : trigger_reasons)
      {
        RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"), "  - %s", reason.c_str());
      }

      triggered_ = true;
      trigger_time_ = std::chrono::steady_clock::now();
      return best_candidate;
    }
    std::string trigger_reasons_str;
    for (const auto &reason : trigger_reasons)
    {
      trigger_reasons_str += reason + ", ";
    }
    // Log why we didn't trigger
    RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"),
                          "Not triggering: best_score=%.2f, required=%.2f, conditions_met=%zu, reasons=[%s]",
                          best_score, required_score, trigger_reasons.size(),
                          trigger_reasons_str.c_str());

    return std::nullopt;
  }

  double DecisionEngine::getAdaptiveThreshold() const
  {
    // Get elapsed time since monitoring started
    double elapsed_time = context_manager_->getElapsedTime();

    // Find appropriate threshold based on elapsed time
    for (size_t i = 0; i < config_.stage_durations.size(); i++)
    {
      if (elapsed_time <= config_.stage_durations[i])
      {
        return config_.stage_thresholds[i];
      }
    }

    // Fallback (shouldn't reach here)
    return config_.stage_thresholds.back();
  }

  bool DecisionEngine::checkUrgencyConditions(const TrackedCandidate &candidate) const
  {
    // Check if the candidate is very close
    double urgent_distance = config_.urgent_distance; // Should come from parameters

    return candidate.getLatestDetection().distance_to_robot < urgent_distance;
  }

  bool DecisionEngine::checkConsistencyConditions(const TrackedCandidate &candidate) const
  {
    return candidate.getConsistentFramesPerc() >= config_.consistency_threshold;
  }
  
  bool DecisionEngine::checkHighConfidenceBurst(const TrackedCandidate &candidate) const
  {
    const auto &conf_history = candidate.getConfidenceHistory();

    if (conf_history.size() < 5)
    {
      return false;
    }

    // Using the context confidence threshold
    double high_confidence_threshold = context_manager_->getCurrentContext().confidence_threshold;

    // Check last 5 detections
    double max_conf = 0.0;
    for (size_t i = conf_history.size() - 5; i < conf_history.size(); ++i)
    {
      max_conf = std::max(max_conf, conf_history[i]);
    }
    RCLCPP_INFO(rclcpp::get_logger("DecisionEngine"),
                "[HighConfBurst] Track %d - Max confidence in last 5: %f (threshold: %f)",
                candidate.getTrackId(), max_conf, high_confidence_threshold);
    return max_conf > high_confidence_threshold;
  }

  void DecisionEngine::reset()
  {
    triggered_ = false;
    trigger_time_ = std::chrono::steady_clock::time_point();

    RCLCPP_DEBUG(node_->get_logger(), "Decision engine reset");
  }

} // namespace perception_interface