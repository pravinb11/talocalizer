#include "perception_interface/context_manager.hpp"
#include <iostream>

namespace perception_interface
{

ContextManager::ContextManager(const params::PerceptionInterfaceParams & params)
  : params_(params)
{
}

bool ContextManager::activateContext(
  const std::string & context_name,
  const std::vector<std::string> & custom_classes)
{
  // Check if context exists in parameters
  auto it = params_.contexts.find(context_name);
  if (it == params_.contexts.end())
  {
    return false;
  }
  
  // Deactivate any existing context
  deactivateContext();
  
  // Set new active context
  active_context_ = context_name;
  current_context_ = it->second;
  start_time_ = std::chrono::steady_clock::now();
  
  // Set target classes
  target_classes_.clear();
  
  if (!custom_classes.empty())
  {
    // Use custom classes if provided
    for (const auto & class_name : custom_classes)
    {
      target_classes_.insert(class_name);
    }
  }
  else
  {
    // Use configured classes
    for (const auto & class_name : current_context_.primary_classes)
    {
      target_classes_.insert(class_name);
    }
    for (const auto & class_name : current_context_.secondary_classes)
    {
      target_classes_.insert(class_name);
    }
  }
  
  return true;
}

void ContextManager::deactivateContext()
{
  active_context_.clear();
  target_classes_.clear();
  current_context_ = params::ContextParams();
}

bool ContextManager::filterDetection(const Detection & detection) const
{
  // Check if monitoring is active
  if (active_context_.empty())
  {
    return false;
  }
  
  // Check class filter
  if (target_classes_.find(detection.class_name) == target_classes_.end())
  {
    return false;
  }

  std::cout << "filterDetection 3 current conf is " << detection.confidence << " threshold " <<  current_context_.confidence_threshold << std::endl;
  
  // Check confidence threshold
  if (detection.confidence < current_context_.confidence_threshold)
  {
    return false;
  }
  
  // Check distance threshold (if distance is already computed)
  if (detection.distance_to_robot > 0 && 
      detection.distance_to_robot > current_context_.max_distance)
  {
    return false;
  }
  
  return true;
}

double ContextManager::getElapsedTime() const
{
  if (active_context_.empty())
  {
    return 0.0;
  }
  
  auto now = std::chrono::steady_clock::now();
  auto duration = std::chrono::duration_cast<std::chrono::duration<double>>(now - start_time_);
  return duration.count();
}

}  // namespace perception_interface