#include <memory>
#include <rclcpp/rclcpp.hpp>
#include "perception_interface/perception_interface_node.hpp"

int main(int argc, char * argv[])
{
  // Initialize ROS2
  rclcpp::init(argc, argv);
  
  // Create node options for component node
  rclcpp::NodeOptions options;
  
  // Create the perception interface node
  auto node = std::make_shared<perception_interface::PerceptionInterfaceNode>(options);
  node->init(); // Initialize all components and services
  // Create single-threaded executor
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  
  RCLCPP_INFO(node->get_logger(), "Starting Perception Interface Node");
  RCLCPP_INFO(node->get_logger(), "Ready to receive monitoring requests...");
  
  try
  {
    // Spin until shutdown
    executor.spin();
  }
  catch (const std::exception & e)
  {
    RCLCPP_ERROR(node->get_logger(), "Exception in main: %s", e.what());
  }
  
  // Cleanup
  rclcpp::shutdown();
  
  return 0;
}