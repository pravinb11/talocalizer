#include "perception_interface/spatial_validator.hpp"
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <cmath>

namespace perception_interface
{

SpatialValidator::SpatialValidator(
  rclcpp::Node::SharedPtr node,
  const params::PerceptionInterfaceParams & params)
  : node_(node),
    global_frame_id_(params.global.global_frame_id),
    base_frame_id_(params.global.base_frame_id),
    robot_pose_valid_(false),
    costmap_valid_(false)
{
  // Initialize TF2
  tf_buffer_ = std::make_unique<tf2_ros::Buffer>(node_->get_clock());
  tf_listener_ = std::make_unique<tf2_ros::TransformListener>(*tf_buffer_);
  
  // Create costmap subscriber
  costmap_sub_ = node_->create_subscription<nav_msgs::msg::OccupancyGrid>(
    params.global.costmap_topic,
    rclcpp::QoS(1).transient_local(),
    std::bind(&SpatialValidator::costmapCallback, this, std::placeholders::_1));
  
  // Initialize robot pose
  robot_pose_.header.frame_id = global_frame_id_;
  robot_pose_.pose.position.x = 0.0;
  robot_pose_.pose.position.y = 0.0;
  robot_pose_.pose.position.z = 0.0;
  robot_pose_.pose.orientation.w = 1.0;
  
  RCLCPP_INFO(node_->get_logger(), 
    "SpatialValidator initialized with frames: %s -> %s",
    global_frame_id_.c_str(), base_frame_id_.c_str());
}

bool SpatialValidator::getRobotPose(geometry_msgs::msg::PoseStamped & pose)
{
  try
  {
    geometry_msgs::msg::TransformStamped transform = tf_buffer_->lookupTransform(
      global_frame_id_,
      base_frame_id_,
      tf2::TimePointZero);
    
    robot_pose_.header.stamp = transform.header.stamp;
    robot_pose_.header.frame_id = global_frame_id_;
    robot_pose_.pose.position.x = transform.transform.translation.x;
    robot_pose_.pose.position.y = transform.transform.translation.y;
    robot_pose_.pose.position.z = transform.transform.translation.z;
    robot_pose_.pose.orientation = transform.transform.rotation;
    
    robot_pose_valid_ = true;
    last_pose_update_time_ = node_->get_clock()->now();
    
    pose = robot_pose_;

    std::cout << "Received Robot Pose!" << std::endl;
    return true;
  }
  catch (const tf2::TransformException & ex)
  {
    RCLCPP_WARN_THROTTLE(
      node_->get_logger(),
      *node_->get_clock(),
      1000,  // ms
      "Failed to get robot pose from %s to %s: %s", 
      global_frame_id_.c_str(),
      base_frame_id_.c_str(),
      ex.what());
    
    return false;
  }
}

ValidationResult SpatialValidator::validate(
  const Detection & detection,
  const params::ContextParams & context_params)
{
  ValidationResult result;

  std::cout << "Starting to validate via SpatialValidator!" << std::endl;
  
  // Update robot pose if needed (cache for 100ms)
  auto now = node_->get_clock()->now();
  if (!robot_pose_valid_ || 
      (now - last_pose_update_time_).seconds() > 0.1)
  {
    geometry_msgs::msg::PoseStamped current_pose;
    if (!getRobotPose(current_pose))
    {
      result.is_valid = false;
      result.rejection_reasons.push_back("Cannot determine robot pose");
      return result;
    }
  }
  
  // Store the detection pose (already in map frame)
  result.pose_in_map = detection.pose;
  
  // Calculate distance from robot to detection
  result.distance_to_robot = calculateDistance(detection);
  
  // Check if distance is within context limits
  if (result.distance_to_robot > context_params.max_distance)
  {
    result.is_valid = false;
    result.rejection_reasons.push_back(
      "Distance " + std::to_string(result.distance_to_robot) + 
      "m exceeds max " + std::to_string(context_params.max_distance) + "m");
  }
  
  // Check costmap validity if available
  if (costmap_valid_ && local_costmap_)
  {
    bool costmap_clear = checkCostmapValidity(
      detection.pose.pose.position.x,
      detection.pose.pose.position.y);
    
    result.costmap_valid = costmap_clear;
    
    if (!costmap_clear)
    {
      result.is_valid = false;
      result.rejection_reasons.push_back("Position occupied in costmap");
    }
  }
  
  // Calculate reachability score
  result.reachability_score = calculateReachabilityScore(
    result.distance_to_robot,
    result.costmap_valid);
  
  return result;
}

void SpatialValidator::costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  local_costmap_ = msg;
  costmap_valid_ = true;
  
  RCLCPP_DEBUG(
    node_->get_logger(),
    "Updated local costmap: %dx%d, resolution: %.3f",
    msg->info.width,
    msg->info.height,
    msg->info.resolution);
}

double SpatialValidator::calculateDistance(const Detection & detection)
{
  std::cout << "Starting to calculate distance via SpatialValidator!" << std::endl;
  // Ensure we have current robot pose
  if (!robot_pose_valid_)
  {
    geometry_msgs::msg::PoseStamped current_pose;
    getRobotPose(current_pose);
  }
  
  double dx = detection.pose.pose.position.x - robot_pose_.pose.position.x;
  double dy = detection.pose.pose.position.y - robot_pose_.pose.position.y;
  
  return std::sqrt(dx * dx + dy * dy);
}

bool SpatialValidator::checkCostmapValidity(double x, double y) const
{
  if (!local_costmap_)
  {
    return true;  // If no costmap, assume valid
  }
  
  // Transform world coordinates to costmap coordinates
  double origin_x = local_costmap_->info.origin.position.x;
  double origin_y = local_costmap_->info.origin.position.y;
  double resolution = local_costmap_->info.resolution;
  
  int cell_x = static_cast<int>((x - origin_x) / resolution);
  int cell_y = static_cast<int>((y - origin_y) / resolution);
  
  // Check if within costmap bounds
  if (cell_x < 0 || cell_x >= static_cast<int>(local_costmap_->info.width) ||
      cell_y < 0 || cell_y >= static_cast<int>(local_costmap_->info.height))
  {
    // Outside costmap bounds - we can't validate
    return true;
  }
  
  // Get cost value
  int index = cell_y * local_costmap_->info.width + cell_x;
  int8_t cost = local_costmap_->data[index];
  
  // Cost interpretation:
  // 0 = free space
  // 1-252 = varying cost
  // 253 = inflated obstacle
  // 254 = lethal obstacle
  // 255 = unknown
  
  // Consider it valid if not a lethal obstacle
  return cost < 253;
}

double SpatialValidator::calculateReachabilityScore(
  double distance,
  bool costmap_valid) const
{
  // Base score from distance (exponential decay)
  // Closer targets get higher scores
  double distance_score = std::exp(-distance / 5.0);  // 5m scale factor
  
  // Penalize if costmap indicates obstacle
  double costmap_factor = costmap_valid ? 1.0 : 0.5;
  
  return distance_score * costmap_factor;
}

}  // namespace perception_interface