#include "perception_interface/scoring_engine.hpp"
#include <algorithm>
#include <numeric>
#include <cmath>

namespace perception_interface
{

  ScoringEngine::ScoringEngine(std::shared_ptr<ContextManager> context_manager)
      : context_manager_(context_manager)
  {
  }

  std::map<int, double> ScoringEngine::scoreCandidates(
      const std::map<int, std::shared_ptr<TrackedCandidate>> &tracks)
  {
    std::map<int, double> scores;

    for (const auto &[track_id, candidate] : tracks)
    {
      // Only score confirmed tracks
      if (candidate->getState() != TrackState::CONFIRMED)
      {
        RCLCPP_INFO(
            rclcpp::get_logger("ScoringEngine"),
            "Skipping track %d in state %s", track_id,
            trackStateToString(candidate->getState()).c_str());
        continue;
      }

      double score = computeCandidateScore(*candidate);
      RCLCPP_INFO(
          rclcpp::get_logger("ScoringEngine"),
          "Scoring track %d: %f", track_id, score);

      scores[track_id] = score;

      // Update candidate's score history
      if (candidate->score_history_.size() >= candidate->config_.detection_history_size)
      {
        candidate->score_history_.pop_front(); // Maintain fixed size
      }
      candidate->score_history_.push_back(score);

      double high_score_threshold = context_manager_->getCurrentContext().confidence_threshold;
      RCLCPP_INFO(
          rclcpp::get_logger("ScoringEngine"),
          "High score threshold: %f | Current score: %f", high_score_threshold, score);
      if (score >= high_score_threshold)
      {
        // Exponential growth for consistent frames percentage
        candidate->consistent_frames_perc_ = std::min(1.0,
                                                      candidate->consistent_frames_perc_ * 1.2 + 0.1);
      }
      else
      {
        // Decay for breaking the streak
        candidate->consistent_frames_perc_ *= 0.5;
      }
      // Track best score
      if (score > candidate->best_score_)
      {
        candidate->best_score_ = score;
      }
    }

    return scores;
  }

  double ScoringEngine::computeCandidateScore(const TrackedCandidate &candidate)
  {
    // Get base factors
    auto base_factors = calculateBaseFactors(candidate);
    RCLCPP_INFO(
      rclcpp::get_logger("ScoringEngine"),
      "Scoring[ %d]Base factors: confidence=%f, distance=%f, persistence=%f, stability=%f",
      candidate.getTrackId(),
      base_factors["confidence"],
      base_factors["distance"],
      base_factors["persistence"],
      base_factors["stability"]);
    // Get weights from current context
    const auto &context = context_manager_->getCurrentContext();

    // Calculate weighted score using the four main factors
    double weighted_sum = 0.0;
    weighted_sum += context.weight_confidence * base_factors["confidence"];
    weighted_sum += context.weight_distance * base_factors["distance"];
    weighted_sum += context.weight_persistence * base_factors["persistence"];
    weighted_sum += context.weight_stability * base_factors["stability"];

    double weight_sum = context.weight_confidence + context.weight_distance +
                        context.weight_persistence + context.weight_stability;

    // Normalize
    double base_score = weight_sum > 0 ? weighted_sum / weight_sum : 0.0;
    RCLCPP_INFO(
      rclcpp::get_logger("ScoringEngine"),
      "Base score before modifiers: %f", base_score);
    // Apply modifiers
    double final_score = applyModifiers(base_score, candidate);
    RCLCPP_INFO(
      rclcpp::get_logger("ScoringEngine"),
      "Final score after modifiers: %f", final_score);
    // Ensure score is in [0, 1]
    return std::clamp(final_score, 0.0, 1.0);
  }

  std::map<std::string, double> ScoringEngine::calculateBaseFactors(
      const TrackedCandidate &candidate)
  {
    std::map<std::string, double> factors;

    // 1. Confidence factor - average confidence over recent detections
    if (!candidate.getConfidenceHistory().empty())
    {
      double avg_confidence = 0.0;
      size_t count = candidate.getConfidenceHistory().size(); // std::min(candidate.getConfidenceHistory().size(), size_t(10));
      for (size_t i = 0; i < count; ++i)
      {
        avg_confidence += candidate.getConfidenceHistory()[i];
      }
      RCLCPP_INFO(
          rclcpp::get_logger("ScoringEngine"),
          "Track %d - Average confidence: %f over %zu detections",
          candidate.getTrackId(), avg_confidence, count);
      factors["confidence"] = avg_confidence / count;
    }
    else
    {
      factors["confidence"] = 0.0;
    }

    // 2. Distance factor - closer is better (exponential decay)
    double distance = candidate.getLatestDetection().distance_to_robot;
    double max_distance = context_manager_->getCurrentContext().max_distance;
    if (max_distance > 0)
    {
      factors["distance"] = std::exp(-2.0 * distance / max_distance);
    }
    else
    {
      factors["distance"] = 1.0;
    }

    // 3. Persistence factor - how consistently we see this object
    factors["persistence"] = candidate.getPersistenceScore();

    // 4. Stability factor - how stable the position is
    factors["stability"] = candidate.stability_score_;

    return factors;
  }

  double ScoringEngine::applyModifiers(double base_score, const TrackedCandidate &candidate)
  {
    double modified_score = base_score;

    // 1. Time-based penalty
    // As exploration time increases, we become less picky
    // RCLCPP_INFO(
    //     rclcpp::get_logger("ScoringEngine"),
    //     "Applying time-based modifiers for track %d | Boost time: %f", candidate.getTrackId(), context_manager_->getCurrentContext().boost_score_after_time);
    if (context_manager_->getCurrentContext().boost_score_after_time > 0.0)
    {
      double elapsed_time = context_manager_->getElapsedTime();
      
      double boost_time = context_manager_->getCurrentContext().boost_score_after_time;
      RCLCPP_INFO(
          rclcpp::get_logger("ScoringEngine"),
          "Elapsed time: %f seconds | Boost_Time: %f", elapsed_time, boost_time);
      if (elapsed_time > boost_time) // After 30 seconds
      {
        // Boost scores slightly to encourage triggering
        double time_boost = std::min(0.3, 0.01 * (elapsed_time - boost_time)); // Max 0.3 boost, grows 0.01/sec after boost_time
        modified_score += time_boost;
        RCLCPP_INFO(
            rclcpp::get_logger("ScoringEngine"),
            "Applying time-based boost: %f", time_boost);
      }
    }

    // 2. High confidence burst bonus
    // If recent detections all have very high confidence
    if (candidate.getConfidenceHistory().size() >= 5)
    {
      double min_recent_conf = 1.0;
      for (size_t i = candidate.getConfidenceHistory().size() - 5;
           i < candidate.getConfidenceHistory().size(); ++i)
      {
        min_recent_conf = std::min(min_recent_conf, candidate.getConfidenceHistory()[i]);
      }

      if (min_recent_conf > 0.9)
      {
        modified_score *= 1.1; // 10% bonus for very high confidence
      }
    }

    // 3. Very stable detection bonus
    if (candidate.stability_score_ > 0.95)
    {
      modified_score *= 1.05; // 5% bonus for extremely stable detections
    }

    // 4. Check if this is a secondary class
    const auto &context = context_manager_->getCurrentContext();
    bool is_primary = std::find(
                          context.primary_classes.begin(),
                          context.primary_classes.end(),
                          candidate.getClassName()) != context.primary_classes.end();

    if (!is_primary)
    {
      // Secondary classes get a small penalty
      modified_score *= 0.9;
    }

    return modified_score;
  }

} // namespace perception_interface