#include "perception_interface/perception_interface_node.hpp"
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <chrono>

namespace perception_interface
{

PerceptionInterfaceNode::PerceptionInterfaceNode(const rclcpp::NodeOptions & options)
  : Node("perception_interface_node", options),
    is_monitoring_(false),
    triggered_(false)
{
  RCLCPP_INFO(this->get_logger(), "Initializing Perception Interface Node");
  
  initializeParameters();
  // initializeComponents();
  // initializeServices();
  // initializePublishers();
  // initializeSubscribers();
  // initializeTimers();
  
  RCLCPP_INFO(this->get_logger(), "Perception Interface Node initialized successfully");
}
void PerceptionInterfaceNode::init()
{
  initializeComponents();
  initializeServices();
  initializePublishers();
  initializeSubscribers();
  initializeTimers();

}
void PerceptionInterfaceNode::initializeParameters()
{
  // Declare parameters with defaults
  this->declare_parameter("config_file", "");
  
  // Topics
  this->declare_parameter("global.detection_topic", "/detector/objects");
  this->declare_parameter("global.costmap_topic", "/move_base/local_costmap");
  
  // Frame IDs
  this->declare_parameter("global.global_frame_id", "map");
  this->declare_parameter("global.base_frame_id", "base_link");
  
  // Global parameters
  this->declare_parameter("global.min_confidence", 0.6);
  this->declare_parameter("global.min_distance", 1.0);
  this->declare_parameter("global.boost_score_after_time", -1.0);
  
  
  // Tracking parameters
  this->declare_parameter("tracking.max_association_distance", 1.0);
  this->declare_parameter("tracking.max_coasting_cycles", 3);
  this->declare_parameter("tracking.min_hits_to_confirm", 3);
  this->declare_parameter("tracking.detection_history_size", 30);
  this->declare_parameter("tracking.max_time_gap", 0.5);
  
  // Triggering parameters
  this->declare_parameter("triggering.urgent_distance", 1.5);
  this->declare_parameter("triggering.min_trigger_score", 0.75);
  this->declare_parameter("triggering.consistency_threshold", 0.5);
  this->declare_parameter("triggering.use_adaptive_thresholds", false);
  this->declare_parameter("triggering.stage_durations", std::vector<double>{10.0, 30.0, 60.0}); // seconds
  this->declare_parameter("triggering.stage_thresholds", std::vector<double>{0.85, 0.75, 0.65, 0.55}); // last one for inf duration
  this->declare_parameter("triggering.min_conditions", 2); // Minimum conditions to trigger

  // Load global params
  params_.global.detection_topic = this->get_parameter("global.detection_topic").as_string();
  params_.global.costmap_topic = this->get_parameter("global.costmap_topic").as_string();
  params_.global.global_frame_id = this->get_parameter("global.global_frame_id").as_string();
  params_.global.base_frame_id = this->get_parameter("global.base_frame_id").as_string();
  params_.global.min_confidence = this->get_parameter("global.min_confidence").as_double();
  params_.global.min_distance = this->get_parameter("global.min_distance").as_double();
  params_.global.boost_score_after_time = this->get_parameter("global.boost_score_after_time").as_double();
  
  
  // Load tracking params
  params_.tracking.max_association_distance = this->get_parameter("tracking.max_association_distance").as_double();
  params_.tracking.max_coasting_cycles = this->get_parameter("tracking.max_coasting_cycles").as_int();
  params_.tracking.min_hits_to_confirm = this->get_parameter("tracking.min_hits_to_confirm").as_int();
  params_.tracking.detection_history_size = this->get_parameter("tracking.detection_history_size").as_int();
  params_.tracking.max_time_gap = this->get_parameter("tracking.max_time_gap").as_double();
  
  // Load triggering params
  params_.triggering.urgent_distance = this->get_parameter("triggering.urgent_distance").as_double();
  params_.triggering.min_trigger_score = this->get_parameter("triggering.min_trigger_score").as_double();
  params_.triggering.consistency_threshold = this->get_parameter("triggering.consistency_threshold").as_double();
  params_.triggering.use_adaptive_thresholds = this->get_parameter("triggering.use_adaptive_thresholds").as_bool();
  params_.triggering.stage_durations = this->get_parameter("triggering.stage_durations").as_double_array();
  params_.triggering.stage_thresholds = this->get_parameter("triggering.stage_thresholds").as_double_array();
  params_.triggering.min_conditions = this->get_parameter("triggering.min_conditions").as_int();
  // Load context configurations
  RCLCPP_INFO(this->get_logger(), "Params Loaded | Going to load context configurations from parameters");
  loadContextConfigurations();
}

void PerceptionInterfaceNode::loadContextConfigurations()
{
  // Declare parameter for contexts list
  this->declare_parameter("contexts", std::vector<std::string>{});
  auto context_names = this->get_parameter("contexts").as_string_array();
  
  // Load each context
  for (const auto & context_name : context_names)
  {
    params::ContextParams context;
    context.name = context_name;
    
    // Declare and load primary classes
    std::string primary_key = context_name + ".primary_classes";
    this->declare_parameter(primary_key, std::vector<std::string>{});
    context.primary_classes = this->get_parameter(primary_key).as_string_array();
    
    // Declare and load secondary classes
    std::string secondary_key = context_name + ".secondary_classes";
    this->declare_parameter(secondary_key, std::vector<std::string>{});
    context.secondary_classes = this->get_parameter(secondary_key).as_string_array();
    
    // Declare and load confidence threshold
    std::string conf_key = context_name + ".confidence_threshold";
    this->declare_parameter(conf_key, 0.7);
    context.confidence_threshold = this->get_parameter(conf_key).as_double();
    
    context.confidence_threshold = std::max(context.confidence_threshold, params_.global.min_confidence);
    // Declare and load max distance
    std::string dist_key = context_name + ".max_distance";
    this->declare_parameter(dist_key, 5.0);
    context.max_distance = this->get_parameter(dist_key).as_double();
    context.max_distance = std::max(context.max_distance, params_.global.min_distance);

    // Declare and load boost_score_after_time
    std::string boost_time_key = context_name + ".boost_score_after_time";
    this->declare_parameter(boost_time_key, -1.0);
    context.boost_score_after_time = this->get_parameter(boost_time_key).as_double();
    context.boost_score_after_time = std::max(context.boost_score_after_time, params_.global.boost_score_after_time);

    // Declare and load weights
    std::string weight_conf_key = context_name + ".weight_confidence";
    this->declare_parameter(weight_conf_key, 0.25);
    context.weight_confidence = this->get_parameter(weight_conf_key).as_double();
    
    std::string weight_dist_key = context_name + ".weight_distance";
    this->declare_parameter(weight_dist_key, 0.25);
    context.weight_distance = this->get_parameter(weight_dist_key).as_double();
    
    std::string weight_pers_key = context_name + ".weight_persistence";
    this->declare_parameter(weight_pers_key, 0.25);
    context.weight_persistence = this->get_parameter(weight_pers_key).as_double();
    
    std::string weight_stab_key = context_name + ".weight_stability";
    this->declare_parameter(weight_stab_key, 0.25);
    context.weight_stability = this->get_parameter(weight_stab_key).as_double();
    
    // Add context to params
    params_.contexts[context_name] = context;
    
    RCLCPP_INFO(this->get_logger(), 
      "Loaded context '%s' with %zu primary and %zu secondary classes | Boost time: %.2f seconds | Weights: [Confidence: %.2f, Distance: %.2f, Persistence: %.2f, Stability: %.2f] | Global boost time: %.2f",
      context_name.c_str(), 
      context.primary_classes.size(), 
      context.secondary_classes.size(),
      context.boost_score_after_time,
      context.weight_confidence,
      context.weight_distance,
      context.weight_persistence,
      context.weight_stability,
      params_.global.boost_score_after_time);
  }
  
  if (params_.contexts.empty())
  {
    RCLCPP_WARN(this->get_logger(), 
      "No contexts loaded from parameters. Please check your configuration file.");
  }
  RCLCPP_INFO(this->get_logger(), 
    "Total contexts loaded: %zu", params_.contexts.size());

}

void PerceptionInterfaceNode::initializeComponents()
{
  // Create context manager
  context_manager_ = std::make_shared<ContextManager>(params_);
  RCLCPP_INFO(this->get_logger(), "Context Manager initialized!");
  // Create spatial validator
  spatial_validator_ = std::make_unique<SpatialValidator>(this->shared_from_this(), params_);
  RCLCPP_INFO(this->get_logger(), "Spatial Validator initialized!");

  // Create candidate tracker
  candidate_tracker_ = std::make_unique<CandidateTracker>(params_.tracking);
  RCLCPP_INFO(this->get_logger(), "Candidate Tracker initialized!");
  // Create scoring engine
  scoring_engine_ = std::make_unique<ScoringEngine>(context_manager_);
  RCLCPP_INFO(this->get_logger(), "Scoring Engine initialized!");
  
  // Create decision engine
  decision_engine_ = std::make_unique<DecisionEngine>(params_.triggering, context_manager_, shared_from_this());
  RCLCPP_INFO(this->get_logger(), "Decision Engine initialized!");
}

void PerceptionInterfaceNode::initializeServices()
{
  // Start monitoring service
  start_monitoring_service_ = this->create_service<autonovus_msgs::srv::StartPIMonitoring>(
    "/perception_interface/start_monitoring",
    std::bind(&PerceptionInterfaceNode::handleStartMonitoring, this,
              std::placeholders::_1, std::placeholders::_2));
  
  // Stop monitoring service
  stop_monitoring_service_ = this->create_service<autonovus_msgs::srv::StopPIMonitoring>(
    "/perception/stop_monitoring",
    std::bind(&PerceptionInterfaceNode::handleStopMonitoring, this,
              std::placeholders::_1, std::placeholders::_2));
  
  RCLCPP_INFO(this->get_logger(), "Services initialized");
}

void PerceptionInterfaceNode::initializePublishers()
{
  // Best target publisher with transient local QoS (like latched)
  auto target_qos = rclcpp::QoS(1);
  target_qos.transient_local();
  
  best_target_publisher_ = this->create_publisher<autonovus_msgs::msg::PITarget>(
    "/perception/best_target", target_qos);
  
  // Status publisher
  status_publisher_ = this->create_publisher<autonovus_msgs::msg::PIStatus>(
    "/perception/status", 10);
  
  RCLCPP_INFO(this->get_logger(), "Publishers initialized");
}

void PerceptionInterfaceNode::initializeSubscribers()
{
  // Create detection subscriber
  detection_sub_ = this->create_subscription<autonovus_msgs::msg::TALocation>(
    params_.global.detection_topic, 2,
    std::bind(&PerceptionInterfaceNode::detectionCallback, this, std::placeholders::_1));

  RCLCPP_INFO(this->get_logger(),
    "Subscribed to detection topic: %s", params_.global.detection_topic.c_str());
}

void PerceptionInterfaceNode::initializeTimers()
{
  // Status publishing timer (1 Hz)
  status_timer_ = this->create_wall_timer(
    std::chrono::seconds(1),
    std::bind(&PerceptionInterfaceNode::statusTimerCallback, this));
}

void PerceptionInterfaceNode::handleStartMonitoring(
  const std::shared_ptr<autonovus_msgs::srv::StartPIMonitoring::Request> request,
  std::shared_ptr<autonovus_msgs::srv::StartPIMonitoring::Response> response)
{
  RCLCPP_INFO(this->get_logger(), 
    "Start monitoring request received for context: %s", 
    request->context_name.c_str());
  
  // Check if already monitoring
  if (is_monitoring_)
  {
    response->success = false;
    response->message = "Already monitoring. Please stop current monitoring first.";
    return;
  }
  
  // Activate context
  bool context_activated = context_manager_->activateContext(
    request->context_name, std::vector<std::string>{});
  
  if (!context_activated)
  {
    response->success = false;
    response->message = "Unknown context: " + request->context_name;
    return;
  }
  
  // Reset components
  candidate_tracker_ = std::make_unique<CandidateTracker>(params_.tracking);
  decision_engine_->reset();
  
  // Start monitoring
  is_monitoring_ = true;
  triggered_ = false;
  monitoring_start_time_ = this->get_clock()->now();
  
  // Set timeout
  if (request->timeout > 0)
  {
    monitoring_timeout_ = std::chrono::duration<double>(request->timeout);
  }
  else
  {
    monitoring_timeout_ = std::chrono::duration<double>::max();
  }
  
  response->success = true;
  response->message = "Started monitoring for context: " + request->context_name;
  
  // RCLCPP_INFO(this->get_logger(), 
  //   "Monitoring started successfully. Target classes: %zu", 
  //   context_manager_->getTargetClasses().size());

  const auto &classes = context_manager_->getTargetClasses();

  std::ostringstream oss;
  for (auto it = classes.begin(); it != classes.end(); ++it) {
      if (it != classes.begin()) {
          oss << ", ";   // add separator
      }
      oss << *it;
  }

  RCLCPP_INFO(this->get_logger(),
      "Monitoring started successfully. Target classes (%zu): [%s]",
      classes.size(),
      oss.str().c_str());
}

void PerceptionInterfaceNode::handleStopMonitoring(
  const std::shared_ptr<autonovus_msgs::srv::StopPIMonitoring::Request> request,
  std::shared_ptr<autonovus_msgs::srv::StopPIMonitoring::Response> response)
{
  RCLCPP_INFO(this->get_logger(), 
    "Stop monitoring request received. Reason: %s", 
    request->reason.c_str());
  
  response->was_active = is_monitoring_;
  
  if (is_monitoring_)
  {
    is_monitoring_ = false;
    context_manager_->deactivateContext();
    response->success = true;
  }
  else
  {
    response->success = false;
  }
}

void PerceptionInterfaceNode::detectionCallback(
  const autonovus_msgs::msg::TALocation::SharedPtr msg)
{
  if (!is_monitoring_)
  {
    return;
  }

  auto elapsed = this->get_clock()->now() - monitoring_start_time_;
  if (elapsed.seconds() > monitoring_timeout_.count())
  {
    RCLCPP_WARN(this->get_logger(), "Monitoring timeout reached");
    is_monitoring_ = false;
    context_manager_->deactivateContext();
    return;
  }
  // std::cout << "Converting TALocation to Detection" << std::endl;

  std::vector<Detection> detections;
  Detection det = convertTALocationToDetection(*msg);
  detections.push_back(det);
  
  // Process detections
  processDetections(detections);
}

Detection PerceptionInterfaceNode::convertTALocationToDetection(
    const autonovus_msgs::msg::TALocation & ta_location)
{
  Detection detection;

  detection.header = ta_location.header;
  detection.class_name = ta_location.label;
  detection.confidence = ta_location.confidence;

  geometry_msgs::msg::PoseStamped pose_stamped;
  pose_stamped.header = ta_location.header;
  pose_stamped.pose = ta_location.pose;

  detection.pose = pose_stamped;
  
  // Distance will be calculated by spatial validator
  detection.distance_to_robot = 0.0;
  
  return detection;
}

// Detection PerceptionInterfaceNode::convertBoundingBoxToDetection(
//   const autonovus_msgs::msg::BoundingBox & bbox,
//   const std_msgs::msg::Header & header)
// {
//   Detection detection;
  
//   detection.header = header;
//   detection.class_name = bbox.label;
//   detection.confidence = bbox.conf;
  
//   // Create pose in camera frame
//   geometry_msgs::msg::PoseStamped pose_camera;
//   pose_camera.header = header;
//   pose_camera.pose.position.x = bbox.pose_x;
//   pose_camera.pose.position.y = bbox.pose_y;
//   pose_camera.pose.position.z = 0.0;  // Assuming 2D detection
  
//   // Convert theta to quaternion
//   tf2::Quaternion q;
//   q.setRPY(0.0, 0.0, bbox.pose_theta);
//   pose_camera.pose.orientation.x = q.x();
//   pose_camera.pose.orientation.y = q.y();
//   pose_camera.pose.orientation.z = q.z();
//   pose_camera.pose.orientation.w = q.w();
  
//   // For now, use the camera frame pose
//   // The spatial validator will transform to map frame
//   detection.pose = pose_camera;
  
//   // Distance will be calculated by spatial validator
//   detection.distance_to_robot = 0.0;
  
//   return detection;
// }

void PerceptionInterfaceNode::processDetections(const std::vector<Detection> & detections)
{
  auto current_time = std::chrono::steady_clock::now();
  
  // Stage 1: Context filtering
  std::vector<Detection> filtered_detections;
  for (const auto & detection : detections)
  {
    if (context_manager_->filterDetection(detection))
    {
      filtered_detections.push_back(detection);
    }
  }

  // Stage 2: Spatial validation
  std::vector<std::pair<Detection, ValidationResult>> validated_detections;
  for (auto & detection : filtered_detections)
  {
    auto validation_result = spatial_validator_->validate(
      detection, context_manager_->getCurrentContext());
    
    if (validation_result.is_valid)
    {
      // Update detection with calculated distance
      detection.distance_to_robot = validation_result.distance_to_robot;
      validated_detections.push_back({detection, validation_result});
    }
  }

  // Stage 3: Update tracking
  auto tracks = candidate_tracker_->update(validated_detections, current_time);
 
  // Stage 4: Score candidates
  auto scores = scoring_engine_->scoreCandidates(tracks);
  
  // Stage 5: Check trigger conditions
  auto trigger_candidate = decision_engine_->evaluateTriggerConditions(tracks, scores);
  
  // Stage 6: Generate trigger if needed
  if (trigger_candidate.has_value())
  {
    publishBestTarget(*trigger_candidate.value());
    is_monitoring_ = false;
    triggered_ = true;
  }
}

void PerceptionInterfaceNode::publishBestTarget(const TrackedCandidate & candidate)
{
  auto msg = autonovus_msgs::msg::PITarget();
  
  // Header
  msg.header.stamp = this->get_clock()->now();
  msg.header.frame_id = params_.global.global_frame_id;
  
  // Basic info
  msg.context_name = context_manager_->getActiveContext();
  msg.found_class = candidate.getClassName();
  
  // Pose (should be in map frame from validation)
  msg.pose = candidate.latest_validation_.pose_in_map;
  msg.pose.header.stamp = msg.header.stamp;
  msg.pose.header.frame_id = params_.global.global_frame_id;
  
  // Confidence and distance
  auto conf_history = candidate.getConfidenceHistory();
  double avg_confidence = 0.0;
  if (!conf_history.empty())
  {
    for (auto conf : conf_history)
    {
      avg_confidence += conf;
    }
    avg_confidence /= conf_history.size();
  }
  msg.confidence = avg_confidence;
  msg.distance = candidate.getLatestDetection().distance_to_robot;
  
  // Reachability
  msg.reachability_score = candidate.latest_validation_.reachability_score;
  
  // Publish
  best_target_publisher_->publish(msg);
  
  RCLCPP_INFO(this->get_logger(),
    "Published best target: class=%s, distance=%.2fm, confidence=%.2f",
    msg.found_class.c_str(), msg.distance, msg.confidence);
}

void PerceptionInterfaceNode::statusTimerCallback()
{
  if (!is_monitoring_)
  {
    return;
  }
  
  auto msg = autonovus_msgs::msg::PIStatus();
  
  // Header
  msg.header.stamp = this->get_clock()->now();
  
  // Status info
  msg.is_monitoring = is_monitoring_;
  msg.active_context = context_manager_->getActiveContext();
  
  // Get tracking info
  const auto & tracks = candidate_tracker_->getTracks();
  msg.candidates_tracked = 0;
  msg.best_candidate_score = 0.0;
  
  for (const auto & [id, track] : tracks)
  {
    if (track->getState() == TrackState::CONFIRMED)
    {
      msg.candidates_tracked++;
      if (track->best_score_ > msg.best_candidate_score)
      {
        msg.best_candidate_score = track->best_score_;
      }
    }
  }
  
  // Monitoring duration
  auto elapsed = this->get_clock()->now() - monitoring_start_time_;
  msg.monitoring_duration = elapsed.seconds();
  
  // Publish
  status_publisher_->publish(msg);
}

}  // namespace perception_interface