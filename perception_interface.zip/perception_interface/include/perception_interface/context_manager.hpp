#ifndef PERCEPTION_INTERFACE__CONTEXT_MANAGER_HPP_
#define PERCEPTION_INTERFACE__CONTEXT_MANAGER_HPP_

#include <string>
#include <vector>
#include <set>
#include <map>
#include <chrono>
#include "perception_interface/params.hpp"

namespace perception_interface
{

class ContextManager
{
public:
  explicit ContextManager(const params::PerceptionInterfaceParams & params);
  ~ContextManager() = default;

  bool activateContext(
    const std::string & context_name,
    const std::vector<std::string> & custom_classes = {});
  
  void deactivateContext();
  bool filterDetection(const Detection & detection) const;
  
  // Getters
  const std::string & getActiveContext() const { return active_context_; }
  const std::set<std::string> & getTargetClasses() const { return target_classes_; }
  const params::ContextParams & getCurrentContext() const { return current_context_; }
  std::chrono::steady_clock::time_point getStartTime() const { return start_time_; }
  double getElapsedTime() const;

private:
  std::string active_context_;
  std::set<std::string> target_classes_;
  params::ContextParams current_context_;
  std::chrono::steady_clock::time_point start_time_;
  
  // Store reference to parameters
  const params::PerceptionInterfaceParams & params_;
};

}  // namespace perception_interface

#endif  // PERCEPTION_INTERFACE__CONTEXT_MANAGER_HPP_