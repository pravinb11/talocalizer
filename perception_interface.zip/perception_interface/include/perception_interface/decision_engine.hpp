#ifndef PERCEPTION_INTERFACE__DECISION_ENGINE_HPP_
#define PERCEPTION_INTERFACE__DECISION_ENGINE_HPP_

#include <memory>
#include <optional>
#include <chrono>
#include "rclcpp/rclcpp.hpp"
#include "perception_interface/params.hpp"
#include "perception_interface/context_manager.hpp"
#include "perception_interface/candidate_tracker.hpp"

namespace perception_interface
{

class DecisionEngine
{
public:
  DecisionEngine(
    const params::TriggeringParams& config,
    std::shared_ptr<ContextManager> context_manager,
    rclcpp::Node::SharedPtr node);
  ~DecisionEngine() = default;

  std::optional<std::shared_ptr<TrackedCandidate>> evaluateTriggerConditions(
    const std::map<int, std::shared_ptr<TrackedCandidate>> & tracks,
    const std::map<int, double> & scores);

  void reset();
  bool hasTriggered() const { return triggered_; }

private:
  double getAdaptiveThreshold() const;
  bool checkUrgencyConditions(const TrackedCandidate & candidate) const;
  bool checkConsistencyConditions(const TrackedCandidate & candidate) const;
  bool checkHighConfidenceBurst(const TrackedCandidate & candidate) const;

  std::shared_ptr<ContextManager> context_manager_;
  rclcpp::Node::SharedPtr node_;
  bool triggered_;
  std::chrono::steady_clock::time_point trigger_time_;
  params::TriggeringParams config_;
};

}  // namespace perception_interface

#endif  // PERCEPTION_INTERFACE__DECISION_ENGINE_HPP_