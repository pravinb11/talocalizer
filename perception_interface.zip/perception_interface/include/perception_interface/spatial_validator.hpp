#ifndef PERCEPTION_INTERFACE__SPATIAL_VALIDATOR_HPP_
#define PERCEPTION_INTERFACE__SPATIAL_VALIDATOR_HPP_

#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav_msgs/msg/occupancy_grid.hpp"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "perception_interface/params.hpp"

namespace perception_interface
{

class SpatialValidator
{
public:
  SpatialValidator(
    rclcpp::Node::SharedPtr node,
    const params::PerceptionInterfaceParams & params);
  
  ~SpatialValidator() = default;

  ValidationResult validate(
    const Detection & detection,
    const params::ContextParams & context_params);

  // Get current robot pose
  bool getRobotPose(geometry_msgs::msg::PoseStamped & pose);

private:
  double calculateDistance(const Detection & detection);
  bool checkCostmapValidity(double x, double y) const;
  double calculateReachabilityScore(double distance, bool costmap_valid) const;
  
  // Costmap callback
  void costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg);

  rclcpp::Node::SharedPtr node_;
  
  // TF2
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::unique_ptr<tf2_ros::TransformListener> tf_listener_;
  
  // Subscribers
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr costmap_sub_;
  
  // Frame IDs from parameters
  std::string global_frame_id_;
  std::string base_frame_id_;
  
  // Cached robot pose
  geometry_msgs::msg::PoseStamped robot_pose_;
  bool robot_pose_valid_;
  rclcpp::Time last_pose_update_time_;
  
  // Costmap data
  nav_msgs::msg::OccupancyGrid::SharedPtr local_costmap_;
  nav_msgs::msg::OccupancyGrid::SharedPtr global_costmap_;
  bool costmap_valid_;
};

}  // namespace perception_interface

#endif  // PERCEPTION_INTERFACE__SPATIAL_VALIDATOR_HPP_