#ifndef PERCEPTION_INTERFACE__PERCEPTION_INTERFACE_NODE_HPP_
#define PERCEPTION_INTERFACE__PERCEPTION_INTERFACE_NODE_HPP_

#include <memory>
#include <string>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "autonovus_msgs/msg/pi_target.hpp"
#include "autonovus_msgs/msg/pi_status.hpp"
// #include "autonovus_msgs/msg/object_detection.hpp"
#include "autonovus_msgs/msg/ta_location.hpp"
#include "autonovus_msgs/srv/start_pi_monitoring.hpp"
#include "autonovus_msgs/srv/stop_pi_monitoring.hpp"

// Component includes
#include "perception_interface/context_manager.hpp"
#include "perception_interface/spatial_validator.hpp"
#include "perception_interface/candidate_tracker.hpp"
#include "perception_interface/scoring_engine.hpp"
#include "perception_interface/decision_engine.hpp"
#include "perception_interface/params.hpp"

namespace perception_interface
{

class PerceptionInterfaceNode : public rclcpp::Node
{
public:
  explicit PerceptionInterfaceNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());
  ~PerceptionInterfaceNode() = default;
  void init(); // it will intialize all components and other necessary parts

private:
  // Initialization methods
  void initializeParameters();
  void initializeServices();
  void initializePublishers();
  void initializeSubscribers();
  void initializeComponents();
  void initializeTimers();
  void loadContextConfigurations();

  // Service handlers
  void handleStartMonitoring(
    const std::shared_ptr<autonovus_msgs::srv::StartPIMonitoring::Request> request,
    std::shared_ptr<autonovus_msgs::srv::StartPIMonitoring::Response> response);
  
  void handleStopMonitoring(
    const std::shared_ptr<autonovus_msgs::srv::StopPIMonitoring::Request> request,
    std::shared_ptr<autonovus_msgs::srv::StopPIMonitoring::Response> response);

  // Callbacks
  void detectionCallback(const autonovus_msgs::msg::TALocation::SharedPtr msg);
  void statusTimerCallback();

  // Core processing
  void processDetections(const std::vector<Detection> & detections);
  void publishBestTarget(const TrackedCandidate & candidate);
  // Detection convertBoundingBoxToDetection(
  //   const autonovus_msgs::msg::BoundingBox & bbox,
  //   const std_msgs::msg::Header & header);
  Detection convertTALocationToDetection(
    const autonovus_msgs::msg::TALocation & ta_location);

  // Services
  rclcpp::Service<autonovus_msgs::srv::StartPIMonitoring>::SharedPtr start_monitoring_service_;
  rclcpp::Service<autonovus_msgs::srv::StopPIMonitoring>::SharedPtr stop_monitoring_service_;

  // Publishers
  rclcpp::Publisher<autonovus_msgs::msg::PITarget>::SharedPtr best_target_publisher_;
  rclcpp::Publisher<autonovus_msgs::msg::PIStatus>::SharedPtr status_publisher_;

  // Subscribers
  rclcpp::Subscription<autonovus_msgs::msg::TALocation>::SharedPtr detection_sub_;

  // Timers
  rclcpp::TimerBase::SharedPtr status_timer_;

  // Components
  std::shared_ptr<ContextManager> context_manager_;
  std::unique_ptr<SpatialValidator> spatial_validator_;
  std::unique_ptr<CandidateTracker> candidate_tracker_;
  std::unique_ptr<ScoringEngine> scoring_engine_;
  std::unique_ptr<DecisionEngine> decision_engine_;

  // Parameters
  params::PerceptionInterfaceParams params_;

  // State variables
  bool is_monitoring_;
  rclcpp::Time monitoring_start_time_;
  std::chrono::duration<double> monitoring_timeout_;
  bool triggered_;
};

}  // namespace perception_interface

#endif  // PERCEPTION_INTERFACE__PERCEPTION_INTERFACE_NODE_HPP_