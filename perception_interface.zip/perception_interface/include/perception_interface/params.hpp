#ifndef PERCEPTION_INTERFACE__PARAMS_HPP_
#define PERCEPTION_INTERFACE__PARAMS_HPP_

#include <string>
#include <vector>
#include <deque>
#include <chrono>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <std_msgs/msg/header.hpp>
#include <map>
namespace perception_interface
{

    // Forward declarations
    // class TrackedCandidate;

    // Detection structure
    struct Detection
    {
        std_msgs::msg::Header header;
        std::string class_name;
        double confidence;
        geometry_msgs::msg::PoseStamped pose; // Already in map frame

        // Computed fields (will be filled by spatial validator)
        double distance_to_robot{0.0};
    };

    // Validation result structure
    struct ValidationResult
    {
        bool is_valid{true};
        double distance_to_robot{0.0};
        double reachability_score{0.0};
        bool costmap_valid{true};
        std::vector<std::string> rejection_reasons;

        // Store the pose in map frame for tracking
        geometry_msgs::msg::PoseStamped pose_in_map;
    };

    // ROS2 Parameter Structures
    namespace params
    {

        struct GlobalParams
        {
            std::string detection_topic{"/object_detector/detections"};
            std::string costmap_topic{"/local_costmap"};
            std::string global_frame_id{"odom"};
            std::string base_frame_id{"base_link"};
            double min_confidence{0.6};
            double min_distance{10.0};
            double boost_score_after_time{-1.0}; // -1 to disable
        };

        struct TrackingParams
        {
            double max_association_distance{1.0};
            int max_coasting_cycles{3};
            int min_hits_to_confirm{3};
            int detection_history_size{30};
            double max_time_gap{0.5}; // seconds
        };

        struct TriggeringParams
        {
            double urgent_distance{1.5};
            double min_trigger_score{0.75};
            double consistency_threshold{0.5};  // [0,1] threshold for consistent_frames_perc_
            int min_conditions{2}; // Minimum conditions to trigger
            bool use_adaptive_thresholds{false}; // Use time-based adaptive thresholds
            // Time-based adaptive thresholds
            std::vector<double> stage_durations{10.0, 30.0, 60.0};        // seconds
            std::vector<double> stage_thresholds{0.85, 0.75, 0.65, 0.55}; // last one for inf duration
        };

        struct ContextParams
        {
            std::string name;
            std::vector<std::string> primary_classes;
            std::vector<std::string> secondary_classes;
            double confidence_threshold{0.7};
            double max_distance{5.0};
            double boost_score_after_time{-1.0}; // -1 to use global one
            // Scoring weights
            double weight_confidence{0.3};
            double weight_distance{0.3};
            double weight_persistence{0.2};
            double weight_stability{0.2};
        };

        struct PerceptionInterfaceParams
        {
            // Global parameters
            GlobalParams global;
            
            // Module parameters
            TrackingParams tracking;
            TriggeringParams triggering;

            // Context configurations (loaded from parameter server)
            std::map<std::string, ContextParams> contexts;
        };

    } // namespace params

    // Enums
    enum class TrackState
    {
        TENTATIVE,
        CONFIRMED,
        COASTING,
        DELETED
    };

    // Utility functions
    inline std::string trackStateToString(TrackState state)
    {
        switch (state)
        {
        case TrackState::TENTATIVE:
            return "TENTATIVE";
        case TrackState::CONFIRMED:
            return "CONFIRMED";
        case TrackState::COASTING:
            return "COASTING";
        case TrackState::DELETED:
            return "DELETED";
        default:
            return "UNKNOWN";
        }
    }

} // namespace perception_interface

#endif // PERCEPTION_INTERFACE__PARAMS_HPP_