#ifndef PERCEPTION_INTERFACE__SCORING_ENGINE_HPP_
#define PERCEPTION_INTERFACE__SCORING_ENGINE_HPP_

#include <map>
#include <memory>
#include "perception_interface/params.hpp"
#include "perception_interface/context_manager.hpp"
#include "perception_interface/candidate_tracker.hpp"

namespace perception_interface
{

class ScoringEngine
{
public:
  explicit ScoringEngine(std::shared_ptr<ContextManager> context_manager);
  ~ScoringEngine() = default;

  std::map<int, double> scoreCandidates(
    const std::map<int, std::shared_ptr<TrackedCandidate>> & tracks);

private:
  double computeCandidateScore(const TrackedCandidate & candidate);
  std::map<std::string, double> calculateBaseFactors(const TrackedCandidate & candidate);
  double applyModifiers(double base_score, const TrackedCandidate & candidate);

  std::shared_ptr<ContextManager> context_manager_;
  // const double ALPHA = 0.25; // Smoothing factor for consecutive high scores
};

}  // namespace perception_interface

#endif  // PERCEPTION_INTERFACE__SCORING_ENGINE_HPP_