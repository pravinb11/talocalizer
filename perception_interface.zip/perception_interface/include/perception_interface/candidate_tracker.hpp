#ifndef PERCEPTION_INTERFACE__CANDIDATE_TRACKER_HPP_
#define PERCEPTION_INTERFACE__CANDIDATE_TRACKER_HPP_

#include <memory>
#include <vector>
#include <map>
#include <deque>
#include <set>
#include "perception_interface/params.hpp"
#include "rclcpp/rclcpp.hpp"

namespace perception_interface
{

  class TrackedCandidate
  {
  public:
    TrackedCandidate(
        const Detection &detection,
        const ValidationResult &validation_data,
        const std::chrono::steady_clock::time_point &current_time,
        const params::TrackingParams &config);

    void update(
        const Detection &detection,
        const ValidationResult &validation_data,
        const std::chrono::steady_clock::time_point &current_time);

    void markMissed(const std::chrono::steady_clock::time_point &current_time);

    // Getters
    int getTrackId() const { return track_id_; }
    const std::string &getClassName() const { return class_name_; }
    TrackState getState() const { return state_; }
    double getPersistenceScore() const { return persistence_score_; }
    double getConsistentFramesPerc() const { return consistent_frames_perc_; }

    // For scoring
    const std::deque<double> &getConfidenceHistory() const { return confidence_history_; }
    const Detection &getLatestDetection() const { return latest_detection_; }

    // Public members for easy access
    int missed_detections_;
    std::chrono::steady_clock::time_point first_seen_;
    std::chrono::steady_clock::time_point last_seen_;
    TrackState state_;
    double persistence_score_;
    double stability_score_;
    double best_score_;
    double consistent_frames_perc_; // [0,1] representing percentage of consistent frames
    std::deque<Detection> detection_history_;
    std::deque<double> score_history_;
    ValidationResult latest_validation_;
    params::TrackingParams config_;

  private:
    void updatePersistence();
    void updateStability();

    int track_id_;
    std::string class_name_;

    // History buffers
    std::deque<geometry_msgs::msg::PoseStamped> pose_history_;
    std::deque<double> confidence_history_;

    Detection latest_detection_;

    static int next_track_id_;
  };

  class CandidateTracker
  {
  public:
    explicit CandidateTracker(const params::TrackingParams &config);
    ~CandidateTracker() = default;

    std::map<int, std::shared_ptr<TrackedCandidate>> update(
        const std::vector<std::pair<Detection, ValidationResult>> &validated_detections,
        const std::chrono::steady_clock::time_point &current_time);

    const std::map<int, std::shared_ptr<TrackedCandidate>> &getTracks() const { return tracks_; }

  private:
    void createNewTrack(
        const Detection &detection,
        const ValidationResult &validation_data,
        const std::chrono::steady_clock::time_point &current_time);

    void updateTrackStates(const std::chrono::steady_clock::time_point &current_time);
    void pruneDeadTracks();

    std::map<int, std::shared_ptr<TrackedCandidate>> tracks_;
    params::TrackingParams config_;
  };
  inline int TrackedCandidate::next_track_id_ = 0;
} // namespace perception_interface

#endif // PERCEPTION_INTERFACE__CANDIDATE_TRACKER_HPP_