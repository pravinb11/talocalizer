import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

# Parameters
max_distance = 5.0
distances = np.linspace(0, 10, 500)

# Compute the function
values = np.exp(-2.0 * distances / max_distance)

# Plotting
plt.figure(figsize=(8, 5))
plt.plot(distances, values, label='exp(-2 * distance / max_distance)', color='blue')
plt.title('Exponential Decay Function')
plt.xlabel('Distance')
plt.ylabel('Value')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
