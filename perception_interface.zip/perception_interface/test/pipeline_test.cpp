#include <memory>
#include <chrono>
#include <thread>
#include <random>

#include "rclcpp/rclcpp.hpp"
#include "tf2_ros/static_transform_broadcaster.h"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "autonovus_msgs/msg/object_detection.hpp"
#include "autonovus_msgs/msg/bounding_box.hpp"
#include "autonovus_msgs/srv/start_pi_monitoring.hpp"

namespace perception_interface
{

class PipelineTestNode : public rclcpp::Node
{
public:
  PipelineTestNode() : Node("pipeline_test")
  {
    // Publishers
    detection_pub_ = this->create_publisher<autonovus_msgs::msg::ObjectDetection>(
      "/object_detector/detections", 10);
    
    // TF broadcaster
    tf_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(this);
    
    // Service client
    start_client_ = this->create_client<autonovus_msgs::srv::StartPIMonitoring>(
      "/perception_interface/start_monitoring");
    
    // Start TF publishing
    tf_timer_ = this->create_wall_timer(
      std::chrono::milliseconds(50),
      std::bind(&PipelineTestNode::publishTF, this));
    
    RCLCPP_INFO(this->get_logger(), "Pipeline test node started. Waiting 3 seconds before starting test...");
    
    startup_timer_ = this->create_wall_timer(
      std::chrono::seconds(3),
      [this]() {
        startup_timer_->cancel();  // Cancel the timer after first execution
        this->startTest();
      });
  }

private:
  void publishTF()
  {
    geometry_msgs::msg::TransformStamped t;
    
    // map -> odom
    t.header.stamp = this->get_clock()->now();
    t.header.frame_id = "map";
    t.child_frame_id = "odom";
    t.transform.translation.x = 0.0;
    t.transform.translation.y = 0.0;
    t.transform.translation.z = 0.0;
    t.transform.rotation.w = 1.0;
    tf_broadcaster_->sendTransform(t);
    
    // odom -> base_link (robot at origin)
    t.header.frame_id = "odom";
    t.child_frame_id = "base_link";
    tf_broadcaster_->sendTransform(t);
  }
  
  void startTest()
  {
    // Check if service is available
    if (!start_client_->service_is_ready()) {
      RCLCPP_INFO(this->get_logger(), "Waiting for perception_interface service...");
      // Retry after 1 second
      startup_timer_ = this->create_wall_timer(
        std::chrono::seconds(1),
        [this]() {
          startup_timer_->cancel();
          this->startTest();
        });
      return;
    }
    
    // Send request asynchronously
    auto request = std::make_shared<autonovus_msgs::srv::StartPIMonitoring::Request>();
    request->context_name = "outdoor_to_indoor";
    request->timeout = -1.0;
    
    RCLCPP_INFO(this->get_logger(), "Sending start monitoring request...");
    
    // Use async callback instead of blocking wait
    auto future = start_client_->async_send_request(
      request,
      [this](rclcpp::Client<autonovus_msgs::srv::StartPIMonitoring>::SharedFuture future) {
        this->handleServiceResponse(future);
      });
  }
  
  void handleServiceResponse(rclcpp::Client<autonovus_msgs::srv::StartPIMonitoring>::SharedFuture future)
  {
    try {
      auto response = future.get();
      RCLCPP_INFO(this->get_logger(), "Started monitoring: %s - %s", 
        response->success ? "SUCCESS" : "FAILED",
        response->message.c_str());
      
      if (response->success)
      {
        // Start publishing detections
        detection_timer_ = this->create_wall_timer(
          std::chrono::milliseconds(100),  // 10Hz
          std::bind(&PipelineTestNode::publishDetection, this));
      }
    } catch (const std::exception& e) {
      RCLCPP_ERROR(this->get_logger(), "Service call failed: %s", e.what());
    }
  }
  
  void publishDetection()
  {
    // CHANGE THIS LINE TO SELECT TEST CASE
    // publishBasicTest();
    // publishUrgentTest();
    // publishIntermittentTest();
    publishMultiObjectTest();
  }
  
  // TEST CASE 1: Basic static door detection
  void publishBasicTest()
  {
    auto msg = autonovus_msgs::msg::ObjectDetection();
    msg.header.stamp = this->get_clock()->now();
    msg.header.frame_id = "odom";
    
    // Door at 3m with slight noise
    std::normal_distribution<double> noise(0.0, 0.02);
    
    autonovus_msgs::msg::BoundingBox door;
    door.label = "door";
    door.conf = 0.85 + noise(gen_) * 0.05;  // 0.85 ± 0.05
    door.pose_x = 2.0 + noise(gen_);
    door.pose_y = 0.0 + noise(gen_);
    door.pose_theta = 0.0;
    door.x = 320;
    door.y = 240;
    door.width = 100;
    door.height = 150;
    door.id = 1;
    
    msg.bboxes.push_back(door);
    detection_pub_->publish(msg);
    
    RCLCPP_INFO_ONCE(this->get_logger(), "Running BASIC TEST: Door at X,Y(%.3f, %.3f)", door.pose_x, door.pose_y);
  }
  
  // TEST CASE 2: Urgent detection (door very close)
  void publishUrgentTest()
  {
    auto msg = autonovus_msgs::msg::ObjectDetection();
    msg.header.stamp = this->get_clock()->now();
    msg.header.frame_id = "odom";
    
    // Door at 1.0m (below urgent threshold of 1.5m)
    autonovus_msgs::msg::BoundingBox door;
    door.label = "door";
    door.conf = 0.90;
    door.pose_x = 1.0;  // Very close!
    door.pose_y = 0.0;
    door.pose_theta = 0.0;
    door.x = 320;
    door.y = 240;
    door.width = 200;  // Appears larger being closer
    door.height = 300;
    door.id = 1;
    
    msg.bboxes.push_back(door);
    detection_pub_->publish(msg);
    
    RCLCPP_INFO_ONCE(this->get_logger(), "Running URGENT TEST: Door at 1m");
  }
  
  // TEST CASE 3: Intermittent detection (simulates occlusion)
  void publishIntermittentTest()
  {
    auto msg = autonovus_msgs::msg::ObjectDetection();
    msg.header.stamp = this->get_clock()->now();
    msg.header.frame_id = "odom";
    
    // Only publish 70% of the time
    std::uniform_real_distribution<double> prob(0.0, 1.0);
    
    if (prob(gen_) < 0.7)  // 70% detection rate
    {
      autonovus_msgs::msg::BoundingBox door;
      door.label = "door";
      door.conf = 0.82;
      door.pose_x = 2.5;
      door.pose_y = 0.0;
      door.pose_theta = 0.0;
      door.x = 320;
      door.y = 240;
      door.width = 100;
      door.height = 150;
      door.id = 1;
      
      msg.bboxes.push_back(door);
      RCLCPP_DEBUG(this->get_logger(), "Detection published");
    }
    else
    {
      RCLCPP_DEBUG(this->get_logger(), "Detection missed (simulating occlusion)");
    }
    
    detection_pub_->publish(msg);
    RCLCPP_INFO_ONCE(this->get_logger(), "Running INTERMITTENT TEST: 70%% detection rate");
  }
  
  // TEST CASE 4: Multiple objects
  void publishMultiObjectTest()
  {
    auto msg = autonovus_msgs::msg::ObjectDetection();
    msg.header.stamp = this->get_clock()->now();
    msg.header.frame_id = "odom";
    
    // Door (primary class)
    autonovus_msgs::msg::BoundingBox door;
    door.label = "door";
    door.conf = 0.85;
    door.pose_x = 3.0;
    door.pose_y = 0.5;
    door.pose_theta = 0.0;
    door.x = 200;
    door.y = 240;
    door.width = 100;
    door.height = 150;
    door.id = 1;
    msg.bboxes.push_back(door);
    
    // Sign (secondary class)
    autonovus_msgs::msg::BoundingBox sign;
    sign.label = "entrance_sign";
    sign.conf = 0.78;
    sign.pose_x = 2.8;
    sign.pose_y = -0.3;
    sign.pose_theta = 0.0;
    sign.x = 400;
    sign.y = 100;
    sign.width = 50;
    sign.height = 50;
    sign.id = 2;
    msg.bboxes.push_back(sign);
    
    // Person (not in context - should be filtered)
    autonovus_msgs::msg::BoundingBox person;
    person.label = "person";
    person.conf = 0.92;
    person.pose_x = 2.0;
    person.pose_y = 0.0;
    person.pose_theta = 0.0;
    person.x = 320;
    person.y = 240;
    person.width = 60;
    person.height = 120;
    person.id = 3;
    msg.bboxes.push_back(person);
    
    detection_pub_->publish(msg);
    RCLCPP_INFO_ONCE(this->get_logger(), "Running MULTI-OBJECT TEST: door, sign, person");
  }
  
  // TEST CASE 5: Confidence variation
  void publishConfidenceVariationTest()
  {
    auto msg = autonovus_msgs::msg::ObjectDetection();
    msg.header.stamp = this->get_clock()->now();
    msg.header.frame_id = "odom";
    
    // Oscillating confidence
    double time = (this->get_clock()->now() - start_time_).seconds();
    double conf = 0.75 + 0.2 * sin(time);  // Varies between 0.55 and 0.95
    
    autonovus_msgs::msg::BoundingBox door;
    door.label = "door";
    door.conf = conf;
    door.pose_x = 2.5;
    door.pose_y = 0.0;
    door.pose_theta = 0.0;
    door.x = 320;
    door.y = 240;
    door.width = 100;
    door.height = 150;
    door.id = 1;
    
    msg.bboxes.push_back(door);
    detection_pub_->publish(msg);
    
    RCLCPP_INFO_ONCE(this->get_logger(), 
      "Running CONFIDENCE VARIATION TEST: confidence oscillates 0.55-0.95");
    RCLCPP_DEBUG(this->get_logger(), "Current confidence: %.2f", conf);
  }

  rclcpp::Publisher<autonovus_msgs::msg::ObjectDetection>::SharedPtr detection_pub_;
  rclcpp::Client<autonovus_msgs::srv::StartPIMonitoring>::SharedPtr start_client_;
  std::shared_ptr<tf2_ros::StaticTransformBroadcaster> tf_broadcaster_;
  rclcpp::TimerBase::SharedPtr tf_timer_;
  rclcpp::TimerBase::SharedPtr detection_timer_;
  rclcpp::TimerBase::SharedPtr startup_timer_;  // Added for startup sequence
  rclcpp::Time start_time_{this->get_clock()->now()};
  
  // Random number generation
  std::random_device rd_;
  std::mt19937 gen_{rd_()};
};

}  // namespace perception_interface

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<perception_interface::PipelineTestNode>());
  rclcpp::shutdown();
  return 0;
}