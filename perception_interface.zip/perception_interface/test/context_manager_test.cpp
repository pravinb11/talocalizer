#include <gtest/gtest.h>
#include "perception_interface/context_manager.hpp"
#include <chrono>
#include <cmath>

namespace perception_interface
{

    class ContextManagerTest : public ::testing::Test
    {
    protected:
        void SetUp() override
        {
            // Configuration for testing
            params::ContextParams context_params;
            context_params.name = "test_context";
            context_params.primary_classes = {"door", "window"};
            context_params.secondary_classes = {"person"};
            context_params.confidence_threshold = 0.7;
            context_params.max_distance = 5.0;
            context_params.weight_confidence = 0.3;
            context_params.weight_distance = 0.3;
            context_params.weight_persistence = 0.2;
            context_params.weight_stability = 0.2;

            config_.contexts["test_context"] = context_params;

            context_manager_ = std::make_unique<ContextManager>(config_);
        }

        Detection createDetection(
            const std::string &class_name,
            double x, double y, double confidence)
        {
            Detection det;
            det.class_name = class_name;
            det.confidence = confidence;
            det.pose.header.frame_id = "odom";
            det.pose.pose.position.x = x;
            det.pose.pose.position.y = y;
            det.pose.pose.position.z = 0.0;
            det.pose.pose.orientation.w = 1.0;
            det.distance_to_robot = std::sqrt(x * x + y * y);
            return det;
        }

        ValidationResult createValidationResult(double x, double y)
        {
            ValidationResult val;
            val.is_valid = true;
            val.distance_to_robot = std::sqrt(x * x + y * y);
            val.reachability_score = 1.0;
            val.costmap_valid = true;
            val.pose_in_map.header.frame_id = "odom";
            val.pose_in_map.pose.position.x = x;
            val.pose_in_map.pose.position.y = y;
            val.pose_in_map.pose.position.z = 0.0;
            val.pose_in_map.pose.orientation.w = 1.0;
            return val;
        }

        params::PerceptionInterfaceParams config_;
        std::unique_ptr<ContextManager> context_manager_;
    };
    TEST_F(ContextManagerTest, CreateNewContextManager)
    {

        context_manager_.reset(); // Reset to ensure clean state
        context_manager_ = std::make_unique<ContextManager>(config_);
        EXPECT_TRUE(context_manager_ != nullptr);
        EXPECT_EQ(context_manager_->getActiveContext(), "");
        EXPECT_TRUE(context_manager_->getTargetClasses().empty());
    }

    TEST_F(ContextManagerTest, ActivateContext)
    {
        EXPECT_TRUE(context_manager_->activateContext(std::string("test_context")));

        EXPECT_TRUE(context_manager_->getActiveContext() == "test_context");
    }
    TEST_F(ContextManagerTest, DeactivateContext)
    {
        context_manager_->activateContext("test_context");
        context_manager_->deactivateContext();

        EXPECT_TRUE(context_manager_->getActiveContext().empty());
        EXPECT_TRUE(context_manager_->getTargetClasses().empty());
    }

    TEST_F(ContextManagerTest, FilterDetection)
    {
        context_manager_->activateContext("test_context");

        Detection det = createDetection("door", 3.0, 0.0, 0.8);
        EXPECT_TRUE(context_manager_->filterDetection(det));

        // Test with a class not in the context
        det.class_name = "unknown";
        EXPECT_FALSE(context_manager_->filterDetection(det));

        // Test with low confidence
        det.class_name = "door";
        det.confidence = 0.5;
        EXPECT_FALSE(context_manager_->filterDetection(det));
    }
}