#include <gtest/gtest.h>
#include "perception_interface/candidate_tracker.hpp"
#include <chrono>

namespace perception_interface
{

    class CandidateTrackerTest : public ::testing::Test
    {
    protected:
        void SetUp() override
        {
            // Configuration for testing
            config_.max_association_distance = 1.0;
            config_.max_coasting_cycles = 3.0;
            config_.min_hits_to_confirm = 3.0;
            config_.max_time_gap = 0.5;

            tracker_ = std::make_unique<CandidateTracker>(config_);
        }

        Detection createDetection(
            const std::string &class_name,
            double x, double y, double confidence)
        {
            Detection det;
            det.class_name = class_name;
            det.confidence = confidence;
            det.pose.header.frame_id = "odom";
            det.pose.pose.position.x = x;
            det.pose.pose.position.y = y;
            det.pose.pose.position.z = 0.0;
            det.pose.pose.orientation.w = 1.0;
            det.distance_to_robot = std::sqrt(x * x + y * y);
            return det;
        }

        ValidationResult createValidationResult(double x, double y)
        {
            ValidationResult val;
            val.is_valid = true;
            val.distance_to_robot = std::sqrt(x * x + y * y);
            val.reachability_score = 1.0;
            val.costmap_valid = true;
            val.pose_in_map.header.frame_id = "odom";
            val.pose_in_map.pose.position.x = x;
            val.pose_in_map.pose.position.y = y;
            val.pose_in_map.pose.position.z = 0.0;
            val.pose_in_map.pose.orientation.w = 1.0;
            return val;
        }

        params::TrackingParams config_;
        std::unique_ptr<CandidateTracker> tracker_;
    };

    TEST_F(CandidateTrackerTest, CreateNewTrack)
    {
        auto current_time = std::chrono::steady_clock::now();

        // Create a detection
        auto det = createDetection("door", 3.0, 0.0, 0.85);
        auto val = createValidationResult(3.0, 0.0);

        std::vector<std::pair<Detection, ValidationResult>> detections = {{det, val}};

        // Update tracker
        auto tracks = tracker_->update(detections, current_time);

        // Verify one track created
        EXPECT_EQ(tracks.size(), 1);

        // Verify track properties
        auto track = tracks.begin()->second;
        EXPECT_EQ(track->getClassName(), "door");
        EXPECT_EQ(track->getState(), TrackState::TENTATIVE);
        EXPECT_NEAR(track->getLatestDetection().pose.pose.position.x, 3.0, 0.01);
    }

    TEST_F(CandidateTrackerTest, TrackAssociation)
    {
        auto time1 = std::chrono::steady_clock::now();

        // First detection
        auto det1 = createDetection("door", 3.0, 0.0, 0.85);
        auto val1 = createValidationResult(3.0, 0.0);
        std::vector<std::pair<Detection, ValidationResult>> detections1 = {{det1, val1}};

        auto tracks1 = tracker_->update(detections1, time1);
        EXPECT_EQ(tracks1.size(), 1);
        int track_id = tracks1.begin()->first;

        // Second detection (slightly moved)
        auto time2 = time1 + std::chrono::milliseconds(100);
        auto det2 = createDetection("door", 3.1, 0.1, 0.86);
        auto val2 = createValidationResult(3.1, 0.1);
        std::vector<std::pair<Detection, ValidationResult>> detections2 = {{det2, val2}};

        auto tracks2 = tracker_->update(detections2, time2);

        // Should still have one track (associated)
        EXPECT_EQ(tracks2.size(), 1);
        EXPECT_EQ(tracks2.begin()->first, track_id);

        // Track should be updated
        auto track = tracks2.begin()->second;
        EXPECT_NEAR(track->getLatestDetection().pose.pose.position.x, 3.1, 0.01);
    }

    TEST_F(CandidateTrackerTest, StateTransitions)
    {
        auto current_time = std::chrono::steady_clock::now();

        // Create consistent detections to confirm track
        auto det = createDetection("door", 13.0, 0.0, 0.85);
        auto val = createValidationResult(13.0, 0.0);
        std::vector<std::pair<Detection, ValidationResult>> detections = {{det, val}};

        // Update 3 times to confirm
        for (int i = 0; i < 3; ++i)
        {
            current_time += std::chrono::milliseconds(100);
            auto tracks = tracker_->update(detections, current_time);
            int state_int = static_cast<int>(tracks.begin()->second->getState());
            std::cout<< "Track state after update " << i << ": " <<  state_int<<" | Tentative INT IS: "<<static_cast<int>(TrackState::TENTATIVE) <<" | Confirmed is: "<<static_cast<int>(TrackState::CONFIRMED)<< std::endl;
            if (i < 2)
            {
                EXPECT_EQ(state_int, static_cast<int>(TrackState::TENTATIVE));
            }
            else
            {
                EXPECT_EQ(state_int, static_cast<int>(TrackState::CONFIRMED));
            }
        }
    }

    TEST_F(CandidateTrackerTest, CoastingBehavior)
    {
        auto current_time = std::chrono::steady_clock::now();

        // Create and confirm a track
        auto det = createDetection("door", 3.0, 0.0, 0.85);
        auto val = createValidationResult(3.0, 0.0);
        std::vector<std::pair<Detection, ValidationResult>> detections = {{det, val}};

        // Confirm track
        for (int i = 0; i < 3; ++i)
        {
            current_time += std::chrono::milliseconds(100);
            tracker_->update(detections, current_time);
        }

        // Now send empty detections (occlusion)
        std::vector<std::pair<Detection, ValidationResult>> empty_detections;

        // First miss - should go to COASTING
        current_time += std::chrono::milliseconds(100);
        auto tracks = tracker_->update(empty_detections, current_time);
        EXPECT_EQ(tracks.size(), 1);
        EXPECT_EQ(tracks.begin()->second->getState(), TrackState::COASTING);

        // Continue missing for max_coasting_cycles
        for (int i = 0; i < 3; ++i)
        {
            current_time += std::chrono::milliseconds(100);
            tracks = tracker_->update(empty_detections, current_time);
        }

        // Should be deleted after max coasting
        EXPECT_EQ(tracks.size(), 0);
    }

    TEST_F(CandidateTrackerTest, MultipleObjectTracking)
    {
        auto current_time = std::chrono::steady_clock::now();

        // Create two different objects
        auto det1 = createDetection("door", 3.0, 0.0, 0.85);
        auto val1 = createValidationResult(3.0, 0.0);
        auto det2 = createDetection("stairs_up", 2.0, 2.0, 0.78);
        auto val2 = createValidationResult(2.0, 2.0);

        std::vector<std::pair<Detection, ValidationResult>> detections = {
            {det1, val1}, {det2, val2}};

        auto tracks = tracker_->update(detections, current_time);

        // Should have two tracks
        EXPECT_EQ(tracks.size(), 2);

        // Verify different classes
        std::set<std::string> classes;
        for (const auto &[id, track] : tracks)
        {
            classes.insert(track->getClassName());
        }
        EXPECT_EQ(classes.size(), 2);
        EXPECT_TRUE(classes.count("door") > 0);
        EXPECT_TRUE(classes.count("stairs_up") > 0);
    }

    TEST_F(CandidateTrackerTest, NoAssociationForDifferentClasses)
    {
        auto time1 = std::chrono::steady_clock::now();

        // First detection - door
        auto det1 = createDetection("door", 3.0, 0.0, 0.85);
        auto val1 = createValidationResult(3.0, 0.0);
        std::vector<std::pair<Detection, ValidationResult>> detections1 = {{det1, val1}};

        tracker_->update(detections1, time1);

        // Second detection - stairs at same position
        auto time2 = time1 + std::chrono::milliseconds(100);
        auto det2 = createDetection("stairs_up", 3.0, 0.0, 0.78);
        auto val2 = createValidationResult(3.0, 0.0);
        std::vector<std::pair<Detection, ValidationResult>> detections2 = {{det2, val2}};

        auto tracks = tracker_->update(detections2, time2);

        // Should have two tracks (no association due to different classes)
        EXPECT_EQ(tracks.size(), 2);
    }

} // namespace perception_interface