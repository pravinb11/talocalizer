#include <gtest/gtest.h>
#include "perception_interface/spatial_validator.hpp"
#include <tf2_ros/static_transform_broadcaster.h>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <chrono>
#include <thread>

namespace perception_interface
{

class SpatialValidatorTest : public ::testing::Test
{
protected:
  void SetUp() override
  {
    // Initialize ROS
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }
    
    // Create node for testing
    node_ = std::make_shared<rclcpp::Node>("spatial_validator_test_node");
    
    // Create parameters
    params_.global.global_frame_id = "map";
    params_.global.base_frame_id = "base_link";
    params_.global.costmap_topic = "/test_costmap";
    
    // Create spatial validator
    spatial_validator_ = std::make_unique<SpatialValidator>(node_, params_);
    
    // Create static transform broadcaster for TF
    tf_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(node_);
    
    // Create costmap publisher
    costmap_pub_ = node_->create_publisher<nav_msgs::msg::OccupancyGrid>(
      params_.global.costmap_topic, 10);
    
    // Publish initial transforms
    publishRobotTransform(0.0, 0.0, 0.0);
    
    // Give TF time to update
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
  
  void TearDown() override
  {
    spatial_validator_.reset();
    node_.reset();
    rclcpp::shutdown();
  }
  
  void publishRobotTransform(double x, double y, double theta)
  {
    geometry_msgs::msg::TransformStamped transform;
    transform.header.stamp = node_->get_clock()->now();
    transform.header.frame_id = params_.global.global_frame_id;
    transform.child_frame_id = params_.global.base_frame_id;
    transform.transform.translation.x = x;
    transform.transform.translation.y = y;
    transform.transform.translation.z = 0.0;
    
    tf2::Quaternion q;
    q.setRPY(0, 0, theta);
    transform.transform.rotation.x = q.x();
    transform.transform.rotation.y = q.y();
    transform.transform.rotation.z = q.z();
    transform.transform.rotation.w = q.w();
    
    tf_broadcaster_->sendTransform(transform);
    
    // Give TF time to update
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
  }
  
  Detection createDetection(const std::string& class_name, 
                           double x, double y, double confidence)
  {
    Detection det;
    det.header.stamp = node_->get_clock()->now();
    det.header.frame_id = params_.global.global_frame_id;
    det.class_name = class_name;
    det.confidence = confidence;
    
    // Already in map frame for testing
    det.pose.header = det.header;
    det.pose.pose.position.x = x;
    det.pose.pose.position.y = y;
    det.pose.pose.position.z = 0.0;
    det.pose.pose.orientation.w = 1.0;
    
    return det;
  }
  
  nav_msgs::msg::OccupancyGrid createTestCostmap(
    double origin_x, double origin_y, 
    double resolution, int width, int height)
  {
    nav_msgs::msg::OccupancyGrid costmap;
    costmap.header.frame_id = params_.global.global_frame_id;
    costmap.header.stamp = node_->get_clock()->now();
    
    costmap.info.resolution = resolution;
    costmap.info.width = width;
    costmap.info.height = height;
    costmap.info.origin.position.x = origin_x;
    costmap.info.origin.position.y = origin_y;
    costmap.info.origin.orientation.w = 1.0;
    
    // Initialize with free space
    costmap.data.resize(width * height, 0);
    
    return costmap;
  }
  
  void addObstacleToCostmap(nav_msgs::msg::OccupancyGrid& costmap,
                           int x_cell, int y_cell, int radius_cells = 1)
  {
    int width = costmap.info.width;
    int height = costmap.info.height;
    
    for (int dy = -radius_cells; dy <= radius_cells; dy++)
    {
      for (int dx = -radius_cells; dx <= radius_cells; dx++)
      {
        int x = x_cell + dx;
        int y = y_cell + dy;
        
        if (x >= 0 && x < width && y >= 0 && y < height)
        {
          int index = y * width + x;
          if (dx == 0 && dy == 0)
          {
            costmap.data[index] = 254;  // Lethal obstacle
          }
          else if (std::abs(dx) <= 1 && std::abs(dy) <= 1)
          {
            costmap.data[index] = 253;  // Inflated obstacle
          }
        }
      }
    }
  }

  std::shared_ptr<rclcpp::Node> node_;
  params::PerceptionInterfaceParams params_;
  std::unique_ptr<SpatialValidator> spatial_validator_;
  std::shared_ptr<tf2_ros::StaticTransformBroadcaster> tf_broadcaster_;
  rclcpp::Publisher<nav_msgs::msg::OccupancyGrid>::SharedPtr costmap_pub_;
};

TEST_F(SpatialValidatorTest, BasicValidation)
{
  // Create detection 3 meters ahead
  auto detection = createDetection("door", 3.0, 0.0, 0.85);
  
  params::ContextParams context;
  context.max_distance = 5.0;
  
  auto result = spatial_validator_->validate(detection, context);
  
  EXPECT_TRUE(result.is_valid);
  EXPECT_NEAR(result.distance_to_robot, 3.0, 0.01);
  EXPECT_GT(result.reachability_score, 0.0);
}

TEST_F(SpatialValidatorTest, DistanceCalculation)
{
  // Test various positions
  struct TestCase {
    double x, y;
    double expected_distance;
  };
  
  std::vector<TestCase> test_cases = {
    {3.0, 0.0, 3.0},      // Straight ahead
    {0.0, 4.0, 4.0},      // To the side
    {3.0, 4.0, 5.0},      // Diagonal (3-4-5 triangle)
    {-2.0, 0.0, 2.0},     // Behind
  };
  
  params::ContextParams context;
  context.max_distance = 10.0;
  
  for (const auto& tc : test_cases)
  {
    auto detection = createDetection("door", tc.x, tc.y, 0.85);
    auto result = spatial_validator_->validate(detection, context);
    
    EXPECT_NEAR(result.distance_to_robot, tc.expected_distance, 0.01)
      << "Failed for position (" << tc.x << ", " << tc.y << ")";
  }
}

TEST_F(SpatialValidatorTest, MaxDistanceFilter)
{
  params::ContextParams context;
  context.max_distance = 5.0;
  
  // Within range
  auto near_detection = createDetection("door", 4.0, 0.0, 0.85);
  auto near_result = spatial_validator_->validate(near_detection, context);
  EXPECT_TRUE(near_result.is_valid);
  
  // Beyond range
  auto far_detection = createDetection("door", 6.0, 0.0, 0.85);
  auto far_result = spatial_validator_->validate(far_detection, context);
  EXPECT_FALSE(far_result.is_valid);
  EXPECT_FALSE(far_result.rejection_reasons.empty());
}

TEST_F(SpatialValidatorTest, RobotPoseUpdate)
{
  // Move robot and verify distance calculations update
  publishRobotTransform(2.0, 0.0, 0.0);  // Robot at (2, 0)
  
  auto detection = createDetection("door", 5.0, 0.0, 0.85);  // Door at (5, 0)
  
  params::ContextParams context;
  context.max_distance = 5.0;
  
  auto result = spatial_validator_->validate(detection, context);
  
  // Distance should be 3.0 (5 - 2)
  EXPECT_NEAR(result.distance_to_robot, 3.0, 0.01);
  EXPECT_TRUE(result.is_valid);
}

TEST_F(SpatialValidatorTest, GetRobotPose)
{
  // Test the getRobotPose function
  geometry_msgs::msg::PoseStamped pose;
  
  bool success = spatial_validator_->getRobotPose(pose);
  
  EXPECT_TRUE(success);
  EXPECT_EQ(pose.header.frame_id, params_.global.global_frame_id);
  EXPECT_NEAR(pose.pose.position.x, 0.0, 0.01);
  EXPECT_NEAR(pose.pose.position.y, 0.0, 0.01);
}
TEST_F(SpatialValidatorTest, ReachabilityScore)
{
  params::ContextParams context;
  context.max_distance = 10.0;
  
  // Test reachability at different distances
  struct TestCase {
    double distance;
    double min_expected_score;
  };
  
  std::vector<TestCase> test_cases = {
    {0.5, 0.9},   // Very close - high score
    {2.0, 0.6},   // Medium distance
    {5.0, 0.3},   // Far - lower score
    {10.0, 0.1},  // Very far - low score
  };
  
  for (const auto& tc : test_cases)
  {
    auto detection = createDetection("door", tc.distance, 0.0, 0.85);
    auto result = spatial_validator_->validate(detection, context);
    
    EXPECT_GT(result.reachability_score, tc.min_expected_score)
      << "Failed for distance " << tc.distance;
    EXPECT_LE(result.reachability_score, 1.0);
  }
}


}  // namespace perception_interface