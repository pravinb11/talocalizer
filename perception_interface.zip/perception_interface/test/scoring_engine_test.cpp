#include <gtest/gtest.h>
#include "perception_interface/scoring_engine.hpp"
#include "perception_interface/context_manager.hpp"
#include "perception_interface/candidate_tracker.hpp"
#include <chrono>
#include <cmath>

namespace perception_interface
{

    class ScoringEngineTest : public ::testing::Test
    {
    protected:
        void SetUp() override
        {
            // Setup test context configuration
            setupTestContext();

            // Create context manager
            context_manager_ = std::make_shared<ContextManager>(params_);

            // Create scoring engine
            scoring_engine_ = std::make_unique<ScoringEngine>(context_manager_);

            // Create tracker for generating test candidates
            tracker_ = std::make_unique<CandidateTracker>(tracking_params_);

            // Activate the test context
            context_manager_->activateContext("test_context");
        }

        void setupTestContext()
        {
            // Setup tracking parameters
            tracking_params_.max_association_distance = 1.0;
            tracking_params_.max_coasting_cycles = 3;
            tracking_params_.min_hits_to_confirm = 3;
            tracking_params_.detection_history_size = 30;
            tracking_params_.max_time_gap = 0.5;

            // Setup test context
            params::ContextParams context;
            context.name = "test_context";
            context.primary_classes = {"door", "stairs_up"};
            context.secondary_classes = {"sign", "arrow"};
            context.confidence_threshold = 0.7;
            context.max_distance = 5.0;
            context.boost_score_after_time = 30.0;

            // Scoring weights
            context.weight_confidence = 0.3;
            context.weight_distance = 0.3;
            context.weight_persistence = 0.2;
            context.weight_stability = 0.2;

            params_.contexts["test_context"] = context;
        }

        Detection createDetection(const std::string &class_name,
                                  double x, double y, double confidence)
        {
            Detection det;
            det.header.stamp = rclcpp::Time(0, 0);
            det.header.frame_id = "map";
            det.class_name = class_name;
            det.confidence = confidence;
            det.pose.header = det.header;
            det.pose.pose.position.x = x;
            det.pose.pose.position.y = y;
            det.pose.pose.position.z = 0.0;
            det.pose.pose.orientation.w = 1.0;
            det.distance_to_robot = std::sqrt(x * x + y * y);
            return det;
        }

        ValidationResult createValidationResult(double x, double y)
        {
            ValidationResult val;
            val.is_valid = true;
            val.distance_to_robot = std::sqrt(x * x + y * y);
            val.reachability_score = 1.0;
            val.costmap_valid = true;
            val.pose_in_map.header.frame_id = "map";
            val.pose_in_map.pose.position.x = x;
            val.pose_in_map.pose.position.y = y;
            val.pose_in_map.pose.position.z = 0.0;
            val.pose_in_map.pose.orientation.w = 1.0;
            return val;
        }

        // Helper to create a confirmed track with detection history
        std::shared_ptr<TrackedCandidate> createConfirmedTrack(
            const std::string &class_name,
            double x, double y,
            const std::vector<double> &confidence_sequence,
            const std::vector<std::pair<double, double>> &position_sequence = {})
        {
            auto current_time = std::chrono::steady_clock::now();

            // Create initial detection
            auto det = createDetection(class_name, x, y, confidence_sequence[0]);
            auto val = createValidationResult(x, y);

            // Create candidate
            auto candidate = std::make_shared<TrackedCandidate>(det, val, current_time, tracking_params_);

            // Add detection history to reach confirmed state
            for (size_t i = 1; i < confidence_sequence.size(); ++i)
            {
                current_time += std::chrono::milliseconds(100);

                // Use position sequence if provided, otherwise keep same position
                double pos_x = x, pos_y = y;
                if (!position_sequence.empty() && i - 1 < position_sequence.size())
                {
                    pos_x = position_sequence[i - 1].first;
                    pos_y = position_sequence[i - 1].second;
                }

                auto next_det = createDetection(class_name, pos_x, pos_y, confidence_sequence[i]);
                auto next_val = createValidationResult(pos_x, pos_y);

                candidate->update(next_det, next_val, current_time);
            }

            // Force to confirmed state if we have enough detections
            if (confidence_sequence.size() >= tracking_params_.min_hits_to_confirm)
            {
                candidate->state_ = TrackState::CONFIRMED;
            }

            return candidate;
        }

    protected:
        params::PerceptionInterfaceParams params_;
        params::TrackingParams tracking_params_;
        std::shared_ptr<ContextManager> context_manager_;
        std::unique_ptr<ScoringEngine> scoring_engine_;
        std::unique_ptr<CandidateTracker> tracker_;
    };

    TEST_F(ScoringEngineTest, BasicScoring)
    {
        // Create a simple confirmed track
        std::vector<double> confidences = {0.8, 0.85, 0.9};
        auto candidate = createConfirmedTrack("door", 3.0, 0.0, confidences);

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[candidate->getTrackId()] = candidate;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        EXPECT_EQ(scores.size(), 1);
        EXPECT_GT(scores.begin()->second, 0.0);
        EXPECT_LE(scores.begin()->second, 1.0);
    }

    TEST_F(ScoringEngineTest, OnlyConfirmedTracksScored)
    {
        // Create tracks in different states
        auto tentative_track = createConfirmedTrack("door", 3.0, 0.0, {0.8}); // Only 1 detection = tentative
        tentative_track->state_ = TrackState::TENTATIVE;

        auto confirmed_track = createConfirmedTrack("door", 4.0, 0.0, {0.8, 0.85, 0.9});
        confirmed_track->state_ = TrackState::CONFIRMED;

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[tentative_track->getTrackId()] = tentative_track;
        tracks[confirmed_track->getTrackId()] = confirmed_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        // Only confirmed track should be scored
        EXPECT_EQ(scores.size(), 1);
        EXPECT_TRUE(scores.find(confirmed_track->getTrackId()) != scores.end());
        EXPECT_TRUE(scores.find(tentative_track->getTrackId()) == scores.end());
    }

    TEST_F(ScoringEngineTest, ConfidenceFactorScoring)
    {
        // Test different confidence levels
        auto high_conf_track = createConfirmedTrack("door", 3.0, 0.0, {0.95, 0.96, 0.97});
        auto med_conf_track = createConfirmedTrack("door", 3.0, 1.0, {0.75, 0.76, 0.77});
        auto low_conf_track = createConfirmedTrack("door", 3.0, 2.0, {0.70, 0.71, 0.72});

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[high_conf_track->getTrackId()] = high_conf_track;
        tracks[med_conf_track->getTrackId()] = med_conf_track;
        tracks[low_conf_track->getTrackId()] = low_conf_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        EXPECT_EQ(scores.size(), 3);

        double high_score = scores[high_conf_track->getTrackId()];
        double med_score = scores[med_conf_track->getTrackId()];
        double low_score = scores[low_conf_track->getTrackId()];

        // Higher confidence should yield higher scores
        EXPECT_GT(high_score, med_score);
        EXPECT_GT(med_score, low_score);
    }

    TEST_F(ScoringEngineTest, DistanceFactorScoring)
    {
        // Test different distances (same confidence)
        std::vector<double> same_confidences = {0.85, 0.85, 0.85};

        auto close_track = createConfirmedTrack("door", 1.0, 0.0, same_confidences);
        auto med_track = createConfirmedTrack("door", 3.0, 0.0, same_confidences);
        auto far_track = createConfirmedTrack("door", 4.5, 0.0, same_confidences);

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[close_track->getTrackId()] = close_track;
        tracks[med_track->getTrackId()] = med_track;
        tracks[far_track->getTrackId()] = far_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        EXPECT_EQ(scores.size(), 3);

        double close_score = scores[close_track->getTrackId()];
        double med_score = scores[med_track->getTrackId()];
        double far_score = scores[far_track->getTrackId()];

        // Closer objects should score higher
        EXPECT_GT(close_score, med_score);
        EXPECT_GT(med_score, far_score);
    }

    TEST_F(ScoringEngineTest, StabilityFactorScoring)
    {
        // Test stable vs unstable position tracking
        std::vector<double> same_confidences = {0.85, 0.85, 0.85, 0.85, 0.85};

        // Stable track - same position
        std::vector<std::pair<double, double>> stable_positions = {
            {3.0, 0.0}, {3.01, 0.01}, {2.99, -0.01}, {3.0, 0.0}};

        // Unstable track - varying positions
        std::vector<std::pair<double, double>> unstable_positions = {
            {3.0, 0.0}, {3.5, 0.3}, {2.8, -0.2}, {3.2, 0.4}};

        auto stable_track = createConfirmedTrack("door", 3.0, 0.0, same_confidences, stable_positions);
        auto unstable_track = createConfirmedTrack("door", 3.0, 1.0, same_confidences, unstable_positions);

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[stable_track->getTrackId()] = stable_track;
        tracks[unstable_track->getTrackId()] = unstable_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        EXPECT_EQ(scores.size(), 2);

        double stable_score = scores[stable_track->getTrackId()];
        double unstable_score = scores[unstable_track->getTrackId()];

        // More stable track should score higher
        EXPECT_GT(stable_score, unstable_score);
    }

    TEST_F(ScoringEngineTest, PrimaryVsSecondaryClassModifier)
    {
        // Test primary vs secondary class scoring
        std::vector<double> same_confidences = {0.85, 0.85, 0.85};

        auto primary_track = createConfirmedTrack("door", 3.0, 0.0, same_confidences);   // Primary class
        auto secondary_track = createConfirmedTrack("sign", 3.0, 0.0, same_confidences); // Secondary class

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[primary_track->getTrackId()] = primary_track;
        tracks[secondary_track->getTrackId()] = secondary_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        EXPECT_EQ(scores.size(), 2);

        double primary_score = scores[primary_track->getTrackId()];
        double secondary_score = scores[secondary_track->getTrackId()];

        // Primary class should score higher than secondary
        EXPECT_GT(primary_score, secondary_score);
    }

    TEST_F(ScoringEngineTest, HighConfidenceBurstBonus)
    {
        // Test high confidence burst bonus
        std::vector<double> burst_confidences = {0.92, 0.94, 0.96, 0.95, 0.97};  // All > 0.9
        std::vector<double> normal_confidences = {0.82, 0.84, 0.86, 0.85, 0.87}; // Normal confidences

        auto burst_track = createConfirmedTrack("door", 3.0, 0.0, burst_confidences);
        auto normal_track = createConfirmedTrack("door", 3.0, 1.0, normal_confidences);

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[burst_track->getTrackId()] = burst_track;
        tracks[normal_track->getTrackId()] = normal_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        EXPECT_EQ(scores.size(), 2);

        double burst_score = scores[burst_track->getTrackId()];
        double normal_score = scores[normal_track->getTrackId()];

        // High confidence burst should get bonus
        EXPECT_GT(burst_score, normal_score);
    }

    TEST_F(ScoringEngineTest, ScoreHistoryUpdating)
    {
        // Test that score history is properly updated
        auto candidate = createConfirmedTrack("door", 3.0, 0.0, {0.8, 0.85, 0.9});

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[candidate->getTrackId()] = candidate;

        size_t initial_history_size = candidate->score_history_.size();

        auto scores = scoring_engine_->scoreCandidates(tracks);

        // Score history should be updated
        EXPECT_EQ(candidate->score_history_.size(), initial_history_size + 1);
        EXPECT_EQ(candidate->score_history_.back(), scores[candidate->getTrackId()]);
    }

    TEST_F(ScoringEngineTest, BestScoreTracking)
    {
        // Test best score tracking
        auto candidate = createConfirmedTrack("door", 3.0, 0.0, {0.8, 0.85, 0.9});

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[candidate->getTrackId()] = candidate;

        double initial_best = candidate->best_score_;

        auto scores = scoring_engine_->scoreCandidates(tracks);
        double current_score = scores[candidate->getTrackId()];

        // Best score should be updated if current score is higher
        EXPECT_GE(candidate->best_score_, initial_best);
        EXPECT_GE(candidate->best_score_, current_score);
    }

    TEST_F(ScoringEngineTest, WeightedScoringVerification)
    {
        // Test that scoring weights are properly applied
        // Create context with extreme weights to test individual factors

        // Backup original context
        auto original_context = params_.contexts["test_context"];

        // Test confidence-only weighting
        params_.contexts["test_context"].weight_confidence = 1.0;
        params_.contexts["test_context"].weight_distance = 0.0;
        params_.contexts["test_context"].weight_persistence = 0.0;
        params_.contexts["test_context"].weight_stability = 0.0;

        // Use same distance to isolate confidence factor
        auto high_conf_track = createConfirmedTrack("door", 3.0, 0.0, {0.95, 0.96, 0.97}); // High confidence
        auto low_conf_track = createConfirmedTrack("door", 3.0, 1.0, {0.70, 0.71, 0.72});  // Low confidence, same distance

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[high_conf_track->getTrackId()] = high_conf_track;
        tracks[low_conf_track->getTrackId()] = low_conf_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        double high_conf_score = scores[high_conf_track->getTrackId()];
        double low_conf_score = scores[low_conf_track->getTrackId()];

        // With confidence-only weighting, high confidence should win
        EXPECT_GT(high_conf_score, low_conf_score);

        // Restore original context
        params_.contexts["test_context"] = original_context;
    }

    TEST_F(ScoringEngineTest, DistanceOnlyWeighting)
    {
        // Test distance-only weighting to verify the weighting system works

        // Backup original context
        auto original_context = params_.contexts["test_context"];

        // Distance-only weighting
        params_.contexts["test_context"].weight_confidence = 0.0;
        params_.contexts["test_context"].weight_distance = 1.0;
        params_.contexts["test_context"].weight_persistence = 0.0;
        params_.contexts["test_context"].weight_stability = 0.0;

        // Same confidence, different distances
        std::vector<double> same_conf = {0.85, 0.85, 0.85};
        auto close_track = createConfirmedTrack("door", 1.0, 0.0, same_conf);
        auto far_track = createConfirmedTrack("door", 4.0, 0.0, same_conf);

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[close_track->getTrackId()] = close_track;
        tracks[far_track->getTrackId()] = far_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        double close_score = scores[close_track->getTrackId()];
        double far_score = scores[far_track->getTrackId()];

        // With distance-only weighting, closer should win
        EXPECT_GT(close_score, far_score);

        // Restore original context
        params_.contexts["test_context"] = original_context;
    }

    TEST_F(ScoringEngineTest, EmptyTracksHandling)
    {
        // Test scoring with empty tracks map
        std::map<int, std::shared_ptr<TrackedCandidate>> empty_tracks;

        auto scores = scoring_engine_->scoreCandidates(empty_tracks);

        EXPECT_TRUE(scores.empty());
    }

    TEST_F(ScoringEngineTest, ScoreBounds)
    {
        // Test that scores are always within [0, 1] bounds
        // Create extreme cases

        // Very high confidence, very close, very stable
        std::vector<double> perfect_confidences = {0.99, 0.99, 0.99, 0.99, 0.99};
        std::vector<std::pair<double, double>> stable_positions = {
            {0.1, 0.0}, {0.1, 0.0}, {0.1, 0.0}, {0.1, 0.0}};
        auto perfect_track = createConfirmedTrack("door", 0.1, 0.0, perfect_confidences, stable_positions);

        // Very low confidence, very far, very unstable
        std::vector<double> poor_confidences = {0.70, 0.70, 0.70, 0.70, 0.70};
        std::vector<std::pair<double, double>> unstable_positions = {
            {4.9, 0.0}, {4.7, 0.5}, {4.8, -0.3}, {4.6, 0.8}};
        auto poor_track = createConfirmedTrack("door", 4.9, 0.0, poor_confidences, unstable_positions);

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[perfect_track->getTrackId()] = perfect_track;
        tracks[poor_track->getTrackId()] = poor_track;

        auto scores = scoring_engine_->scoreCandidates(tracks);

        for (const auto &[track_id, score] : scores)
        {
            EXPECT_GE(score, 0.0) << "Score below 0.0 for track " << track_id;
            EXPECT_LE(score, 1.0) << "Score above 1.0 for track " << track_id;
        }
    }

    TEST_F(ScoringEngineTest, ConsistentFramesPercentageUpdating)
    {
        // Test that consistent_frames_perc_ is properly updated
        auto candidate = createConfirmedTrack("door", 1.0, 0.0, {0.8, 0.85, 0.9, 0.95, 0.85});

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[candidate->getTrackId()] = candidate;

        double initial_consistency = candidate->consistent_frames_perc_;

        auto scores = scoring_engine_->scoreCandidates(tracks);
        // scores = scoring_engine_->scoreCandidates(tracks);

        // Consistent frames percentage should be updated
        EXPECT_NE(candidate->consistent_frames_perc_, initial_consistency);
        EXPECT_GE(candidate->consistent_frames_perc_, 0.0);
        EXPECT_LE(candidate->consistent_frames_perc_, 1.0);
    }

    TEST_F(ScoringEngineTest, ConsistencyGrowthTest)
    {
        // Test that consistent_frames_perc_ grows exponentially with consecutive high scores
        auto candidate = createConfirmedTrack("door", 1.5, 0.0,
                                              {0.95, 0.95, 0.95});               // High persistence

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[candidate->getTrackId()] = candidate;

        // Track consistency growth over multiple scoring iterations
        std::vector<double> consistency_progression;
        consistency_progression.push_back(candidate->consistent_frames_perc_); // Initial: 0.0

        // Run multiple scoring iterations
        for (int i = 0; i < 8; ++i)
        {
            auto scores = scoring_engine_->scoreCandidates(tracks);
            consistency_progression.push_back(candidate->consistent_frames_perc_);

            // Verify score is above threshold (should be with high conf + close distance)
            EXPECT_GT(scores[candidate->getTrackId()], context_manager_->getCurrentContext().confidence_threshold);
        }

        // Verify growth pattern
        EXPECT_GT(consistency_progression[1], consistency_progression[0]); // First growth from 0.0
        EXPECT_GT(consistency_progression[3], consistency_progression[1]); // Continued growth
        EXPECT_GT(consistency_progression[6], consistency_progression[3]); // Still growing

        // Verify exponential nature - later increments should be larger
        double early_increment = consistency_progression[2] - consistency_progression[1];
        double later_increment = consistency_progression[6] - consistency_progression[5];
        EXPECT_GT(later_increment, early_increment); // Exponential growth means larger increments later

        // Final consistency should be substantial
        EXPECT_GT(candidate->consistent_frames_perc_, 0.5);

        // Test bounds - should not exceed 1.0
        EXPECT_LE(candidate->consistent_frames_perc_, 1.0);
    }

    TEST_F(ScoringEngineTest, ConsistencyDecayTest)
    {
        // Test that consistent_frames_perc_ properly decays when streak is broken
        // First build up consistency, then test decay

        auto candidate = createConfirmedTrack("door", 1.5, 0.0,   // Close distance for high scores
                                              {0.90, 0.90, 0.90});

        std::map<int, std::shared_ptr<TrackedCandidate>> tracks;
        tracks[candidate->getTrackId()] = candidate;

        // First, build up consistency with multiple high scores
        for (int i = 0; i < 6; ++i)
        {
            auto scores = scoring_engine_->scoreCandidates(tracks);
            // Should get high scores due to high confidence + close distance
            EXPECT_GT(scores[candidate->getTrackId()], context_manager_->getCurrentContext().confidence_threshold);
        }

        double consistency_after_buildup = candidate->consistent_frames_perc_;
        EXPECT_GT(consistency_after_buildup, 0.3); // Should have built up substantial consistency

        // Now create a low score scenario by updating with low confidence detection
        auto low_conf_det = createDetection("door", 4.8, 0.0, 0.60); // Far + very low confidence
        auto low_conf_val = createValidationResult(4.8, 0.0);
        candidate->update(low_conf_det, low_conf_val, std::chrono::steady_clock::now());

        // Score with this low confidence scenario - should get score below threshold
        auto scores = scoring_engine_->scoreCandidates(tracks);

        // Verify we got a low score (below threshold)
        EXPECT_LT(scores[candidate->getTrackId()], context_manager_->getCurrentContext().confidence_threshold);

        // Verify decay happened (should be halved according to formula: *= 0.5)
        EXPECT_LT(candidate->consistent_frames_perc_, consistency_after_buildup);
        EXPECT_NEAR(candidate->consistent_frames_perc_, consistency_after_buildup * 0.5, 0.05);

        // Verify it's still positive (not zero)
        EXPECT_GT(candidate->consistent_frames_perc_, 0.0);
    }
} // namespace perception_interface