from setuptools import setup
import os
from glob import glob

package_name = 'transition_localizer'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your.email@domain.com',
    description='ROS2 package for extracting stereo images from bag files',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'transition_localizer_node = transition_localizer.transition_localizer_node:main',
            'transition_preprocessing_node = transition_localizer.transition_preprocessing_node:main',
            'stereo_image_saver = transition_localizer.stereo_image_saver:main',
            'ta_tmm = transition_localizer.ta_tmm:main',
        ],
    },
)