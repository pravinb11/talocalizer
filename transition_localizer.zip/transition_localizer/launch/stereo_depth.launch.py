import launch
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # Get package directory
    pkg_dir = get_package_share_directory('transition_localizer')
    
    # Declare launch arguments
    bag_path_arg = DeclareLaunchArgument(
        'bag_path',
        default_value='/home/abhijeet/Documents/ros2_ws/src/transition_localizer/bags/stairs_sentry/stairs_sentry_0.db3',
        description='Path to ROS2 bag file'
    )
    
    left_topic_arg = DeclareLaunchArgument(
        'left_topic',
        default_value='/left_camera/image_raw',
        description='Left camera image topic'
    )
    
    right_topic_arg = DeclareLaunchArgument(
        'right_topic',
        default_value='/right_camera/image_raw',
        description='Right camera image topic'
    )
    
    output_dir_arg = DeclareLaunchArgument(
        'output_dir',
        default_value='/home/abhijeet/Documents/ros2_ws/src/transition_localizer/tmp/stereo_output',
        description='Output directory for extracted images'
    )
    
    tolerance_arg = DeclareLaunchArgument(
        'tolerance',
        default_value='0.1',
        description='Timestamp tolerance in seconds'
    )
    
    auto_start_arg = DeclareLaunchArgument(
        'auto_start',
        default_value='false',
        description='Whether to start extraction automatically'
    )
    
    mode_arg = DeclareLaunchArgument(
        'mode',
        default_value='node',
        description='Run mode: node or service'
    )
    
    # Create the node
    transition_localizer_node = Node(
        package='transition_localizer',
        executable='transition_localizer_node',
        name='transition_localizer_node',
        parameters=[{
            'bag_path': LaunchConfiguration('bag_path'),
            'left_topic': LaunchConfiguration('left_topic'),
            'right_topic': LaunchConfiguration('right_topic'),
            'output_dir': LaunchConfiguration('output_dir'),
            'tolerance': LaunchConfiguration('tolerance'),
            'auto_start': LaunchConfiguration('auto_start'),
        }],
        output='screen',
        emulate_tty=True,
        condition=launch.conditions.IfCondition(
            launch.substitutions.PythonExpression([
                '"', LaunchConfiguration('mode'), '" == "node"'
            ])
        )
    )
    
    # Create the service
    transition_localizer_service = Node(
        package='transition_localizer',
        executable='transition_localizer_service',
        name='transition_localizer_service',
        parameters=[{
            'bag_path': LaunchConfiguration('bag_path'),
            'left_topic': LaunchConfiguration('left_topic'),
            'right_topic': LaunchConfiguration('right_topic'),
            'output_dir': LaunchConfiguration('output_dir'),
            'tolerance': LaunchConfiguration('tolerance'),
        }],
        output='screen',
        emulate_tty=True,
        condition=launch.conditions.IfCondition(
            launch.substitutions.PythonExpression([
                '"', LaunchConfiguration('mode'), '" == "service"'
            ])
        )
    )
    
    return LaunchDescription([
        bag_path_arg,
        left_topic_arg,
        right_topic_arg,
        output_dir_arg,
        tolerance_arg,
        auto_start_arg,
        mode_arg,
        
        LogInfo(msg=['Launching stereo extractor in ', LaunchConfiguration('mode'), ' mode']),
        
        transition_localizer_node,
        transition_localizer_service,
    ])