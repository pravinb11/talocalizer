import cv2
import numpy as np
import matplotlib.pyplot as plt

def calculate_disparity(left_img, right_img, method='SGBM', **kwargs):

    # Convert to grayscale if needed
    if len(left_img.shape) == 3:
        left_gray = cv2.cvtColor(left_img, cv2.COLOR_BGR2GRAY)
    else:
        left_gray = left_img.copy()
        
    if len(right_img.shape) == 3:
        right_gray = cv2.cvtColor(right_img, cv2.COLOR_BGR2GRAY)
    else:
        right_gray = right_img.copy()
    
    # Ensure images are the same size
    if left_gray.shape != right_gray.shape:
        raise ValueError("Left and right images must have the same dimensions")
    
    if method == 'BM':
        # Block Matching (faster but less accurate)
        stereo = cv2.StereoBM_create(
            numDisparities=kwargs.get('numDisparities', 16*5),
            blockSize=kwargs.get('blockSize', 15)
        )
        
        # Additional BM parameters
        stereo.setPreFilterCap(kwargs.get('preFilterCap', 31))
        stereo.setMinDisparity(kwargs.get('minDisparity', 0))
        stereo.setTextureThreshold(kwargs.get('textureThreshold', 10))
        stereo.setUniquenessRatio(kwargs.get('uniquenessRatio', 15))
        stereo.setSpeckleRange(kwargs.get('speckleRange', 32))
        stereo.setSpeckleWindowSize(kwargs.get('speckleWindowSize', 100))
        
    elif method == 'SGBM':
        # Semi-Global Block Matching (slower but more accurate)
        stereo = cv2.StereoSGBM_create(
            minDisparity=kwargs.get('minDisparity', 0),
            numDisparities=kwargs.get('numDisparities', 16*5),
            blockSize=kwargs.get('blockSize', 5),
            P1=kwargs.get('P1', 8 * 3 * kwargs.get('blockSize', 5)**2),
            P2=kwargs.get('P2', 32 * 3 * kwargs.get('blockSize', 5)**2),
            disp12MaxDiff=kwargs.get('disp12MaxDiff', 1),
            uniquenessRatio=kwargs.get('uniquenessRatio', 10),
            speckleWindowSize=kwargs.get('speckleWindowSize', 100),
            speckleRange=kwargs.get('speckleRange', 32)
        )
    else:
        raise ValueError("Method must be 'BM' or 'SGBM'")
    
    # Compute disparity
    disparity = stereo.compute(left_gray, right_gray)
    
    # Convert to float and normalize
    disparity = disparity.astype(np.float32) / 16.0
    
    return disparity

def preprocess_images(left_img, right_img, clahe=True, gaussian_blur=True):
    
    def process_single_image(img):
        # Convert to grayscale if needed
        if len(img.shape) == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img.copy()
        
        # Apply CLAHE for better contrast
        if clahe:
            clahe_obj = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            gray = clahe_obj.apply(gray)
        
        # Apply Gaussian blur to reduce noise
        if gaussian_blur:
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            
        return gray
    
    left_processed = process_single_image(left_img)
    right_processed = process_single_image(right_img)
    
    return left_processed, right_processed

def depth_from_disparity(disparity, focal_length, baseline):
    
    # Avoid division by zero
    disparity_safe = np.where(disparity > 0, disparity, 0.1)
    
    # Calculate depth: depth = (focal_length * baseline) / disparity
    depth = (focal_length * baseline) / disparity_safe
    
    # Set invalid disparities to infinity
    depth[disparity <= 0] = np.inf
    
    return depth

def visualize_disparity(img, depth,disparity_fil, title="Disparity Map"):
    
    # Normalize disparity for visualization
    disp_vis = cv2.normalize(disparity_fil, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
    
    # Apply colormap
    disp_color = cv2.applyColorMap(disp_vis, cv2.COLORMAP_JET)
    
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 3, 1)
    plt.imshow(depth, cmap='gray')
    plt.title(f'{title} (Grayscale)')
    plt.colorbar()
    
    plt.subplot(1, 3, 2)
    plt.imshow(cv2.cvtColor(disp_color, cv2.COLOR_BGR2RGB))
    plt.title(f'{title} (Color)')
    plt.colorbar()
    
    plt.subplot(1, 3, 3)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.title(f'{title} (raw img)')
    plt.colorbar()

    plt.tight_layout()
    plt.show()

def postprocess_disparity(disparity):
    disp_fil = disparity.copy()
    disp_fil = cv2.medianBlur(disp_fil, ksize=5)

    kernel = np.ones((5,5), np.uint8)
    disp_fil = cv2.morphologyEx(disp_fil, cv2.MORPH_CLOSE, kernel)
    disp_fil = cv2.dilate(disp_fil, kernel, iterations=1)

    return disp_fil

# Example usage
def example_usage():
    
    # Load stereo images (replace with your image paths)
    left_img = cv2.imread('/home/abhijeet/Documents/ros2_ws/src/transition_localizer/bags/saved_images/left_20250708_153249_523843.png')
    right_img = cv2.imread('/home/abhijeet/Documents/ros2_ws/src/transition_localizer/bags/saved_images/right_20250708_153249_523843.png')
    
    # For demonstration, create synthetic images
    # # In practice, you would load real stereo camera images
    # left_img = np.random.randint(0, 255, (480, 640), dtype=np.uint8)
    # right_img = np.random.randint(0, 255, (480, 640), dtype=np.uint8)
    
    # Preprocess images
    left_processed, right_processed = preprocess_images(left_img, right_img)
    
    # Calculate disparity using SGBM (recommended)
    disparity = calculate_disparity(
        left_processed, 
        right_processed, 
        method='SGBM',
        numDisparities=16*5,
        blockSize=5,
        minDisparity=0,
        uniquenessRatio=10,
        speckleWindowSize=100,
        speckleRange=32
    )

    disparity_fil = postprocess_disparity(disparity)
    
    # Convert to depth if camera parameters are known
    focal_length = 160  # Example focal length in pixels
    baseline = 0.12       # Example baseline in meters
    depth = depth_from_disparity(disparity_fil, focal_length, baseline)
    
    # Visualize results
    visualize_disparity(left_img, depth,disparity_fil)
    
    return disparity

def get_depth_img(left_img, right_img,focal_length=320,baseline=0.12):
    
    left_processed, right_processed = preprocess_images(left_img, right_img)
    
    # Calculate disparity using SGBM (recommended)
    disparity = calculate_disparity(
        left_processed, 
        right_processed, 
        method='SGBM',
        numDisparities=16*5,
        blockSize=5,#11, #5,
        minDisparity=0,
        uniquenessRatio=10, #5,#10,
        speckleWindowSize=100,
        speckleRange=32
    )

    disparity_fil = postprocess_disparity(disparity)
    
    depth = depth_from_disparity(disparity_fil, focal_length, baseline)
    
    return depth

if __name__ == "__main__":
    # Run example
    disparity_result = example_usage()
    print(f"Disparity map shape: {disparity_result.shape}")
    print(f"Disparity range: {disparity_result.min():.2f} to {disparity_result.max():.2f}")