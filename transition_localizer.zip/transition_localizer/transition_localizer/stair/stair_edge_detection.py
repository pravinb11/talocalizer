import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage
from ultralytics import YOLO

def detect_staircase_edges(img,rect):
    if img is None:
        raise ValueError(f"Could not get the image")
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Apply edge detection using Canny
    edges = cv2.Canny(blurred, 50, 150, apertureSize=3)
    
    # Use morphological operations to clean up edges
    kernel = np.ones((3, 3), np.uint8)
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
    
    # Detect lines using Hough Transform
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, 
                           minLineLength=80, maxLineGap=10)
    
    # Create a copy of the original image for visualization
    result_img = img.copy()
    # Find horizontal lines (stair treads) and vertical lines (risers)
    horizontal_lines = []
    vertical_lines = []
    
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            
            # Calculate angle of the line
            angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
            angle_tol = 15
            # Classify lines as horizontal or vertical
            if abs(angle) < angle_tol or abs(angle) > 180-angle_tol:  # Horizontal lines
                horizontal_lines.append(line[0])
                
            elif (90 - angle_tol) < abs(angle) < (90 + angle_tol):  # Vertical lines
                vertical_lines.append(line[0])
                cv2.line(result_img, (x1, y1), (x2, y2), (255, 0, 0), 2)

    horizontal_lines_fil = valid_lines(horizontal_lines,rect)
    
    for line in horizontal_lines_fil:
        x1, y1, x2, y2 = line
        cv2.line(result_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    vertical_lines_fil = valid_lines(vertical_lines,rect)
    
    for line in vertical_lines_fil:
        x1, y1, x2, y2 = line
        cv2.line(result_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    # Find the starting midpoint of the staircase
    starting_midpoint = find_staircase_midpoint(horizontal_lines_fil, vertical_lines_fil, img.shape)
    
    # Mark the starting midpoint on the image
    if starting_midpoint:
        cv2.circle(result_img, starting_midpoint, 10, (0, 0, 255), -1)
        cv2.putText(result_img, "Starting Point", 
                   (starting_midpoint[0] + 15, starting_midpoint[1] - 15),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    
    return edges, starting_midpoint, result_img

def detect_staircase_edges2(img,od_msg,label_id = 26):
    if img is None:
        raise ValueError(f"Could not get the image")
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Apply edge detection using Canny
    edges = cv2.Canny(blurred, 50, 150, apertureSize=3)
    
    # Use morphological operations to clean up edges
    kernel = np.ones((3, 3), np.uint8)
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
    
    # Detect lines using Hough Transform
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, 
                           minLineLength=80, maxLineGap=10)
    
    # Create a copy of the original image for visualization
    result_img = img.copy()
    # Find horizontal lines (stair treads) and vertical lines (risers)
    horizontal_lines = []
    vertical_lines = []
    
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            
            # Calculate angle of the line
            angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
            angle_tol = 15
            # Classify lines as horizontal or vertical
            if abs(angle) < angle_tol or abs(angle) > 180-angle_tol:  # Horizontal lines
                horizontal_lines.append(line[0])
                
            elif (90 - angle_tol) < abs(angle) < (90 + angle_tol):  # Vertical lines
                vertical_lines.append(line[0])
                cv2.line(result_img, (x1, y1), (x2, y2), (255, 0, 0), 2)

    horizontal_lines_fil = valid_lines2(horizontal_lines,od_msg,label_id)
    
    for line in horizontal_lines_fil:
        x1, y1, x2, y2 = line
        cv2.line(result_img, (x1, y1), (x2, y2), (0, 255, 0), 2)

    return edges, od_msg, result_img

def valid_lines2(lines,od_msg,label_id):
    out_line = []

    for line in lines:
        x1, y1, x2, y2 = line
        xc = (x1+x2)/2
        yc = (y1+y2)/2

        for bbox in od_msg.bboxes:
            if(bbox.id != label_id):
                continue

            i = np.array([bbox.x-bbox.width//2, bbox.y-bbox.height//2, bbox.x+bbox.width//2, bbox.y+bbox.height//2])
            rect = np.array([[i[0], i[1]], [i[2], i[1]], [i[2], i[3]], [i[0], i[3]]])
            print(rect)
            if cv2.pointPolygonTest(rect.astype(int), (xc, yc), False) == 1.0:
                out_line.append(line)
                if(bbox.pose_y == 0 or bbox.pose_y < yc):
                    print("updated the xc yc", xc, yc)
                    bbox.pose_x = xc
                    bbox.pose_y = yc
                
    return out_line

def valid_lines(lines,rects):
    out_line = []

    for line in lines:
        x1, y1, x2, y2 = line
        xc = (x1+x2)/2
        yc = (y1+y2)/2

        for rect in rects:
            if(rect[0][0] == -1):
                continue
            if cv2.pointPolygonTest(rect.astype(int), (xc, yc), False) == 1.0:
                out_line.append(line)
                break
                
    return out_line


def find_staircase_midpoint(horizontal_lines, vertical_lines, img_shape):
    """
    Find the starting midpoint of the staircase based on detected lines
    
    Args:
        horizontal_lines (list): List of horizontal line coordinates
        vertical_lines (list): List of vertical line coordinates
        img_shape (tuple): Shape of the image (height, width, channels)
    
    Returns:
        tuple: (x, y) coordinates of the starting midpoint
    """
    
    if not horizontal_lines:
        return None
    
    # Sort horizontal lines by y-coordinate (top to bottom)
    horizontal_lines.sort(key=lambda line: min(line[1], line[3]))
    
    # Find the bottom-most horizontal line (closest to camera/bottom of image)
    bottom_line = horizontal_lines[-1]
    
    # Calculate the center x-coordinate of the bottom line
    center_x = (bottom_line[0] + bottom_line[2]) // 2
    center_y = (bottom_line[1] + bottom_line[3]) // 2
    
    return (center_x, center_y)

def analyze_staircase_structure(edges, horizontal_lines, vertical_lines):
    """
    Analyze the structure of the staircase to provide additional information
    
    Args:
        edges (numpy.ndarray): Edge-detected image
        horizontal_lines (list): List of horizontal line coordinates
        vertical_lines (list): List of vertical line coordinates
    
    Returns:
        dict: Dictionary containing staircase analysis
    """
    
    analysis = {
        'num_steps_detected': len(horizontal_lines),
        'num_risers_detected': len(vertical_lines),
        'step_heights': [],
        'step_widths': []
    }
    
    # Calculate step heights
    if len(horizontal_lines) > 1:
        sorted_horizontal = sorted(horizontal_lines, key=lambda line: min(line[1], line[3]))
        for i in range(len(sorted_horizontal) - 1):
            y1 = min(sorted_horizontal[i][1], sorted_horizontal[i][3])
            y2 = min(sorted_horizontal[i+1][1], sorted_horizontal[i+1][3])
            height = abs(y2 - y1)
            analysis['step_heights'].append(height)
    
    # Calculate step widths
    for line in horizontal_lines:
        width = abs(line[2] - line[0])
        analysis['step_widths'].append(width)
    
    return analysis

def visualize_results(original_img, edges, result_img, starting_midpoint, analysis):
    """
    Create a comprehensive visualization of the results
    """
    
    plt.figure(figsize=(15, 10))
    
    # Original image
    plt.subplot(2, 3, 1)
    plt.imshow(cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB))
    plt.title('Original Image')
    plt.axis('off')
    
    # Edge detection result
    plt.subplot(2, 3, 2)
    plt.imshow(edges, cmap='gray')
    plt.title('Edge Detection (Canny)')
    plt.axis('off')
    
    # Final result with lines and midpoint
    plt.subplot(2, 3, 3)
    plt.imshow(cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB))
    plt.title('Detected Lines and Starting Point')
    plt.axis('off')
    
    # Analysis plots
    plt.subplot(2, 3, 4)
    if analysis['step_heights']:
        plt.bar(range(len(analysis['step_heights'])), analysis['step_heights'])
        plt.title('Step Heights')
        plt.xlabel('Step Number')
        plt.ylabel('Height (pixels)')
    
    plt.subplot(2, 3, 5)
    if analysis['step_widths']:
        plt.bar(range(len(analysis['step_widths'])), analysis['step_widths'])
        plt.title('Step Widths')
        plt.xlabel('Step Number')
        plt.ylabel('Width (pixels)')
    
    # Summary text
    plt.subplot(2, 3, 6)
    plt.text(0.1, 0.8, f"Steps Detected: {analysis['num_steps_detected']}", 
             transform=plt.gca().transAxes, fontsize=12)
    plt.text(0.1, 0.6, f"Risers Detected: {analysis['num_risers_detected']}", 
             transform=plt.gca().transAxes, fontsize=12)
    if starting_midpoint:
        plt.text(0.1, 0.4, f"Starting Point: ({starting_midpoint[0]}, {starting_midpoint[1]})", 
                 transform=plt.gca().transAxes, fontsize=12)
    plt.text(0.1, 0.2, f"Avg Step Height: {np.mean(analysis['step_heights']):.1f} px" if analysis['step_heights'] else "No step heights", 
             transform=plt.gca().transAxes, fontsize=12)
    plt.axis('off')
    plt.title('Analysis Summary')
    
    plt.tight_layout()
    plt.show()

def create_polygon(bbox,label):
        # print(f"Boxes : {bbox} {bbox.shape}")
        rectangles = np.zeros((bbox.shape[0], 4, 2))
        # print(label)
        for idx, i in enumerate(bbox):
            if label[idx] == 5: #label consisting the stair_case rightnow
                rectangles[idx] = np.array([[i[0], i[1]], [i[2], i[1]], [i[2], i[3]], [i[0], i[3]]])
            else:
                rectangles[idx] = np.array([[-1,-1], [-1,-1],[-1,-1],[-1,-1]])
        # print(f"Rectangles: {rectangles} {rectangles.shape}")
        return rectangles


# Main execution function
def main(img,model_path):
    """
    Main function to process staircase image
    
    Args:
        image_path (str): Path to the staircase image
    """
    
    try:
        # Load original image for visualization
        # original_img = cv2.imread(image_path)
        
        yolo_model = YOLO(model_path)
        results = yolo_model.predict(img, verbose=True)
        bboxes = results[0].boxes.xyxy.cpu().numpy()
        labels = results[0].boxes.cls.cpu().numpy()


        rectangles = create_polygon(bboxes,labels)
        
        # Detect staircase edges and find midpoint
        edges, starting_midpoint, result_img = detect_staircase_edges(img,rectangles)
        
        return starting_midpoint
        
    except Exception as e:
        print(f"Error processing image: {e}")
        return None, None, None, None

def get_od_with_pose(img,od_msg,label_id = 26):
    """
    Main function to process staircase image
    
    Args:
        image_path (str): Path to the staircase image
    """
    
    try:
        # Detect staircase edges and find midpoint
        edges, od_msg, result_img = detect_staircase_edges2(img,od_msg,label_id)
        

        print(len(od_msg.bboxes))
        return od_msg
        
    except Exception as e:
        print(f"Error processing image: {e}")
        return None
    
# Example usage
if __name__ == "__main__":
    # Replace with your image path
    image_path = "/home/abhijeet/Documents/ros2_ws/src/transition_localizer/bags/saved_images/left_20250708_153249_523843.png"
    model_path = "/home/hitech/ros2/perception_ws/src/ta_localizer_modules/transition_localizer/model/simulation_model.pt"
    # Process the image
    img = cv2.imread(image_path)
    # edges, midpoint, result, analysis = main(img,model_path)
    midpoint= main(img,model_path)
    print(midpoint)
    # Save the result
    # if result is not None:
    #     cv2.imwrite("staircase_detected.jpg", result)
    #     print("Result saved as 'staircase_detected.jpg'")