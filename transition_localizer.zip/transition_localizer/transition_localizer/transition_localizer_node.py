#!/usr/bin/env python3
import os
import cv2
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from pathlib import Path
from collections import defaultdict
import numpy as np
from autonovus_msgs.msg import ObjectDetection
from cv_bridge import CvBridge
from autonovus_msgs.msg import BoundingBox
from rclpy.serialization import deserialize_message
from rosidl_runtime_py.utilities import get_message
from sensor_msgs.msg import Image, CompressedImage
from std_msgs.msg import String, Bool
import message_filters
from transition_localizer.common import img_disparity
from transition_localizer.stair import stair_edge_detection
from transition_localizer.main_enterance.enterance_edge_detection import EnteranceDetector
from transition_localizer.ramp import ramp_edge_detection
import tf2_ros
import tf2_geometry_msgs
from geometry_msgs.msg import PointStamped

def pixel_to_3d(u, v, depth_image, fx = 239.4569243918056, fy = 239.4569243918056, cx = 160, cy = 320):
    Z = depth_image[v, u]  # Note: depth_image[y, x] convention
    if Z == 0 or Z == np.inf:
        return (0.0,0.0,0.0)  # Invalid depth

    X = (u - cx) * Z / fx
    Y = (v - cy) * Z / fy
    print("3D Point: ", (X, Y, Z))
    print("Camera Intrinsics: ", (u, v, cx, cy, fx, fy))

    # Just extracting the XY coordinate
    
    return (Z,X,np.tanh(Z/X))

class TransitionLocalizerNode(Node):
    def __init__(self):
        super().__init__('transition_localizer_node')
        
        # Declare parametersTransitionLocalizerNode
        self.declare_parameter('left_camera_topic', '/left_camera/image/compressed')
        self.declare_parameter('right_camera_topic', '/right_camera/image/compressed')
        self.declare_parameter('od_topic', '/object_detection')
        self.declare_parameter('model_path', '/home/hitech/ros2/perception_ws/src/ta_localizer_modules/transition_localizer/model/simulation_model.pt')
        self.declare_parameter('tolerance', 0.1)
        self.declare_parameter('entrance_label_id', 38)  # Default label ID for stairs #TODO: add these to parameter launch
        self.declare_parameter('stair_label_id', 26)  # Default label ID for doors #TODO: add these to parameter launch
        self.declare_parameter('ramp_label_id', 41)  # Default label ID for ramps #TODO: add these to parameter launch

        # Get parameters
        self.left_topic = self.get_parameter('left_camera_topic').get_parameter_value().string_value
        self.right_topic = self.get_parameter('right_camera_topic').get_parameter_value().string_value
        self.od_topic = self.get_parameter('od_topic').get_parameter_value().string_value
        self.model_path = self.get_parameter('model_path').get_parameter_value().string_value
        self.tolerance = self.get_parameter('tolerance').get_parameter_value().double_value
        self.entrance_label_id = self.get_parameter('entrance_label_id').get_parameter_value().integer_value
        self.stair_label_id = self.get_parameter('stair_label_id').get_parameter_value().integer_value
        self.ramp_label_id = self.get_parameter('ramp_label_id').get_parameter_value().integer_value 
        # Storage for images
        self.left_images = {}
        self.right_images = {}
        self.bridge = CvBridge()
        
        # Create publishers
        self.pose_pub = self.create_publisher(ObjectDetection, '/object_detector/detections', 10)
        self.model_img_pub_ = self.create_publisher(Image,'/object_detector/disparity_map', 10)

        # Create Subscribers
        self.left_cam_sub = message_filters.Subscriber(self, CompressedImage, self.left_topic)
        self.right_cam_sub = message_filters.Subscriber(self, CompressedImage, self.right_topic)
        self.od_sub = message_filters.Subscriber(self, ObjectDetection, self.od_topic)

        self.get_logger().info('Stereo Depth Node initialized')
        self.get_logger().info(f'Left topic: {self.left_topic}')
        self.get_logger().info(f'Right topic: {self.right_topic}')
        self.get_logger().info(f'Model Path: {self.model_path}')
        self.get_logger().info(f'Tolerance: {self.tolerance}s')
        self.get_logger().info(f'Entrance Label ID: {self.entrance_label_id}')
        self.get_logger().info(f'Stair Label ID: {self.stair_label_id}')
        self.get_logger().info(f'Ramp Label ID: {self.ramp_label_id}')

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.entrance_detector = EnteranceDetector()
        ts = message_filters.ApproximateTimeSynchronizer(
            [self.left_cam_sub, self.right_cam_sub, self.od_sub], 10, self.tolerance  # Queue size, synchronization slop
        )

        ts.registerCallback(self.callback)
    
    def callback(self, left_img_msg, right_img_msg, od_msg):

        # Convert the compressed image to a CV2 image
        np_arr = np.frombuffer(left_img_msg.data, np.uint8)
        img_left = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        # Convert the compressed image to a CV2 image
        np_arr = np.frombuffer(right_img_msg.data, np.uint8)
        img_right = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        # img_left = self.bridge.imgmsg_to_cv2(left_img_msg, desired_encoding='passthrough')
        # img_right = self.bridge.imgmsg_to_cv2(right_img_msg, desired_encoding='passthrough')

        depth_img = img_disparity.get_depth_img(img_left,img_right,160,0.12)
        ros_image_msg = self.bridge.cv2_to_imgmsg(depth_img)
        self.model_img_pub_.publish(ros_image_msg)

        cv2.imshow("Depth Image", depth_img)
        cv2.waitKey(1)

        od_msg = stair_edge_detection.get_od_with_pose(img_left,od_msg,self.stair_label_id)
        od_msg = self.entrance_detector.get_od_with_pose(img_left,od_msg,self.entrance_label_id)
        od_msg = ramp_edge_detection.get_od_with_pose(img_left,od_msg,self.ramp_label_id)
        transform = self.tf_buffer.lookup_transform(
                'odom',  # target frame
                'right_camera_frame',  # source frame
                rclpy.time.Time(),  # use latest transform
                timeout=rclpy.duration.Duration(seconds=1.0)
            )
        
        od_msg.header.frame_id = 'odom'
        for bbox in od_msg.bboxes:
            if bbox.pose_x == 0:
                continue

            out = pixel_to_3d(int(bbox.pose_x),int(bbox.pose_y),depth_img)
            if bbox.id == self.ramp_label_id:
                print("Ramp 3D: ", out)
            point_in_camera = PointStamped()
            point_in_camera.point.x = float(out[0])
            point_in_camera.point.y = float(out[1])
            point_in_camera.point.z = 0.0

            transformed_point = tf2_geometry_msgs.do_transform_point(point_in_camera, transform)

            bbox.pose_x = transformed_point.point.x
            bbox.pose_y = transformed_point.point.y

        
        
        # print(np.array(img_right).shape)
        # print(np.array(depth_img).shape)

        self.pose_pub.publish(od_msg)


def main(args=None):
    rclpy.init(args=args)
    
    node = TransitionLocalizerNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node interrupted by user')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()