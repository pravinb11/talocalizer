import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage
from sklearn.cluster import DBSCAN
from sklearn.linear_model import RANSACRegressor

class RampDetector:
    def __init__(self):
        self.debug = True
        
    def detect_ramp_boundaries(self, image_path):
        """
        Detect boundaries of a ramp and find the bottom midpoint
        
        Args:
            image_path (str): Path to the ramp image
        
        Returns:
            tuple: (edges, ramp_boundaries, bottom_midpoint, processed_image)
        """
        
        # Read the image
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Could not load image from {image_path}")
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Enhance contrast for better edge detection
        enhanced = self.enhance_image_contrast(gray)
        
        # Multi-scale edge detection optimized for ramps
        edges = self.ramp_optimized_edge_detection(enhanced)
        
        # Detect ramp lines (including angled edges)
        ramp_lines = self.detect_ramp_lines(edges)
        
        # Find ramp boundaries using geometric analysis
        ramp_boundaries = self.find_ramp_boundaries(ramp_lines, img.shape)
        
        # Calculate bottom midpoint (entry point of ramp)
        bottom_midpoint = self.find_bottom_midpoint(ramp_boundaries, img.shape)
        
        # Create comprehensive visualization
        result_img = self.create_visualization(img, edges, ramp_lines, ramp_boundaries, bottom_midpoint)
        
        return edges, ramp_boundaries, bottom_midpoint, result_img
    
    def enhance_image_contrast(self, gray_img):
        """
        Enhance image contrast for better ramp detection
        """
        # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
        enhanced = clahe.apply(gray_img)
        
        # Apply bilateral filter to preserve edges while reducing noise
        filtered = cv2.bilateralFilter(enhanced, 11, 80, 80)
        
        return filtered
    
    def ramp_optimized_edge_detection(self, gray_img):
        """
        Edge detection optimized for ramp characteristics
        """
        # Apply multiple edge detection approaches
        
        # Sobel edge detection (good for gradual transitions)
        sobel_x = cv2.Sobel(gray_img, cv2.CV_64F, 1, 0, ksize=3)
        sobel_y = cv2.Sobel(gray_img, cv2.CV_64F, 0, 1, ksize=3)
        sobel_combined = np.sqrt(sobel_x**2 + sobel_y**2)
        sobel_edges = np.uint8(sobel_combined / sobel_combined.max() * 255)
        
        # Canny edge detection with multiple scales
        blur1 = cv2.GaussianBlur(gray_img, (3, 3), 0)
        blur2 = cv2.GaussianBlur(gray_img, (5, 5), 0)
        
        canny1 = cv2.Canny(blur1, 30, 120, apertureSize=3)
        canny2 = cv2.Canny(blur2, 40, 150, apertureSize=3)
        
        # Combine different edge detection results
        combined_edges = cv2.bitwise_or(canny1, canny2)
        
        # Add Sobel edges (threshold and convert to binary)
        _, sobel_binary = cv2.threshold(sobel_edges, 50, 255, cv2.THRESH_BINARY)
        combined_edges = cv2.bitwise_or(combined_edges, sobel_binary)
        
        # Morphological operations to connect ramp edges
        kernel_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        kernel_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        
        combined_edges = cv2.morphologyEx(combined_edges, cv2.MORPH_CLOSE, kernel_close)
        combined_edges = cv2.morphologyEx(combined_edges, cv2.MORPH_OPEN, kernel_open)
        
        return combined_edges
    
    def detect_ramp_lines(self, edges):
        """
        Detect ramp lines including angled side edges and horizontal boundaries
        """
        # Detect lines using Hough Transform with parameters optimized for ramps
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=60, 
                               minLineLength=80, maxLineGap=30)
        
        if lines is None:
            return {'left_side': [], 'right_side': [], 'horizontal': [], 'all': []}
        
        # Classify lines based on angle and position
        left_side_lines = []
        right_side_lines = []
        horizontal_lines = []
        all_lines = []
        
        height, width = edges.shape
        
        for line in lines:
            x1, y1, x2, y2 = line[0]
            
            # Calculate line properties
            length = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
            angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            
            # Filter short lines
            if length < 40:
                continue
            
            line_info = {
                'coords': (x1, y1, x2, y2),
                'length': length,
                'angle': angle,
                'center': (center_x, center_y),
                'slope': (y2 - y1) / (x2 - x1) if (x2 - x1) != 0 else float('inf')
            }
            
            all_lines.append(line_info)
            
            # Classify lines
            if abs(angle) < 20 or abs(angle) > 160:  # Nearly horizontal
                horizontal_lines.append(line_info)
            elif 20 <= abs(angle) <= 80:  # Angled lines (ramp sides)
                if center_x < width // 2:  # Left side of image
                    left_side_lines.append(line_info)
                else:  # Right side of image
                    right_side_lines.append(line_info)
        
        return {
            'left_side': left_side_lines,
            'right_side': right_side_lines,
            'horizontal': horizontal_lines,
            'all': all_lines
        }
    
    def find_ramp_boundaries(self, ramp_lines, img_shape):
        """
        Find ramp boundaries using geometric analysis and line fitting
        """
        height, width = img_shape[:2]
        
        boundaries = {
            'left_edge': None,
            'right_edge': None,
            'top_edge': None,
            'bottom_edge': None,
            'ramp_polygon': None,
            'ramp_width_top': 0,
            'ramp_width_bottom': 0,
            'ramp_angle': 0
        }
        
        # Find left and right ramp edges
        boundaries['left_edge'] = self.find_best_ramp_edge(ramp_lines['left_side'], 'left', img_shape)
        boundaries['right_edge'] = self.find_best_ramp_edge(ramp_lines['right_side'], 'right', img_shape)
        
        # Find horizontal boundaries (top and bottom of ramp)
        if ramp_lines['horizontal']:
            # Sort horizontal lines by y-coordinate
            sorted_horizontal = sorted(ramp_lines['horizontal'], 
                                     key=lambda line: (line['coords'][1] + line['coords'][3]) // 2)
            
            # Top edge - uppermost horizontal line
            boundaries['top_edge'] = sorted_horizontal[0]
            
            # Bottom edge - lowermost horizontal line that makes sense for a ramp
            for line in reversed(sorted_horizontal):
                y_pos = (line['coords'][1] + line['coords'][3]) // 2
                if y_pos > height * 0.6:  # In bottom 40% of image
                    boundaries['bottom_edge'] = line
                    break
        
        # Create ramp polygon if we have enough information
        if boundaries['left_edge'] and boundaries['right_edge']:
            boundaries['ramp_polygon'] = self.create_ramp_polygon(boundaries, img_shape)
            
            # Calculate ramp measurements
            measurements = self.calculate_ramp_measurements(boundaries, img_shape)
            boundaries.update(measurements)
        
        return boundaries
    
    def find_best_ramp_edge(self, side_lines, side, img_shape):
        """
        Find the best line representing a ramp edge using RANSAC
        """
        if not side_lines:
            return None
        
        height, width = img_shape[:2]
        
        # If only one line, return it
        if len(side_lines) == 1:
            return side_lines[0]
        
        # For multiple lines, use the longest one that makes geometric sense
        # Filter lines based on position and angle consistency
        valid_lines = []
        
        for line in side_lines:
            x1, y1, x2, y2 = line['coords']
            center_x = (x1 + x2) // 2
            
            # Check if line is in correct side of image
            if side == 'left' and center_x < width * 0.6:
                valid_lines.append(line)
            elif side == 'right' and center_x > width * 0.4:
                valid_lines.append(line)
        
        if not valid_lines:
            valid_lines = side_lines
        
        # Return the longest valid line
        return max(valid_lines, key=lambda x: x['length'])
    
    def create_ramp_polygon(self, boundaries, img_shape):
        """
        Create a polygon representing the ramp area
        """
        height, width = img_shape[:2]
        
        left_edge = boundaries['left_edge']
        right_edge = boundaries['right_edge']
        
        if not left_edge or not right_edge:
            return None
        
        # Get line coordinates
        left_coords = left_edge['coords']
        right_coords = right_edge['coords']
        
        # Extend lines to image boundaries to get full ramp shape
        left_top, left_bottom = self.extend_line_to_bounds(left_coords, img_shape)
        right_top, right_bottom = self.extend_line_to_bounds(right_coords, img_shape)
        
        # Create polygon points (clockwise from top-left)
        polygon_points = np.array([
            left_top,
            right_top,
            right_bottom,
            left_bottom
        ], dtype=np.int32)
        
        return polygon_points
    
    def extend_line_to_bounds(self, line_coords, img_shape):
        """
        Extend a line to image boundaries
        """
        x1, y1, x2, y2 = line_coords
        height, width = img_shape[:2]
        
        # Calculate line equation: y = mx + b
        if x2 - x1 != 0:
            m = (y2 - y1) / (x2 - x1)
            b = y1 - m * x1
            
            # Find intersections with image boundaries
            # Top boundary (y = 0)
            x_top = -b / m if m != 0 else x1
            top_point = (int(np.clip(x_top, 0, width-1)), 0)
            
            # Bottom boundary (y = height-1)
            x_bottom = (height - 1 - b) / m if m != 0 else x1
            bottom_point = (int(np.clip(x_bottom, 0, width-1)), height-1)
        else:
            # Vertical line
            top_point = (x1, 0)
            bottom_point = (x1, height-1)
        
        return top_point, bottom_point
    
    def calculate_ramp_measurements(self, boundaries, img_shape):
        """
        Calculate ramp measurements and properties
        """
        measurements = {
            'ramp_width_top': 0,
            'ramp_width_bottom': 0,
            'ramp_angle': 0,
            'ramp_length': 0
        }
        
        if not boundaries['left_edge'] or not boundaries['right_edge']:
            return measurements
        
        height, width = img_shape[:2]
        
        # Calculate width at top and bottom
        left_coords = boundaries['left_edge']['coords']
        right_coords = boundaries['right_edge']['coords']
        
        # Extend lines to get top and bottom widths
        left_top, left_bottom = self.extend_line_to_bounds(left_coords, img_shape)
        right_top, right_bottom = self.extend_line_to_bounds(right_coords, img_shape)
        
        measurements['ramp_width_top'] = abs(right_top[0] - left_top[0])
        measurements['ramp_width_bottom'] = abs(right_bottom[0] - left_bottom[0])
        
        # Calculate average angle of ramp sides
        left_angle = abs(boundaries['left_edge']['angle'])
        right_angle = abs(boundaries['right_edge']['angle'])
        measurements['ramp_angle'] = (left_angle + right_angle) / 2
        
        # Calculate ramp length (distance from top to bottom along center)
        center_top = ((left_top[0] + right_top[0]) // 2, left_top[1])
        center_bottom = ((left_bottom[0] + right_bottom[0]) // 2, left_bottom[1])
        measurements['ramp_length'] = np.sqrt((center_bottom[0] - center_top[0])**2 + 
                                            (center_bottom[1] - center_top[1])**2)
        
        return measurements
    
    def find_bottom_midpoint(self, ramp_boundaries, img_shape):
        """
        Find the bottom midpoint of the ramp (entry/exit point)
        """
        height, width = img_shape[:2]
        
        # Method 1: Use ramp polygon if available
        if ramp_boundaries['ramp_polygon'] is not None:
            polygon = ramp_boundaries['ramp_polygon']
            # Find bottom two points and calculate midpoint
            bottom_points = sorted(polygon, key=lambda p: p[1], reverse=True)[:2]
            midpoint_x = (bottom_points[0][0] + bottom_points[1][0]) // 2
            midpoint_y = max(bottom_points[0][1], bottom_points[1][1])
            return (midpoint_x, midpoint_y)
        
        # Method 2: Use left and right edges
        if ramp_boundaries['left_edge'] and ramp_boundaries['right_edge']:
            left_coords = ramp_boundaries['left_edge']['coords']
            right_coords = ramp_boundaries['right_edge']['coords']
            
            # Extend lines to bottom of image
            left_top, left_bottom = self.extend_line_to_bounds(left_coords, img_shape)
            right_top, right_bottom = self.extend_line_to_bounds(right_coords, img_shape)
            
            # Calculate midpoint at bottom
            midpoint_x = (left_bottom[0] + right_bottom[0]) // 2
            midpoint_y = height - 1
            
            # If there's a bottom edge, use its y-coordinate
            if ramp_boundaries['bottom_edge']:
                bottom_coords = ramp_boundaries['bottom_edge']['coords']
                midpoint_y = max(bottom_coords[1], bottom_coords[3])
            
            return (midpoint_x, midpoint_y)
        
        # Method 3: Use bottom edge only
        if ramp_boundaries['bottom_edge']:
            bottom_coords = ramp_boundaries['bottom_edge']['coords']
            midpoint_x = (bottom_coords[0] + bottom_coords[2]) // 2
            midpoint_y = (bottom_coords[1] + bottom_coords[3]) // 2
            return (midpoint_x, midpoint_y)
        
        return None
    
    def create_visualization(self, original_img, edges, ramp_lines, boundaries, bottom_midpoint):
        """
        Create comprehensive visualization of ramp detection
        """
        result_img = original_img.copy()
        
        # Draw all detected lines in light gray
        for line in ramp_lines['all']:
            coords = line['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (200, 200, 200), 1)
        
        # Draw ramp boundaries with different colors
        if boundaries['left_edge']:
            coords = boundaries['left_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (0, 255, 0), 4)
            cv2.putText(result_img, "Left Edge", (coords[0] - 60, coords[1] + 20), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        if boundaries['right_edge']:
            coords = boundaries['right_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (255, 0, 0), 4)
            cv2.putText(result_img, "Right Edge", (coords[0] + 10, coords[1] + 20), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        
        if boundaries['top_edge']:
            coords = boundaries['top_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (0, 255, 255), 3)
            cv2.putText(result_img, "Top", (coords[0], coords[1] - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        
        if boundaries['bottom_edge']:
            coords = boundaries['bottom_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (255, 255, 0), 3)
            cv2.putText(result_img, "Bottom", (coords[0], coords[1] + 25), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        # Draw ramp polygon
        if boundaries['ramp_polygon'] is not None:
            cv2.polylines(result_img, [boundaries['ramp_polygon']], True, (255, 0, 255), 3)
            # Fill polygon with semi-transparent overlay
            overlay = result_img.copy()
            cv2.fillPoly(overlay, [boundaries['ramp_polygon']], (255, 0, 255))
            result_img = cv2.addWeighted(result_img, 0.8, overlay, 0.2, 0)
        
        # Draw bottom midpoint (entry/exit point)
        if bottom_midpoint:
            cv2.circle(result_img, bottom_midpoint, 12, (0, 0, 255), -1)
            cv2.circle(result_img, bottom_midpoint, 16, (255, 255, 255), 3)
            cv2.putText(result_img, f"Entry/Exit: ({bottom_midpoint[0]}, {bottom_midpoint[1]})", 
                       (bottom_midpoint[0] - 100, bottom_midpoint[1] - 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        # Add measurements text
        y_offset = 30
        if boundaries['ramp_width_bottom'] > 0:
            cv2.putText(result_img, f"Width (bottom): {boundaries['ramp_width_bottom']:.0f}px", 
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            y_offset += 25
        
        if boundaries['ramp_angle'] > 0:
            cv2.putText(result_img, f"Avg Angle: {boundaries['ramp_angle']:.1f}°", 
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            y_offset += 25
        
        if boundaries['ramp_length'] > 0:
            cv2.putText(result_img, f"Length: {boundaries['ramp_length']:.0f}px", 
                       (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        return result_img
    
    def analyze_ramp_structure(self, ramp_boundaries, img_shape):
        """
        Analyze ramp structure and provide detailed measurements
        """
        height, width = img_shape[:2]
        
        analysis = {
            'ramp_detected': False,
            'confidence_score': 0,
            'ramp_type': 'unknown',
            'accessibility_compliant': False,
            'slope_estimate': 0,
            'width_variation': 0,
            'symmetry_score': 0
        }
        
        # Check if ramp is detected
        components_detected = 0
        if ramp_boundaries['left_edge']: components_detected += 1
        if ramp_boundaries['right_edge']: components_detected += 1
        if ramp_boundaries['top_edge']: components_detected += 1
        if ramp_boundaries['bottom_edge']: components_detected += 1
        
        analysis['ramp_detected'] = components_detected >= 2
        analysis['confidence_score'] = min(components_detected * 25, 100)
        
        if analysis['ramp_detected']:
            # Analyze ramp type
            if ramp_boundaries['ramp_width_top'] and ramp_boundaries['ramp_width_bottom']:
                width_ratio = ramp_boundaries['ramp_width_top'] / ramp_boundaries['ramp_width_bottom']
                if width_ratio > 1.1:
                    analysis['ramp_type'] = 'converging'
                elif width_ratio < 0.9:
                    analysis['ramp_type'] = 'diverging'
                else:
                    analysis['ramp_type'] = 'parallel'
                
                # Width variation
                analysis['width_variation'] = abs(ramp_boundaries['ramp_width_top'] - 
                                                ramp_boundaries['ramp_width_bottom'])
            
            # Estimate slope (very rough estimate based on angle)
            if ramp_boundaries['ramp_angle'] > 0:
                analysis['slope_estimate'] = np.tan(np.radians(ramp_boundaries['ramp_angle']))
                # ADA compliance check (slope should be less than 1:12 or about 4.8 degrees)
                analysis['accessibility_compliant'] = ramp_boundaries['ramp_angle'] < 5.0
            
            # Symmetry analysis
            if ramp_boundaries['left_edge'] and ramp_boundaries['right_edge']:
                left_angle = abs(ramp_boundaries['left_edge']['angle'])
                right_angle = abs(ramp_boundaries['right_edge']['angle'])
                angle_difference = abs(left_angle - right_angle)
                analysis['symmetry_score'] = max(0, 100 - angle_difference * 2)
        
        return analysis

def visualize_results(original_img, edges, result_img, analysis, boundaries):
    """
    Create comprehensive visualization plots
    """
    plt.figure(figsize=(16, 12))
    
    # Original image
    plt.subplot(2, 4, 1)
    plt.imshow(cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB))
    plt.title('Original Ramp Image')
    plt.axis('off')
    
    # Edge detection
    plt.subplot(2, 4, 2)
    plt.imshow(edges, cmap='gray')
    plt.title('Multi-Scale Edge Detection')
    plt.axis('off')
    
    # Final result
    plt.subplot(2, 4, 3)
    plt.imshow(cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB))
    plt.title('Ramp Boundary Detection')
    plt.axis('off')
    
    # Measurements plot
    plt.subplot(2, 4, 4)
    if boundaries['ramp_width_top'] > 0 and boundaries['ramp_width_bottom'] > 0:
        labels = ['Top Width', 'Bottom Width']
        values = [boundaries['ramp_width_top'], boundaries['ramp_width_bottom']]
        colors = ['blue', 'green']
        plt.bar(labels, values, color=colors)
        plt.title('Ramp Widths (pixels)')
        plt.ylabel('Pixels')
        plt.xticks(rotation=45)
    else:
        plt.text(0.5, 0.5, 'No Width\nData', ha='center', va='center', 
                transform=plt.gca().transAxes, fontsize=14)
        plt.title('Ramp Widths')
    
    # Angle and slope analysis
    plt.subplot(2, 4, 5)
    if boundaries['ramp_angle'] > 0:
        metrics = ['Angle (°)', 'Slope Est.']
        values = [boundaries['ramp_angle'], analysis['slope_estimate'] * 100]  # slope as percentage
        colors = ['orange', 'red' if analysis['slope_estimate'] > 0.083 else 'green']  # 0.083 ≈ 1:12 slope
        bars = plt.bar(metrics, values, color=colors)
        plt.title('Angle & Slope Analysis')
        plt.ylabel('Degrees / Percentage')
        
        # Add ADA compliance line for slope
        if len(values) > 1:
            plt.axhline(y=8.33, color='red', linestyle='--', alpha=0.7, label='ADA Limit (8.33%)')
            plt.legend()
    else:
        plt.text(0.5, 0.5, 'No Angle\nData', ha='center', va='center', 
                transform=plt.gca().transAxes, fontsize=14)
        plt.title('Angle & Slope Analysis')
    
    # Confidence and quality metrics
    plt.subplot(2, 4, 6)
    metrics = ['Confidence', 'Symmetry']
    values = [analysis['confidence_score'], analysis['symmetry_score']]
    colors = ['green' if v > 70 else 'orange' if v > 40 else 'red' for v in values]
    plt.bar(metrics, values, color=colors)
    plt.title('Detection Quality')
    plt.ylabel('Score (0-100)')
    plt.ylim(0, 100)
    
    # Ramp type visualization
    plt.subplot(2, 4, 7)
    ramp_types = {'parallel': 0, 'converging': 1, 'diverging': 2, 'unknown': 3}
    type_colors = ['blue', 'orange', 'purple', 'gray']
    current_type = analysis['ramp_type']
    
    plt.bar([current_type], [1], color=type_colors[ramp_types[current_type]])
    plt.title(f'Ramp Type: {current_type.title()}')
    plt.ylabel('Detected Type')
    plt.xticks([])
    
    # Summary text
    plt.subplot(2, 4, 8)
    summary_text = f"""Ramp Detection Summary:
    
Status: {'✓ Detected' if analysis['ramp_detected'] else '✗ Not Found'}
Confidence: {analysis['confidence_score']}%
Type: {analysis['ramp_type'].title()}
ADA Compliant: {'✓' if analysis['accessibility_compliant'] else '✗'}

Measurements:
Width Top: {boundaries['ramp_width_top']:.0f} px
Width Bottom: {boundaries['ramp_width_bottom']:.0f} px
Length: {boundaries['ramp_length']:.0f} px
Angle: {boundaries['ramp_angle']:.1f}°
Slope: {analysis['slope_estimate']:.3f} ({analysis['slope_estimate']*100:.1f}%)

Quality Metrics:
Symmetry: {analysis['symmetry_score']:.0f}%
Width Variation: {analysis['width_variation']:.0f} px
"""
    
    plt.text(0.05, 0.95, summary_text, transform=plt.gca().transAxes, 
             fontsize=9, verticalalignment='top', fontfamily='monospace')
    plt.axis('off')
    plt.title('Analysis Summary')
    
    plt.tight_layout()
    plt.show()

def main(image_path):
    """
    Main function to process ramp image
    """
    detector = RampDetector()
    
    try:
        # Load original image
        original_img = cv2.imread(image_path)
        if original_img is None:
            print(f"Error: Could not load image from {image_path}")
            return
        
        print("Processing ramp image...")
        
        # Detect ramp boundaries
        edges, boundaries, bottom_midpoint, result_img = detector.detect_ramp_boundaries(image_path)
        
        # Analyze ramp structure
        analysis = detector.analyze_ramp_structure(boundaries, original_img.shape)
        
        # Display results
        print(f"\n=== Ramp Detection Results ===")
        print(f"Ramp detected: {analysis['ramp_detected']}")
        print(f"Confidence: {analysis['confidence_score']}%")
        print(f"Ramp type: {analysis['ramp_type']}")
        print(f"ADA compliant slope: {analysis['accessibility_compliant']}")
        
        if bottom_midpoint:
            print(f"Bottom midpoint (entry/exit): ({bottom_midpoint[0]}, {bottom_midpoint[1]})")
        else:
            print("Bottom midpoint: Not found")
        
        print(f"\n=== Ramp Measurements ===")
        print(f"Width at top: {boundaries['ramp_width_top']:.0f} pixels")
        print(f"Width at bottom: {boundaries['ramp_width_bottom']:.0f} pixels")
        print(f"Length: {boundaries['ramp_length']:.0f} pixels")
        print(f"Average angle: {boundaries['ramp_angle']:.1f} degrees")
        print(f"Estimated slope: {analysis['slope_estimate']:.3f} ({analysis['slope_estimate']*100:.1f}%)")
        
        # Boundary detection details
        print(f"\n=== Boundary Detection Details ===")
        print(f"Left edge: {'✓' if boundaries['left_edge'] else '✗'}")
        print(f"Right edge: {'✓' if boundaries['right_edge'] else '✗'}")
        print(f"Top edge: {'✓' if boundaries['top_edge'] else '✗'}")
        print(f"Bottom edge: {'✓' if boundaries['bottom_edge'] else '✗'}")
        
        print(f"\n=== Quality Analysis ===")
        print(f"Symmetry score: {analysis['symmetry_score']:.0f}%")
        print(f"Width variation: {analysis['width_variation']:.0f} pixels")
        
        # Visualize results
        visualize_results(original_img, edges, result_img, analysis, boundaries)
        
        # Save result
        cv2.imwrite("ramp_detection_result.jpg", result_img)
        print("\nResult saved as 'ramp_detection_result.jpg'")
        
        return edges, boundaries, bottom_midpoint, analysis
        
    except Exception as e:
        print(f"Error processing image: {e}")
        return None, None, None, None

# Additional utility functions for advanced ramp analysis
def detect_ramp_handrails(image, ramp_boundaries):
    """
    Detect handrails on the ramp (bonus feature)
    """
    if not ramp_boundaries['ramp_polygon']:
        return []
    
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Look for parallel lines above the ramp edges
    edges = cv2.Canny(gray, 50, 150)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, 
                           minLineLength=100, maxLineGap=20)
    
    handrails = []
    if lines is not None:
        ramp_polygon = ramp_boundaries['ramp_polygon']
        ramp_top_y = min(ramp_polygon[:, 1])
        
        for line in lines:
            x1, y1, x2, y2 = line[0]
            line_y = (y1 + y2) // 2
            
            # Check if line is above ramp and roughly parallel to ramp edges
            if line_y < ramp_top_y - 20:  # Above the ramp
                angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
                if 10 <= abs(angle) <= 80:  # Similar angle to ramp
                    handrails.append({
                        'coords': (x1, y1, x2, y2),
                        'angle': angle,
                        'height_above_ramp': ramp_top_y - line_y
                    })
    
    return handrails

def assess_ramp_surface_quality(image, ramp_boundaries):
    """
    Assess the surface quality/texture of the ramp
    """
    if not ramp_boundaries['ramp_polygon']:
        return {'surface_quality': 'unknown', 'texture_score': 0}
    
    # Create mask for ramp area
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    cv2.fillPoly(mask, [ramp_boundaries['ramp_polygon']], 255)
    
    # Extract ramp area
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    ramp_area = cv2.bitwise_and(gray, mask)
    
    # Calculate texture metrics
    # Standard deviation of pixel intensities (higher = more textured)
    ramp_pixels = ramp_area[mask > 0]
    if len(ramp_pixels) > 0:
        texture_std = np.std(ramp_pixels)
        mean_intensity = np.mean(ramp_pixels)
        
        # Simple surface quality assessment
        if texture_std > 30:
            surface_quality = 'rough/textured'
        elif texture_std > 15:
            surface_quality = 'moderate'
        else:
            surface_quality = 'smooth'
        
        texture_score = min(texture_std / 50 * 100, 100)  # Normalize to 0-100
        
        return {
            'surface_quality': surface_quality,
            'texture_score': texture_score,
            'mean_intensity': mean_intensity,
            'texture_std': texture_std
        }
    
    return {'surface_quality': 'unknown', 'texture_score': 0}

def generate_ramp_accessibility_report(boundaries, analysis, surface_analysis=None):
    """
    Generate a comprehensive accessibility report for the ramp
    """
    report = {
        'overall_grade': 'Unknown',
        'ada_compliant': False,
        'issues': [],
        'recommendations': []
    }
    
    if not analysis['ramp_detected']:
        report['overall_grade'] = 'F - No Ramp Detected'
        report['issues'].append('Ramp boundaries could not be clearly identified')
        return report
    
    # Check slope compliance
    if analysis['slope_estimate'] > 0:
        if analysis['slope_estimate'] <= 0.083:  # 1:12 ratio
            report['ada_compliant'] = True
        else:
            report['issues'].append(f"Slope too steep: {analysis['slope_estimate']*100:.1f}% (max 8.33%)")
            report['recommendations'].append("Consider adding switchbacks or reducing slope")
    
    # Check width (ADA minimum is typically 36 inches, but we can't convert pixels to real measurements)
    if boundaries['ramp_width_bottom'] > 0:
        if boundaries['ramp_width_bottom'] < boundaries['ramp_width_top'] * 0.8:
            report['issues'].append("Ramp narrows significantly toward bottom")
            report['recommendations'].append("Ensure consistent width throughout ramp")
    
    # Check symmetry
    if analysis['symmetry_score'] < 70:
        report['issues'].append("Ramp appears asymmetrical")
        report['recommendations'].append("Check for even construction and proper alignment")
    
    # Determine overall grade
    if analysis['confidence_score'] >= 90 and analysis['accessibility_compliant'] and len(report['issues']) == 0:
        report['overall_grade'] = 'A - Excellent'
    elif analysis['confidence_score'] >= 70 and analysis['accessibility_compliant'] and len(report['issues']) <= 1:
        report['overall_grade'] = 'B - Good'
    elif analysis['confidence_score'] >= 50 and len(report['issues']) <= 2:
        report['overall_grade'] = 'C - Acceptable'
    elif analysis['confidence_score'] >= 30:
        report['overall_grade'] = 'D - Poor'
    else:
        report['overall_grade'] = 'F - Inadequate'
    
    # Add surface quality if available
    if surface_analysis and surface_analysis['surface_quality'] != 'unknown':
        if surface_analysis['surface_quality'] == 'smooth':
            report['issues'].append("Surface may be too smooth (slip hazard)")
            report['recommendations'].append("Consider adding non-slip surface treatment")
    
    return report

def create_detailed_ramp_analysis(image_path):
    """
    Perform comprehensive ramp analysis including accessibility assessment
    """
    detector = RampDetector()
    
    # Basic detection
    original_img = cv2.imread(image_path)
    edges, boundaries, bottom_midpoint, result_img = detector.detect_ramp_boundaries(image_path)
    analysis = detector.analyze_ramp_structure(boundaries, original_img.shape)
    
    # Advanced analysis
    handrails = detect_ramp_handrails(original_img, boundaries)
    surface_analysis = assess_ramp_surface_quality(original_img, boundaries)
    accessibility_report = generate_ramp_accessibility_report(boundaries, analysis, surface_analysis)
    
    # Print comprehensive report
    print("=" * 60)
    print("COMPREHENSIVE RAMP ANALYSIS REPORT")
    print("=" * 60)
    
    print(f"\n📏 STRUCTURAL MEASUREMENTS:")
    print(f"   Width (top): {boundaries['ramp_width_top']:.0f} px")
    print(f"   Width (bottom): {boundaries['ramp_width_bottom']:.0f} px")
    print(f"   Length: {boundaries['ramp_length']:.0f} px")
    print(f"   Angle: {boundaries['ramp_angle']:.1f}°")
    print(f"   Slope: {analysis['slope_estimate']:.3f} ({analysis['slope_estimate']*100:.1f}%)")
    
    print(f"\n🎯 DETECTION QUALITY:")
    print(f"   Confidence: {analysis['confidence_score']}%")
    print(f"   Symmetry: {analysis['symmetry_score']:.0f}%")
    print(f"   Type: {analysis['ramp_type'].title()}")
    
    print(f"\n🏗️ SURFACE ANALYSIS:")
    if surface_analysis['surface_quality'] != 'unknown':
        print(f"   Surface Quality: {surface_analysis['surface_quality'].title()}")
        print(f"   Texture Score: {surface_analysis['texture_score']:.0f}/100")
    else:
        print("   Surface analysis: Not available")
    
    print(f"\n🚪 HANDRAILS:")
    if handrails:
        print(f"   Detected: {len(handrails)} handrail(s)")
        for i, rail in enumerate(handrails):
            print(f"   Handrail {i+1}: {rail['height_above_ramp']:.0f}px above ramp")
    else:
        print("   Detected: None")
    
    print(f"\n♿ ACCESSIBILITY ASSESSMENT:")
    print(f"   Overall Grade: {accessibility_report['overall_grade']}")
    print(f"   ADA Compliant Slope: {'✓' if accessibility_report['ada_compliant'] else '✗'}")
    
    if accessibility_report['issues']:
        print(f"\n⚠️  ISSUES IDENTIFIED:")
        for issue in accessibility_report['issues']:
            print(f"   • {issue}")
    
    if accessibility_report['recommendations']:
        print(f"\n💡 RECOMMENDATIONS:")
        for rec in accessibility_report['recommendations']:
            print(f"   • {rec}")
    
    return {
        'basic_analysis': analysis,
        'boundaries': boundaries,
        'bottom_midpoint': bottom_midpoint,
        'handrails': handrails,
        'surface_analysis': surface_analysis,
        'accessibility_report': accessibility_report,
        'result_image': result_img
    }

def get_od_with_pose(left_img, od_msg, label_id=41):
    for bbox in od_msg.bboxes:
            if(bbox.id != label_id):
                continue
            
            i = np.array([bbox.x-bbox.width//2, bbox.y-bbox.height//2, bbox.x+bbox.width//2, bbox.y+bbox.height//2])
            
            bbox.pose_x = float(bbox.x)
            bbox.pose_y = float(min(i[1],i[2]))
            print("inside ramp: ", bbox.pose_x, bbox.pose_y)

    return od_msg

# Example usage and testing
if __name__ == "__main__":
    # Replace with your ramp image path
    image_path = "ramp.png"
    
    print("Starting basic ramp analysis...")
    # Basic analysis
    edges, boundaries, midpoint, analysis = main(image_path)
    
    print("\n" + "="*50)
    print("Starting comprehensive analysis...")
    # Comprehensive analysis
    comprehensive_results = create_detailed_ramp_analysis(image_path)
    
    if boundaries:
        print("\n✅ Ramp analysis completed successfully!")
        print(f"Entry/exit point: {midpoint}")
    else:
        print("\n❌ Ramp analysis failed!")