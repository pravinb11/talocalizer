#!/usr/bin/env python3
import cv2
import sys
import math
import numpy as np
from typing import Tuple, List

import rclpy
from rclpy.node import Node
from grid_map_msgs.msg import GridMap
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from nav_msgs.msg import Odometry

np.set_printoptions(threshold=sys.maxsize)

class GridMapSubscriber(Node):
    def __init__(self):
        super().__init__('grid_map_subscriber')

        self.normal_sub = self.create_subscription(
            GridMap,
            '/normal_layer_grid_map',
            self.normal_callback,
            10
        )

        self.marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)
        self.marker_pub_gt = self.create_publisher(Marker, 'visualization_marker_gt', 10)
        self.midpoint_marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)
        self.odom_pub = self.create_publisher(Odometry, "ta_midpoint_odom", 10)

        self.get_logger().info("Subscribed to /normal_layer_grid_map")

    def normal_callback(self, msg: GridMap):
        if "slope_layer" not in msg.layers:
            self.get_logger().warn("No 'slope' layer found in grid map.")
            return
        
        idx = msg.layers.index("slope_layer")
        resolution = msg.info.resolution
        grid_w = msg.info.length_x
        grid_h = msg.info.length_y
        origin_x = msg.info.pose.position.x
        origin_y = msg.info.pose.position.y
        
        slope_grid = np.array(msg.data[idx].data, dtype=np.float32).reshape(
            msg.data[idx].layout.dim[0].size, 
            msg.data[idx].layout.dim[1].size
        )        

        rows, cols = slope_grid.shape

        self.get_logger().info(
            f"\nSlope layer: shape={slope_grid.shape}, "
            f"min={np.nanmin(slope_grid):.3f}, max={np.nanmax(slope_grid):.3f}, "
            f"origin={origin_x:.3f}, {origin_y:.3f}"
        )

        slope_raw = np.nan_to_num(slope_grid, nan=0.0)
        slope_raw_norm = cv2.normalize(slope_raw, None, 0, 255, cv2.NORM_MINMAX)
        slope_raw_uint8 = slope_raw_norm.astype(np.uint8)
        slope_raw_uint8_flipped = np.flipud(slope_raw_uint8)
        slope_raw_color = cv2.applyColorMap(slope_raw_uint8_flipped, cv2.COLORMAP_JET)

        # Cap slope to 0–30° for visualization
        max_vis_angle = np.deg2rad(30.0)  # 30 deg in radians
        slope_vis = np.clip(slope_raw, 0.0, max_vis_angle)

        # Scale 0–30° → 0–255
        slope_vis_norm = (slope_vis / max_vis_angle * 255).astype(np.uint8)

        # Flip for display
        slope_vis_flipped = np.flipud(slope_vis_norm)

        # Apply color map
        slope_raw_color = cv2.applyColorMap(slope_vis_flipped, cv2.COLORMAP_JET)

        cv2.imshow("Raw Slope Layer", slope_raw_color)



        cv2.imshow("Raw Slope Layer", slope_raw_color)

        # Filter slopes between 5-20 deg
        slope_min = np.deg2rad(5.0)
        slope_max = np.deg2rad(20)
        filtered = np.where((slope_grid >= slope_min) & (slope_grid <= slope_max), 255, 0).astype(np.uint8)

        # Area of gridmap
        grid_area = grid_w * grid_h
        print(f"Grid Area: {grid_area}, Height: {grid_h}, Width: {grid_w}")

        filtered_flipped = np.flipud(filtered)
        contours, _ = cv2.findContours(filtered_flipped, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        vis = cv2.cvtColor(filtered_flipped, cv2.COLOR_GRAY2BGR)

        final_bbox = None
        final_cnt = None
        best_confidence = -1

        for i,cnt in enumerate(contours):
            x, y, w_pixel, h_pixel = cv2.boundingRect(cnt)
            w_meter, h_meter = w_pixel*resolution, h_pixel*resolution

            contour_area = w_meter * h_meter
            confidence = contour_area / grid_area * 100

            # Filter bboxes with w and h < 1 m
            if w_meter <= 1 and h_meter <= 1:
                continue

            # Filter bboxes based on area 
            if contour_area < 0.5:
                continue

            if confidence > best_confidence:
                best_confidence = confidence
                final_cnt = cnt
                final_bbox = (x, y, w_pixel, h_pixel)

            # cv2.rectangle(vis, (x, y), (x + w_pixel, y + h_pixel), (0, 255, 0), 2)
            # cv2.drawContours(vis, [cnt], -1, (0, 0, 255), 2)

            vertices = [(x, y), (x + w_pixel, y), (x, y + h_pixel), (x + w_pixel, y + h_pixel)]

            self.get_logger().info(
                f"Bounding Box {i} -> Width: {w_meter:.1f}m, Height: {h_meter:.1f}m, Area: {contour_area:.2f}, Confidence: {confidence:.2f},  Vertices: {vertices}"
            )

        if final_bbox is not None and final_cnt is not None:

            # Create a mask for the current contour
            mask = np.zeros_like(filtered_flipped, dtype=np.uint8)
            cv2.drawContours(mask, [cnt], -1, color=1, thickness=-1)  # fill contour with 1


            # Extract slope values corresponding to this contour
            # Remember slope_grid is not flipped, so flip mask back
            mask_unflipped = np.flipud(mask)
            self.get_logger().info(f"Mask sum={np.sum(mask)}, Mask_unflipped sum={np.sum(mask_unflipped)}")
            slope_values = slope_grid[mask_unflipped.astype(bool)]

            if slope_values.size > 0:
                avg_slope = np.nanmean(slope_values)
                var_slope = np.nanvar(slope_values) 

                std_rad = np.sqrt(var_slope)
                std_deg = np.rad2deg(std_rad)
                avg_slope_deg = np.rad2deg(avg_slope)

                self.get_logger().info(
                    f"Contour {i}: Avg slope={avg_slope_deg:.2f} deg, Std slope={std_deg:.2f} deg"
                )

                # Reject if slope variation too high
                if std_deg > 1.5:
                    self.get_logger().info(f"Contour {i} rejected due to slope std={std_deg:.2f} > 1.5 deg")
                    avg_slope = float('nan')
                    var_slope = float('nan')
            else:
                avg_slope = float('nan')
                var_slope = float('nan')

            # --- Visualization of masked slope layer ---
            # Normalize slope_grid for visualization (0–255)
            # --- Visualization of masked slope layer ---
            max_vis_angle = np.deg2rad(30.0)  # cap at 30 deg
            slope_clean = np.nan_to_num(slope_grid, nan=0.0, posinf=0.0, neginf=0.0)
            slope_clipped = np.clip(slope_clean, 0.0, max_vis_angle)
            slope_norm = cv2.normalize(slope_clipped, None, 0, 255, cv2.NORM_MINMAX)
            slope_color_full = cv2.applyColorMap(slope_norm.astype(np.uint8), cv2.COLORMAP_JET)

            # Mask in slope_grid coordinates
            mask_bool = mask_unflipped.astype(bool)

            # Use global normalization for consistent colors
            masked_slope = np.zeros_like(slope_norm, dtype=np.uint8)
            masked_slope[mask_bool] = slope_norm[mask_bool]

            # Apply colormap
            masked_slope_color = cv2.applyColorMap(masked_slope, cv2.COLORMAP_JET)

            # Optionally overlay the mask edges in white
            contour_overlay = masked_slope_color.copy()
            cv2.drawContours(contour_overlay, [final_cnt], -1, (255, 255, 255), 1)

            cv2.imshow("Masked Slope (Best Contour)", contour_overlay)


            x, y, w_pixel, h_pixel = final_bbox
            cv2.rectangle(vis, (x, y), (x + w_pixel, y + h_pixel), (0, 255, 0), 2)
            cv2.drawContours(vis, [final_cnt], -1, (0, 0, 255), 2)

            # x1, y1 = 0, 0
            # x2, y2 = 100, 50
            # # Draw rectangle in yellow (BGR = (0,255,255)), thickness=2
            # cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 255), 2)

            vertices = [(x, y), (x + w_pixel, y), (x + w_pixel, y + h_pixel), (x, y + h_pixel)]
            self.get_logger().info(f"Vertices: {vertices}") 
            vertices_odom = []

            #  bring pixel coordinates relative to origin in the gridmap center, convert to metres, convert to odom frame
            for (vx, vy) in vertices:
                X = (-(vx - cols/2)) * resolution + origin_x
                Y = ( (vy - rows/2)) * resolution + origin_y
                vertices_odom.append((X,Y))


            vertices_odom_1 = [(-29.0,-221.0), (-29.0,-224.0), (-32.0,-224.0), (-32.0,-221.0)]
            # [(-26.9, -221), (-26.9, -218), (-30, -218), (-30, -221)]

            self.publish_bbox(vertices_odom, (1.0,1.0,0.0), self.marker_pub)
            self.publish_bbox(vertices_odom_1, (1.0,0.0,1.0), self.marker_pub_gt)

            result_x, result_y = self.find_closest_bbox_edge_to_point(vertices_odom, (origin_x, origin_y))

            self.publish_marker(result_x, result_y, origin_x, origin_y, self.midpoint_marker_pub)
            self.publish_midpoint_odometry(result_x, result_y, origin_x, origin_y)

            cv2.imshow("Filtered Slope with Bounding Boxes", vis)
            cv2.waitKey(1)

        else:
            self.get_logger().info("No suitable slope region found in this frame.")

    def publish_midpoint_odometry(self, result_x, result_y, origin_x, origin_y):
        odom_msg = Odometry()
        odom_msg.header.frame_id = "odom"
        odom_msg.header.stamp = self.get_clock().now().to_msg()

        odom_msg.pose.pose.position.x = float(result_x)
        odom_msg.pose.pose.position.y = float(result_y)
        odom_msg.pose.pose.position.z = 0.0
        odom_msg.pose.pose.orientation.x = 0.0
        odom_msg.pose.pose.orientation.y = 0.0
        odom_msg.pose.pose.orientation.z = 0.0
        odom_msg.pose.pose.orientation.w = 1.0

        # Optionally: put distance from robot origin in covariance diagonal
        dist = math.hypot(result_x - origin_x, result_y - origin_y)
        odom_msg.pose.covariance[0] = dist ** 2
        odom_msg.pose.covariance[7] = dist ** 2
        odom_msg.pose.covariance[35] = 0.01  # small Z variance

        self.odom_pub.publish(odom_msg)
        self.get_logger().info(f"Published midpoint as Odometry: ({result_x:.2f}, {result_y:.2f})")


    def publish_bbox(self, vertices_odom, rgb, pub):
        # vertices_odom is a list of (X, Y) tuples in odom frame [(x1,y1), (x2,y2), ...]
        if len(vertices_odom) >= 4:
            marker = Marker()
            marker.header.frame_id = 'odom'  # CHANGE if your vertices_odom are in another frame
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = 'slope_bboxes'
            marker.id = 0                       # change per box if you publish many
            marker.type = Marker.LINE_STRIP     # draw connected lines
            marker.action = Marker.ADD

            # line width in meters
            marker.scale.x = 0.05               # thickness of the line
            marker.color.r = rgb[0]
            marker.color.g = rgb[1]
            marker.color.b = rgb[2]
            marker.color.a = 1.0

            # Fill the points (z set to 0.0 or msg.info.pose.position.z if needed)
            for (X, Y) in vertices_odom:
                p = Point()
                p.x = float(X)
                p.y = float(Y)
                p.z = 0.0
                marker.points.append(p)

            # close the loop by appending the first point again
            first = Point()
            first.x = float(vertices_odom[0][0])
            first.y = float(vertices_odom[0][1])
            first.z = 0.0
            marker.points.append(first)

            # Optional: set lifetime (0 = forever)
            # marker.lifetime = rclpy.duration.Duration(seconds=5).to_msg()

            pub.publish(marker)
        else:
            pass
        return
    
    def publish_marker(self, result_x, result_y, origin_x, origin_y, pub):
        # midpoint coordinates
        mx = float(result_x)
        my = float(result_y)
        mz = 0.0   # choose appropriate z (e.g. msg.info.pose.position.z or 0.0)

        # optional: compute distance from robot origin (or any reference)
        robot_x, robot_y = origin_x, origin_y
        dist = math.hypot(mx - robot_x, my - robot_y)

        # === Sphere marker (visual dot) ===
        sphere = Marker()
        sphere.header.frame_id = 'odom'                     # must match RViz fixed frame or have TF
        sphere.header.stamp = self.get_clock().now().to_msg()
        sphere.ns = 'slope_midpoint'
        sphere.id = 0
        sphere.type = Marker.SPHERE
        sphere.action = Marker.ADD

        # position & orientation
        sphere.pose.position.x = mx
        sphere.pose.position.y = my
        sphere.pose.position.z = mz
        sphere.pose.orientation.x = 0.0
        sphere.pose.orientation.y = 0.0
        sphere.pose.orientation.z = 0.0
        sphere.pose.orientation.w = 1.0

        # size of the sphere (meters)
        sphere.scale.x = 0.2
        sphere.scale.y = 0.2
        sphere.scale.z = 0.2

        # color (yellowish)
        sphere.color.r = 0.0
        sphere.color.g = 0.0
        sphere.color.b = 1.0
        sphere.color.a = 1.0

        pub.publish(sphere)



    def closest_point_on_segment(self, p: Point, a: Point, b: Point) -> Tuple[Point, float]:
        """Return (closest_point_on_segment, distance) from point p to segment a-b."""
        px, py = p
        ax, ay = a
        bx, by = b
        dx = bx - ax
        dy = by - ay
        if dx == 0 and dy == 0:
            # a and b are the same
            return (ax, ay), math.hypot(px - ax, py - ay)
        t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
        t = max(0.0, min(1.0, t))
        cx = ax + t * dx
        cy = ay + t * dy
        dist = math.hypot(px - cx, py - cy)
        return (cx, cy), dist
    
    def find_closest_bbox_edge_to_point(self, vertices: List[Point], robot_xy: Point):
        """
        vertices: list of 4 bbox corners in order (any order is OK; we treat edges by consecutive pairs, closed).
        returns: midpoint of closest edge
        """

        # compute bbox center for labeling
        cx = sum(v[0] for v in vertices) / len(vertices)
        cy = sum(v[1] for v in vertices) / len(vertices)

        best = None
        n = len(vertices)
        for i in range(n):
            a = vertices[i]
            b = vertices[(i + 1) % n]
            (cxp, cyp), d = self.closest_point_on_segment(robot_xy, a, b)

            # compute a simple label using midpoint relative to center
            mx = (a[0] + b[0]) / 2.0
            my = (a[1] + b[1]) / 2.0
            dx = mx - cx
            dy = my - cy
            if abs(dx) > abs(dy):
                label = 'left' if dx < 0 else 'right'
            else:
                label = 'top' if dy < 0 else 'bottom'

            print(f"Distance of robot to edge {i} : {d}")

            info = {
                'edge_index': i,
                'edge_endpoints': (a, b),
                'midpoint': (mx, my),
                'closest_point': (cxp, cyp),
                'distance': d,
                'label': label
            }
            if best is None or d < best['distance']:
                best = info

        return best['midpoint']       


def main(args=None):
    rclpy.init(args=args)
    node = GridMapSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down GridMap subscriber...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()