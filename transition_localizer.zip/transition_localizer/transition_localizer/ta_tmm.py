#!/usr/bin/env python3
import cv2
import sys
import math
import numpy as np
from typing import Tuple, List

import rclpy
from rclpy.node import Node
from grid_map_msgs.msg import GridMap
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from autonovus_msgs.msg import TALocation

np.set_printoptions(threshold=sys.maxsize)

class GridMapSubscriber(Node):
    def __init__(self):
        super().__init__('grid_map_subscriber')

        self.normal_sub = self.create_subscription(
            GridMap,
            '/normal_layer_grid_map',
            self.normal_callback,
            10
        )

        self.marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)
        self.marker_pub_gt = self.create_publisher(Marker, 'visualization_marker_gt', 10)
        self.midpoint_marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)
        self.odom_pub = self.create_publisher(TALocation, "ta_midpoint_odom", 10)

        self.get_logger().info("Subscribed to /normal_layer_grid_map")

        # Robot dimensions for filtering - RELAXED
        self.robot_length = 1.0  # 1m
        self.robot_width = 0.5   # 0.5m
        self.min_ramp_area = self.robot_length * self.robot_width * 8  # Reduced from 2.0 to 1.5
        
        # Allow slightly smaller dimensions with safety margin
        self.min_width = self.robot_width * 0.8   # 0.4m (80% of robot width)
        self.min_length = self.robot_length * 0.8  # 0.8m (80% of robot length)

    def normal_callback(self, msg: GridMap):
        if "slope_layer" not in msg.layers:
            self.get_logger().warn("No 'slope' layer found in grid map.")
            return
        
        idx = msg.layers.index("slope_layer")
        resolution = msg.info.resolution
        grid_w = msg.info.length_x
        grid_h = msg.info.length_y
        origin_x = msg.info.pose.position.x
        origin_y = msg.info.pose.position.y
        
        slope_grid = np.array(msg.data[idx].data, dtype=np.float32).reshape(
            msg.data[idx].layout.dim[0].size, 
            msg.data[idx].layout.dim[1].size
        )        

        rows, cols = slope_grid.shape

        self.get_logger().info(
            f"\nSlope layer: shape={slope_grid.shape}, "
            f"min={np.nanmin(slope_grid):.3f}, max={np.nanmax(slope_grid):.3f}, "
            f"origin={origin_x:.3f}, {origin_y:.3f}"
        )

        slope_raw = np.nan_to_num(slope_grid, nan=0.0)
        slope_raw_norm = cv2.normalize(slope_raw, None, 0, 255, cv2.NORM_MINMAX)
        slope_raw_uint8 = slope_raw_norm.astype(np.uint8)
        slope_raw_uint8_flipped = np.flipud(slope_raw_uint8)
        slope_raw_color = cv2.applyColorMap(slope_raw_uint8_flipped, cv2.COLORMAP_JET)

        # Cap slope to 0–30° for visualization
        max_vis_angle = np.deg2rad(30.0)  # 30 deg in radians
        slope_vis = np.clip(slope_raw, 0.0, max_vis_angle)

        # Scale 0–30° → 0–255
        slope_vis_norm = (slope_vis / max_vis_angle * 255).astype(np.uint8)

        # Flip for display
        slope_vis_flipped = np.flipud(slope_vis_norm)

        # Apply color map
        slope_raw_color = cv2.applyColorMap(slope_vis_flipped, cv2.COLORMAP_JET)

        cv2.imshow("Raw Slope Layer", slope_raw_color)

        # Filter slopes between 5-20 deg
        slope_min = np.deg2rad(6.0)
        slope_max = np.deg2rad(20)
        filtered = np.where((slope_grid >= slope_min) & (slope_grid <= slope_max), 255, 0).astype(np.uint8)

        # Area of gridmap
        grid_area = grid_w * grid_h
        print(f"Grid Area: {grid_area}, Height: {grid_h}, Width: {grid_w}")

        filtered_flipped = np.flipud(filtered)
        
        # Apply morphological operations to connect nearby regions and clean noise
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        filtered_cleaned = cv2.morphologyEx(filtered_flipped, cv2.MORPH_CLOSE, kernel)
        filtered_cleaned = cv2.morphologyEx(filtered_cleaned, cv2.MORPH_OPEN, kernel)
        
        contours, _ = cv2.findContours(filtered_cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        vis = cv2.cvtColor(filtered_flipped, cv2.COLOR_GRAY2BGR)

        final_bbox = None
        final_cnt = None
        best_score = -float('inf')
        best_contour_info = None
        all_candidates = []

        for i, cnt in enumerate(contours):
            x, y, w_pixel, h_pixel = cv2.boundingRect(cnt)
            w_meter, h_meter = w_pixel*resolution, h_pixel*resolution

            contour_area = w_meter * h_meter
            confidence = contour_area / grid_area * 100

            # RELAXED CRITERION 1: Robot Dimension Check
            if w_meter < self.min_width or h_meter < self.min_length:
                self.get_logger().info(f"Contour {i} REJECTED: dimensions {w_meter:.2f}x{h_meter:.2f}m < relaxed requirements {self.min_width:.2f}x{self.min_length:.2f}m")
                continue

            # RELAXED CRITERION 1: Minimum area check
            if contour_area < self.min_ramp_area:
                self.get_logger().info(f"Contour {i} REJECTED: area {contour_area:.2f}m² < minimum {self.min_ramp_area:.2f}m²")
                continue

            # Create a mask for the current contour
            mask = np.zeros_like(filtered_flipped, dtype=np.uint8)
            cv2.drawContours(mask, [cnt], -1, color=1, thickness=-1)  # fill contour with 1

            # Extract slope values corresponding to this contour
            mask_unflipped = np.flipud(mask)
            slope_values = slope_grid[mask_unflipped.astype(bool)]

            if slope_values.size == 0:
                continue

            # Calculate slope statistics
            # REJECT contours with significant NaN values
            nan_count = np.sum(np.isnan(slope_values))
            nan_percentage = (nan_count / slope_values.size) * 100
            max_nan_percentage = 6.0  # Allow max 6% NaN values

            if nan_percentage > max_nan_percentage:
                self.get_logger().info(f"Contour {i} REJECTED: {nan_percentage:.1f}% NaN slope values > {max_nan_percentage}%")
                continue

            # Remove NaN values for calculations
            slope_values_clean = slope_values[~np.isnan(slope_values)]
            if slope_values_clean.size == 0:
                self.get_logger().info(f"Contour {i} REJECTED: no valid slope values after NaN removal")
                continue


            avg_slope = np.nanmean(slope_values)
            std_rad = np.sqrt(np.nanvar(slope_values))
            std_deg = np.rad2deg(std_rad)
            avg_slope_deg = np.rad2deg(avg_slope)

            # Calculate visual uniformity metric (alternative to std_deg)
            # IMPROVED CRITERION 3: Slope consistency check with better binning
            slope_values_deg = np.rad2deg(slope_values_clean)
            slope_values_rounded = np.round(slope_values_deg * 2) / 2  # Round to 0.5° increments
            unique_slopes, counts = np.unique(slope_values_rounded, return_counts=True)

            # Visual uniformity: how concentrated the slopes are (inverse of entropy)
            probabilities = counts / len(slope_values_clean)
            visual_entropy = -np.sum(probabilities * np.log2(probabilities + 1e-10))
            max_possible_entropy = np.log2(len(unique_slopes))
            visual_uniformity = 1.0 - (visual_entropy / (max_possible_entropy + 1e-10))  # 0-1 scale

            # RELAXED CRITERION 2: Slope variance check - more permissive for larger areas
            base_max_std = 2.5
            area_bonus_std = min(contour_area / self.min_ramp_area, 3.0) * 0.5  # Up to +1.5° for large areas
            max_std_deg = base_max_std + area_bonus_std
            if std_deg > max_std_deg:
                self.get_logger().info(f"Contour {i} REJECTED: slope std={std_deg:.2f}° > {max_std_deg:.2f}° (area-adjusted limit)")
                continue
            
            # Find the most frequent slope and calculate consistency
            max_count_idx = np.argmax(counts)
            most_frequent_slope = unique_slopes[max_count_idx]
            most_frequent_count = counts[max_count_idx]
            total_cells = len(slope_values)
            frequency_percentage = (most_frequent_count / total_cells) * 100

            # Alternative consistency measure: Look for slopes within ±1° of most frequent
            tolerance = 1.0  # degrees
            consistent_mask = np.abs(slope_values_deg - most_frequent_slope) <= tolerance
            consistent_cells = np.sum(consistent_mask)
            consistency_percentage = (consistent_cells / total_cells) * 100

            # Use the better of the two consistency measures
            print(f"frequency_percentage : {frequency_percentage}% , consistency_percentage : {consistency_percentage}%")
            # final_consistency = max(frequency_percentage, consistency_percentage)
            final_consistency = 0.6*frequency_percentage + 0.4*consistency_percentage

            # LOWERED minimum consistency threshold
            min_consistency = 15.0  # Reduced from 5.0% to be more meaningful
            if final_consistency < min_consistency:
                self.get_logger().info(f"Contour {i} REJECTED: slope consistency {final_consistency:.1f}% < {min_consistency}%")
                continue

            # AREA-PRIORITIZED RAMP SCORING EQUATION
            # Heavily weight area and consistency, reduce smoothness penalty for large ramps

            # Area Factor: Strong preference for larger areas
            area_factor = min(contour_area / self.min_ramp_area, 6.0) ** 1.2  # Power scaling favors larger areas

            # Smoothness Factor: Use visual uniformity instead of just std_deg
            uniformity_weight = 0.7  # 70% visual uniformity, 30% std_deg
            std_component = np.exp(-std_deg / 3.0)  # Gentler std penalty
            uniformity_component = visual_uniformity ** 0.5  # Square root scaling

            smoothness_factor = uniformity_weight * uniformity_component + (1 - uniformity_weight) * std_component

            # Bonus for large areas with good uniformity
            if contour_area >= 3.0 * self.min_ramp_area and visual_uniformity > 0.6:
                smoothness_factor *= 1.2  # 20% bonus for large uniform areas

            # Consistency Factor: Strong weight on consistency
            consistency_factor = (final_consistency / 100.0) ** 1.2

            # Size Bonus: Significant bonuses for large ramps
            length_bonus = 1.0
            if contour_area >= 5.0 * self.min_ramp_area:
                length_bonus = 2.0  # Major bonus for very large ramps
            elif contour_area >= 3.0 * self.min_ramp_area:
                length_bonus = 1.6  # Good bonus for large ramps
            elif w_meter >= self.robot_width and h_meter >= self.robot_length:
                length_bonus = 1.2  # Small bonus for meeting requirements

            # Shape Factor: Less strict on shape for large areas
            aspect_ratio = max(w_meter, h_meter) / min(w_meter, h_meter)
            if contour_area >= 3.0 * self.min_ramp_area:
                shape_factor = max(0.85, 1.0 / (1.0 + (aspect_ratio - 3.0) * 0.05))  # More lenient
            else:
                shape_factor = max(0.7, 1.0 / (1.0 + (aspect_ratio - 2.0) * 0.1))   # Original

            # Final Score: Prioritize area and consistency
            composite_score = area_factor * smoothness_factor * consistency_factor * length_bonus * shape_factor

            # Store contour information
            contour_info = {
                'index': i,
                'bbox': (x, y, w_pixel, h_pixel),
                'dimensions': (w_meter, h_meter),
                'area': contour_area,
                'std_deg': std_deg,
                'frequency_percentage': frequency_percentage,
                'consistency_percentage': consistency_percentage,
                'final_consistency': final_consistency,
                'avg_slope_deg': avg_slope_deg,
                'most_frequent_slope': most_frequent_slope,
                'most_frequent_count': most_frequent_count,
                'total_cells': total_cells,
                'score': composite_score,
                'area_factor': area_factor,
                'smoothness_factor': smoothness_factor,
                'consistency_factor': consistency_factor,
                'length_bonus': length_bonus,
                'shape_factor': shape_factor,
                'aspect_ratio': aspect_ratio,
                'visual_uniformity': visual_uniformity,
                'visual_entropy': visual_entropy,
            }
            
            all_candidates.append(contour_info)

            self.get_logger().info(
                f"Contour {i} ACCEPTED: {w_meter:.1f}x{h_meter:.1f}m, "
                f"std={std_deg:.2f}°, consistency={final_consistency:.1f}%, score={composite_score:.3f}"
            )
            self.get_logger().info(
                f"  Score breakdown: area={area_factor:.2f} × smooth={smoothness_factor:.2f} × "
                f"consist={consistency_factor:.2f} × bonus={length_bonus:.2f} × shape={shape_factor:.2f}"
            )

            # Select best contour based on composite score
            if composite_score > best_score:
                best_score = composite_score
                final_cnt = cnt
                final_bbox = (x, y, w_pixel, h_pixel)
                best_contour_info = contour_info

        # Log all candidates for debugging
        if all_candidates:
            self.get_logger().info(f"\nFound {len(all_candidates)} candidate ramps:")
            for info in sorted(all_candidates, key=lambda x: x['score'], reverse=True)[:5]:
                self.get_logger().info(
                    f"  Contour {info['index']}: {info['dimensions'][0]:.1f}x{info['dimensions'][1]:.1f}m, "
                    f"area={info['area']:.1f}m², consistency={info['final_consistency']:.1f}%, score={info['score']:.3f}, "
                    f"visual_uniformity={info['visual_uniformity']:.1f}, visual_entropy={info['visual_entropy']:.1f}"
                )

        if final_bbox is not None and final_cnt is not None and best_contour_info is not None:
            info = best_contour_info
            
            self.get_logger().info(
                f"\n********************************************"
            )
            self.get_logger().info(
                f"SELECTED RAMP: Contour {info['index']} with score {best_score:.3f}"
            )
            self.get_logger().info(
                f"Dimensions: {info['dimensions'][0]:.1f}m × {info['dimensions'][1]:.1f}m (area: {info['area']:.2f}m²)"
            )
            self.get_logger().info(
                f"Slope stats: avg={info['avg_slope_deg']:.1f}°, std={info['std_deg']:.2f}°"
            )
            self.get_logger().info(
                f"Consistency: {info['final_consistency']:.1f}% (freq={info['frequency_percentage']:.1f}%, tol={info['consistency_percentage']:.1f}%)"
            )
            self.get_logger().info(
                f"Score factors: area={info['area_factor']:.2f}, smooth={info['smoothness_factor']:.2f}, "
                f"consist={info['consistency_factor']:.2f}, bonus={info['length_bonus']:.2f}, shape={info['shape_factor']:.2f}"
            )

            bbox_accepted = True

            # --- Always show visualization of raw and masked slope layers ---
            # Recreate mask for visualization
            mask = np.zeros_like(filtered_flipped, dtype=np.uint8)
            cv2.drawContours(mask, [final_cnt], -1, color=1, thickness=-1)
            mask_unflipped = np.flipud(mask)
            
            max_vis_angle = np.deg2rad(30.0)  # cap at 30 deg
            slope_clean = np.nan_to_num(slope_grid, nan=0.0, posinf=0.0, neginf=0.0)
            slope_clipped = np.clip(slope_clean, 0.0, max_vis_angle)
            slope_norm = cv2.normalize(slope_clipped, None, 0, 255, cv2.NORM_MINMAX)
            slope_color_full = cv2.applyColorMap(slope_norm.astype(np.uint8), cv2.COLORMAP_JET)

            # Mask in slope_grid coordinates
            mask_bool = mask_unflipped.astype(bool)

            # Use global normalization for consistent colors
            masked_slope = np.zeros_like(slope_norm, dtype=np.uint8)
            masked_slope[mask_bool] = slope_norm[mask_bool]

            # Apply colormap
            masked_slope_color = cv2.applyColorMap(masked_slope, cv2.COLORMAP_JET)

            # Optionally overlay the mask edges in white
            contour_overlay = masked_slope_color.copy()
            cv2.drawContours(contour_overlay, [final_cnt], -1, (255, 255, 255), 1)

            cv2.imshow("Masked Slope (Best Contour)", contour_overlay)

            # Show the filtered visualization with contour outline
            x, y, w_pixel, h_pixel = final_bbox
            bbox_color = (0, 255, 0)  # Green for accepted ramp
            contour_color = (0, 0, 255)  # Red for contour
                
            cv2.rectangle(vis, (x, y), (x + w_pixel, y + h_pixel), bbox_color, 2)
            cv2.drawContours(vis, [final_cnt], -1, contour_color, 2)

            # Publish markers and midpoint
            vertices = [(x, y), (x + w_pixel, y), (x + w_pixel, y + h_pixel), (x, y + h_pixel)]
            self.get_logger().info(f"Ramp vertices: {vertices}") 
            vertices_odom = []

            # Bring pixel coordinates relative to origin in the gridmap center, convert to metres, convert to odom frame
            for (vx, vy) in vertices:
                X = (-(vx - cols/2)) * resolution + origin_x
                Y = ( (vy - rows/2)) * resolution + origin_y
                vertices_odom.append((X,Y))

            vertices_odom_1 = [(-29.0,-221.0), (-29.0,-224.0), (-32.0,-224.0), (-32.0,-221.0)]

            self.publish_bbox(vertices_odom, (1.0,1.0,0.0), self.marker_pub)
            self.publish_bbox(vertices_odom_1, (1.0,0.0,1.0), self.marker_pub_gt)

            result_x, result_y = self.find_closest_bbox_edge_to_point(vertices_odom, (origin_x, origin_y))

            self.publish_marker(result_x, result_y, origin_x, origin_y, self.midpoint_marker_pub)
            self.publish_midpoint_odometry(msg, result_x, result_y, composite_score)

            cv2.imshow("Filtered Slope with Bounding Boxes", vis)
            cv2.waitKey(1)

        else:
            self.get_logger().info("No suitable ramp region found in this frame.")

    def publish_midpoint_odometry(self, tmm_msg, result_x, result_y, score):
        # odom_msg = TALocation()
        # odom_msg.header.frame_id = "odom"
        # odom_msg.header.stamp = self.get_clock().now().to_msg()

        # odom_msg.pose.pose.position.x = float(result_x)
        # odom_msg.pose.pose.position.y = float(result_y)
        # odom_msg.pose.pose.position.z = 0.0
        # odom_msg.pose.pose.orientation.x = 0.0
        # odom_msg.pose.pose.orientation.y = 0.0
        # odom_msg.pose.pose.orientation.z = 0.0
        # odom_msg.pose.pose.orientation.w = 1.0

        # # Optionally: put distance from robot origin in covariance diagonal
        # dist = math.hypot(result_x - origin_x, result_y - origin_y)
        # odom_msg.pose.covariance[0] = dist ** 2
        # odom_msg.pose.covariance[7] = dist ** 2
        # odom_msg.pose.covariance[35] = 0.01  # small Z variance

        msg = TALocation()
        msg.header.stamp = tmm_msg.header.stamp
        msg.header.frame_id = "odom"
        msg.label = "Ramp"   
        msg.pose.position.x = float(result_x)
        msg.pose.position.y = float(result_y)
        msg.pose.position.z = 0.0
        msg.pose.orientation.x = 0.0
        msg.pose.orientation.y = 0.0
        msg.pose.orientation.z = 0.0
        msg.pose.orientation.w = 1.0
        msg.confidence = score

        self.odom_pub.publish(msg)
        self.get_logger().info(f"Published ramp midpoint as Odometry: ({result_x:.2f}, {result_y:.2f})")

    def publish_bbox(self, vertices_odom, rgb, pub):
        # vertices_odom is a list of (X, Y) tuples in odom frame [(x1,y1), (x2,y2), ...]
        if len(vertices_odom) >= 4:
            marker = Marker()
            marker.header.frame_id = 'odom'  # CHANGE if your vertices_odom are in another frame
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = 'slope_bboxes'
            marker.id = 0                       # change per box if you publish many
            marker.type = Marker.LINE_STRIP     # draw connected lines
            marker.action = Marker.ADD

            # line width in meters
            marker.scale.x = 0.05               # thickness of the line
            marker.color.r = rgb[0]
            marker.color.g = rgb[1]
            marker.color.b = rgb[2]
            marker.color.a = 1.0

            # Fill the points (z set to 0.0 or msg.info.pose.position.z if needed)
            for (X, Y) in vertices_odom:
                p = Point()
                p.x = float(X)
                p.y = float(Y)
                p.z = 0.0
                marker.points.append(p)

            # close the loop by appending the first point again
            first = Point()
            first.x = float(vertices_odom[0][0])
            first.y = float(vertices_odom[0][1])
            first.z = 0.0
            marker.points.append(first)

            pub.publish(marker)
        else:
            pass
        return
    
    def publish_marker(self, result_x, result_y, origin_x, origin_y, pub):
        # midpoint coordinates
        mx = float(result_x)
        my = float(result_y)
        mz = 0.0

        # === Sphere marker (visual dot) ===
        sphere = Marker()
        sphere.header.frame_id = 'odom'
        sphere.header.stamp = self.get_clock().now().to_msg()
        sphere.ns = 'slope_midpoint'
        sphere.id = 0
        sphere.type = Marker.SPHERE
        sphere.action = Marker.ADD

        # position & orientation
        sphere.pose.position.x = mx
        sphere.pose.position.y = my
        sphere.pose.position.z = mz
        sphere.pose.orientation.x = 0.0
        sphere.pose.orientation.y = 0.0
        sphere.pose.orientation.z = 0.0
        sphere.pose.orientation.w = 1.0

        # size of the sphere (meters)
        sphere.scale.x = 0.2
        sphere.scale.y = 0.2
        sphere.scale.z = 0.2

        # color (blue for ramp target)
        sphere.color.r = 0.0
        sphere.color.g = 0.0
        sphere.color.b = 1.0
        sphere.color.a = 1.0

        pub.publish(sphere)

    def closest_point_on_segment(self, p: Point, a: Point, b: Point) -> Tuple[Point, float]:
        """Return (closest_point_on_segment, distance) from point p to segment a-b."""
        px, py = p
        ax, ay = a
        bx, by = b
        dx = bx - ax
        dy = by - ay
        if dx == 0 and dy == 0:
            # a and b are the same
            return (ax, ay), math.hypot(px - ax, py - ay)
        t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
        t = max(0.0, min(1.0, t))
        cx = ax + t * dx
        cy = ay + t * dy
        dist = math.hypot(px - cx, py - cy)
        return (cx, cy), dist
    
    def find_closest_bbox_edge_to_point(self, vertices: List[Point], robot_xy: Point):
        """
        vertices: list of 4 bbox corners in order (any order is OK; we treat edges by consecutive pairs, closed).
        returns: midpoint of closest edge
        """

        # compute bbox center for labeling
        cx = sum(v[0] for v in vertices) / len(vertices)
        cy = sum(v[1] for v in vertices) / len(vertices)

        best = None
        n = len(vertices)
        for i in range(n):
            a = vertices[i]
            b = vertices[(i + 1) % n]
            (cxp, cyp), d = self.closest_point_on_segment(robot_xy, a, b)

            # compute a simple label using midpoint relative to center
            mx = (a[0] + b[0]) / 2.0
            my = (a[1] + b[1]) / 2.0
            dx = mx - cx
            dy = my - cy
            if abs(dx) > abs(dy):
                label = 'left' if dx < 0 else 'right'
            else:
                label = 'top' if dy < 0 else 'bottom'

            print(f"Distance of robot to edge {i} : {d}")

            info = {
                'edge_index': i,
                'edge_endpoints': (a, b),
                'midpoint': (mx, my),
                'closest_point': (cxp, cyp),
                'distance': d,
                'label': label
            }
            if best is None or d < best['distance']:
                best = info

        return best['midpoint']       


def main(args=None):
    rclpy.init(args=args)
    node = GridMapSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down GridMap subscriber...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()