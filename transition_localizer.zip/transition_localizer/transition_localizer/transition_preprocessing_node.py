import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
import tf2_ros
import tf2_geometry_msgs
from geometry_msgs.msg import Twist, PoseStamped, TransformStamped
from std_srvs.srv import Trigger
import math
import time
from threading import Lock
import numpy as np
from autonovus_msgs.msg import ObjectDetection
from autonovus_msgs.msg import BoundingBox
from autonovus_msgs.srv import TNPreprocessingStop
from autonovus_msgs.srv import TNPreprocessingStart

class TransitionAlignmentNode(Node):
    def __init__(self):
        super().__init__('transition_preprocessing_node')
        self.get_logger().info('transition Alignment Node initialized')
        self.get_logger().info('Services available:')
        self.get_logger().info('  - /start_transition_alignment: Start monitoring poses')
        self.get_logger().info('  - /stop_transition_alignment: Stop monitoring and return best pose')#!/usr/bin/env python3

        # Callback group for multi-threading
        self.callback_group = ReentrantCallbackGroup()
        
        # Initialize tf buffer and listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        # Subscribers
        self.detection_sub = self.create_subscription(
            ObjectDetection,
            '/object_detection',
            self.detection_callback,
            10,
            callback_group=self.callback_group
        )
        
        # Service servers
        self.start_service = self.create_service(
            TNPreprocessingStart,
            'start_transition_alignment',
            self.start_alignment_callback,
            callback_group=self.callback_group
        )
        
        self.stop_service = self.create_service(
            TNPreprocessingStop,
            'stop_transition_alignment',
            self.stop_alignment_callback,
            callback_group=self.callback_group
        )
        
        # State variables
        self.current_detections = []
        self.current_label = ""
        self.detections_lock = Lock()
        self.is_monitoring = False
        self.best_pose = None
        self.best_score = 0.0
        self.pose_history = []  # Store pose and score pairs
        
        # Configuration parameters
        self.image_width = 640  # Adjust based on your camera
        self.image_height = 480  # Adjust based on your camera
        self.confidence_threshold = 0.3
        self.minimum_score_threshold = 0.3  # Minimum score to consider alignment successful
        self.evaluation_rate = 10.0  # Hz - how often to evaluate poses
        
        # Timer for continuous pose evaluation while monitoring
        self.evaluation_timer = self.create_timer(
            1.0 / self.evaluation_rate,
            self.evaluate_pose_callback
        )
    
    def detection_callback(self, msg):
        """Callback for object detection messages"""
        if not self.is_monitoring:
            return

        with self.detections_lock:
            # Filter for stair detections with sufficient confidence
            stair_bboxes = []
            for bbox in msg.bboxes:
                if (bbox.label.lower() == self.current_label.lower()) and bbox.conf >= self.confidence_threshold:
                    stair_bboxes.append(bbox)
            
            self.current_detections = stair_bboxes
    
    def get_current_pose(self):
        """Get current robot pose from tf"""
        try:
            transform = self.tf_buffer.lookup_transform(
                'odom', 
                'base_link', 
                rclpy.time.Time(),
                timeout=rclpy.duration.Duration(seconds=1.0)
            )
            
            # Extract pose information
            pose = PoseStamped()
            pose.header = transform.header
            pose.pose.position.x = transform.transform.translation.x
            pose.pose.position.y = transform.transform.translation.y
            pose.pose.position.z = transform.transform.translation.z
            pose.pose.orientation = transform.transform.rotation
            
            return pose
            
        except Exception as e:
            self.get_logger().warn(f'Failed to get current pose: {e}')
            return None
    
    def calculate_bbox_score(self, bbox):
        """Calculate score for a bounding box based on size and center alignment"""
        # Normalize coordinates
        center_x_norm = bbox.x / self.image_width
        center_y_norm = bbox.y / self.image_height
        
        # Calculate area
        area = bbox.width * bbox.height
        area_norm = area / (self.image_width * self.image_height)
        
        # Calculate center alignment score (higher score for center alignment)
        center_score = 1.0 - abs(center_x_norm - 0.5) * 2  # 0 to 1 scale
        
        # Combine area and center alignment with confidence
        # Weight: 40% area, 40% center alignment, 20% confidence
        total_score = (0.4 * area_norm + 
                      0.4 * center_score + 
                      0.2 * bbox.conf)
        
        return total_score
    
    def evaluate_current_view(self):
        """Evaluate current view and return best stair detection score"""
        with self.detections_lock:
            if not self.current_detections:
                return 0.0
            
            # Find the best stair bounding box in current view
            best_score = 0.0
            for bbox in self.current_detections:
                score = self.calculate_bbox_score(bbox)
                if score > best_score:
                    best_score = score
            
            return best_score
    
    def evaluate_pose_callback(self):
        """Timer callback to continuously evaluate poses while monitoring"""
        if not self.is_monitoring:
            return
        
        # Get current pose
        current_pose = self.get_current_pose()
        if current_pose is None:
            return
        
        # Evaluate current view
        current_score = self.evaluate_current_view()
        
        # Store pose and score
        pose_data = {
            'pose': current_pose,
            'score': current_score,
            'timestamp': time.time()
        }
        self.pose_history.append(pose_data)
        
        # Update best pose if current is better
        if current_score > self.best_score:
            self.best_score = current_score
            self.best_pose = current_pose
            self.get_logger().info(f'New best alignment score: {current_score:.3f}')
    
    def reset_monitoring_state(self):
        """Reset monitoring state for new alignment session"""
        self.current_label = ""
        self.best_pose = None
        self.best_score = 0.0
        self.pose_history = []
    
    def start_alignment_callback(self, request, response):
        """Service callback to start monitoring poses for alignment"""
        if self.is_monitoring:
            response.success = False
            response.message = "Already monitoring for transition alignment"
            return response
        
        self.get_logger().info('Starting transition alignment monitoring...')
        
        # Reset state
        self.reset_monitoring_state()
        
        # Start monitoring
        self.is_monitoring = True
        self.current_label = request.label
        
        response.success = True
        response.message = "Started monitoring poses for transition alignment for " + request.label
        return response
    
    def stop_alignment_callback(self, request, response):
        """Service callback to stop monitoring and return best pose"""
        if not self.is_monitoring:
            response.success = False
            response.message = "Not currently monitoring for alignment"
            response.theta = 0.0
            return response
        
        self.get_logger().info('Stopping transition alignment monitoring...')
        
        # Stop monitoring
        self.is_monitoring = False
        
        # Check if we found a good alignment
        if self.best_pose is not None and self.best_score >= self.minimum_score_threshold:
            # Extract orientation from best pose for logging
            quat = self.best_pose.pose.orientation
            yaw = math.atan2(
                2.0 * (quat.w * quat.z + quat.x * quat.y),
                1.0 - 2.0 * (quat.y * quat.y + quat.z * quat.z)
            )
            
            self.get_logger().info(f'Best alignment found:')
            self.get_logger().info(f'  Score: {self.best_score:.3f}')
            self.get_logger().info(f'  Position: ({self.best_pose.pose.position.x:.3f}, '
                                 f'{self.best_pose.pose.position.y:.3f})')
            self.get_logger().info(f'  Orientation (yaw): {math.degrees(yaw):.1f}°')
            self.get_logger().info(f'  Total poses evaluated: {len(self.pose_history)}')
            
            response.success = True
            response.message = "Yaw successfully calculated"
            response.theta = math.degrees(yaw)
            
            # response.message = (f"Alignment successful! Score: {self.best_score:.3f}, "
            #                   f"Position: ({self.best_pose.pose.position.x:.3f}, "
            #                   f"{self.best_pose.pose.position.y:.3f}), "
            #                   f"Yaw: {math.degrees(yaw):.1f}°")
        else:
            score_msg = f"Best score: {self.best_score:.3f}" if self.best_score > 0 else "No valid detections"
            self.get_logger().warn(f'No suitable alignment found. {score_msg}')
            
            response.success = False
            response.message = (f"No suitable alignment found. {score_msg}. "
                              f"Minimum required: {self.minimum_score_threshold:.3f}")
            response.theta = 0.0
        
        return response

def main(args=None):
    rclpy.init(args=args)
    
    node = TransitionAlignmentNode()
    
    # Use MultiThreadedExecutor for handling service calls and subscriptions
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()