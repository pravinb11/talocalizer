#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from grid_map_msgs.msg import GridMap
import numpy as np
import matplotlib.pyplot as plt
import cv2
import sys
np.set_printoptions(threshold=sys.maxsize)
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point

import math
from typing import Tuple, List




class GridMapSubscriber(Node):
    def __init__(self):
        super().__init__('grid_map_subscriber')

        self.normal_sub = self.create_subscription(
            GridMap,
            '/normal_layer_grid_map',
            self.normal_callback,
            10
        )
        Point = Tuple[float, float]

        self.marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)
        self.marker_pub_gt = self.create_publisher(Marker, 'visualization_marker_gt', 10)
        self.midpoint_marker_pub = self.create_publisher(Marker, 'visualization_marker', 10)

        # Subscriber for /elevation_map_raw
        # self.elevation_sub = self.create_subscription(
        #     GridMap,
        #     '/elevation_map_raw',
        #     self.elevation_callback,
        #     10
        # )

        # cv2.namedWindow("Filtered Slope Layer", cv2.WINDOW_NORMAL)

        self.get_logger().info("Subscribed to /normal_layer_grid_map and /elevation_map_raw")

    # def normal_callback(self, msg: GridMap):
    #     layers = list(msg.layers)
    #     self.get_logger().info(
    #         f"[NORMAL MAP] Frame: {msg.header.frame_id}, "
    #         f"Timestamp: {msg.header.stamp.sec}.{msg.header.stamp.nanosec}, "
    #         f"Layers: {layers}"
    #     )

    #     if "slope_layer" in layers:
    #         idx = layers.index("slope_layer")
    #         slope_data = np.array(msg.data[idx].data, dtype=np.float32)

    #         # Row-major order
    #         rows, cols = msg.info.length_y, msg.info.length_x
    #         resolution = msg.info.resolution
    #         grid_rows = int(rows / resolution)
    #         grid_cols = int(cols / resolution)
    #         slope_grid = slope_data.reshape((grid_rows, grid_cols))

    #         self.get_logger().info(
    #             f"Slope layer extracted: shape={slope_grid.shape}, "
    #             f"min={np.nanmin(slope_grid):.3f}, max={np.nanmax(slope_grid):.3f}"
    #         )

    #         slope_raw = np.nan_to_num(slope_grid, nan=0.0)
    #         slope_raw_norm = cv2.normalize(slope_raw, None, 0, 255, cv2.NORM_MINMAX)
    #         slope_raw_uint8 = slope_raw_norm.astype(np.uint8)
    #         slope_raw_color = cv2.applyColorMap(slope_raw_uint8, cv2.COLORMAP_JET)
    #         cv2.imshow("Raw Slope Layer", slope_raw_color)

    #         min_slope = np.deg2rad(10.0)
    #         max_slope = np.deg2rad(40.0)

    #         slope_filtered = np.full_like(slope_grid, np.nan)
    #         # mask = (slope_grid >= min_slope) & (slope_grid <= max_slope)
    #         mask = (slope_grid <= max_slope)
    #         slope_filtered[mask] = slope_grid[mask]

    #         if np.any(mask):
    #             self.get_logger().info(
    #                 f"Filtered slope grid: kept {np.count_nonzero(mask)} cells "
    #                 f"({np.count_nonzero(mask) / slope_grid.size * 100:.2f}%), "
    #                 f"min={np.nanmin(slope_filtered):.3f}, "
    #                 f"max={np.nanmax(slope_filtered):.3f} (radians)"
    #             )
    #         else:
    #             self.get_logger().warn("No slopes found in the 10°–40° range.")

    #         # === Visualization ===
    #         slope_display = np.nan_to_num(slope_filtered, nan=0.0)
    #         slope_norm = cv2.normalize(slope_display, None, 0, 255, cv2.NORM_MINMAX)
    #         slope_uint8 = slope_norm.astype(np.uint8)
    #         slope_color = cv2.applyColorMap(slope_uint8, cv2.COLORMAP_JET)

    #         cv2.imshow("Filtered Slope Layer", slope_color)
    #         cv2.waitKey(1)

    def normal_callback(self, msg: GridMap):
        if "slope_layer" not in msg.layers:
            self.get_logger().warn("No 'slope' layer found in grid map.")
            return
        
        idx = msg.layers.index("slope_layer")
        resolution = msg.info.resolution
        grid_w = msg.info.length_x
        grid_h = msg.info.length_y
        origin_x = msg.info.pose.position.x
        origin_y = msg.info.pose.position.y
        
        slope_grid = np.array(msg.data[idx].data, dtype=np.float32).reshape(
            msg.data[idx].layout.dim[0].size, 
            msg.data[idx].layout.dim[1].size
        )        

        rows, cols = slope_grid.shape

        self.get_logger().info(
            f"Slope layer: shape={slope_grid.shape}, "
            f"min={np.nanmin(slope_grid):.3f}, max={np.nanmax(slope_grid):.3f}, "
            f"origin={origin_x:.3f}, {origin_y:.3f}"
        )

        slope_raw = np.nan_to_num(slope_grid, nan=0.0)
        slope_raw_norm = cv2.normalize(slope_raw, None, 0, 255, cv2.NORM_MINMAX)
        slope_raw_uint8 = slope_raw_norm.astype(np.uint8)
        slope_raw_color = cv2.applyColorMap(slope_raw_uint8, cv2.COLORMAP_JET)
        cv2.imshow("Raw Slope Layer", slope_raw_color)

        # Filter slopes between 5-20 deg
        slope_min = np.deg2rad(5.0)
        slope_max = np.deg2rad(20)
        filtered = np.where((slope_grid >= slope_min) & (slope_grid <= slope_max), 255, 0).astype(np.uint8)

        # Area of gridmap
        grid_area = grid_w * grid_h
        print(f"Grid Area: {grid_area}, Height: {grid_h}, Width: {grid_w}")

        contours, _ = cv2.findContours(filtered, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        vis = cv2.cvtColor(filtered, cv2.COLOR_GRAY2BGR)

        for i,cnt in enumerate(contours):
            x, y, w_pixel, h_pixel = cv2.boundingRect(cnt)
            w_meter, h_meter = w_pixel*resolution, h_pixel*resolution

            contour_area = w_meter * h_meter
            confidence = contour_area / grid_area * 100

            # Filter bboxes with w and h < 1 m
            if w_meter <= 1 and h_meter <= 1:
                continue

            # Filter bboxes based on area 
            if contour_area < 0.5:
                continue
            elif contour_area > 2:
                final_cnt = cnt
                final_bbox = (x, y, w_pixel, h_pixel)

            # cv2.rectangle(vis, (x, y), (x + w_pixel, y + h_pixel), (0, 255, 0), 2)
            # cv2.drawContours(vis, [cnt], -1, (0, 0, 255), 2)

            vertices = [(x, y), (x + w_pixel, y), (x, y + h_pixel), (x + w_pixel, y + h_pixel)]

            self.get_logger().info(
                f"Bounding Box {i} -> Width: {w_meter:.1f}m, Height: {h_meter:.1f}m, Area: {contour_area:.2f}, Confidence: {confidence:.2f},  Vertices: {vertices}"
            )


        x, y, w_pixel, h_pixel = final_bbox
        # cv2.rectangle(vis, (x, y), (x + w_pixel, y + h_pixel), (0, 255, 0), 2)
        # cv2.drawContours(vis, [final_cnt], -1, (0, 0, 255), 2)

        x1, y1 = 0, 0
        x2, y2 = 159, 101597
        # Draw rectangle in yellow (BGR = (0,255,255)), thickness=2
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 255), 2)

        vertices = [(x, y), (x + w_pixel, y), (x + w_pixel, y + h_pixel), (x, y + h_pixel)]
        self.get_logger().info(f"Vertices: {vertices}") 
        vertices_odom = []

        #  bring pixel coordinates relative to origin in the gridmap center, convert to metres, convert to odom frame
        # [(89, 68), (117, 68), (117, 107), (89, 107)]
        print(f"origin_x = {origin_x}, origin_y = {origin_y}")
        print(f"rows = {rows}, cols = {cols}")
        print(f"rows/2 = {rows/2}, cols/2 = {cols/2}")
        for (vx, vy) in vertices:
            # X = ( (vy - rows/2)) * resolution + origin_x
            # Y = ( (vx - cols/2)) * resolution + origin_y
            dx_pix = vx - (cols / 2.0)    # + right
            dy_pix = vy - (rows / 2.0)    # + down

            X = ( - dx_pix ) * resolution + origin_x   # right -> negative X because X increases left
            Y = (   dy_pix ) * resolution + origin_y   # down -> positive Y because Y increases down
            print(f"vx = {vx} with cols/2 = {cols/2} gives Y = {Y}")
            print(f"vy = {vy} with rows/2 = {rows/2} gives X = {X}")
            vertices_odom.append((X,Y))

        print(f"Odom vertices: {vertices_odom}")
        print(f"Odom center: {vertices_odom}")

        vertices_odom_1 = [(-29.0,-221.0), (-29.0,-224.0), (-32.0,-224.0), (-32.0,-221.0)]
        # [(-26.9, -221), (-26.9, -218), (-30, -218), (-30, -221)]

        # vertices_odom is a list of (X, Y) tuples in odom frame [(x1,y1), (x2,y2), ...]
        if len(vertices_odom) >= 4:
            marker = Marker()
            marker.header.frame_id = 'odom'  # CHANGE if your vertices_odom are in another frame
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = 'slope_bboxes'
            marker.id = 0                       # change per box if you publish many
            marker.type = Marker.LINE_STRIP     # draw connected lines
            marker.action = Marker.ADD

            # line width in meters
            marker.scale.x = 0.05               # thickness of the line

            # yellow color (r=1,g=1,b=0)
            marker.color.r = 1.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            marker.color.a = 1.0

            # Fill the points (z set to 0.0 or msg.info.pose.position.z if needed)
            for (X, Y) in vertices_odom:
                p = Point()
                p.x = float(X)
                p.y = float(Y)
                p.z = 0.0
                marker.points.append(p)

            # close the loop by appending the first point again
            first = Point()
            first.x = float(vertices_odom[0][0])
            first.y = float(vertices_odom[0][1])
            first.z = 0.0
            marker.points.append(first)

            # Optional: set lifetime (0 = forever)
            # marker.lifetime = rclpy.duration.Duration(seconds=5).to_msg()

            self.marker_pub.publish(marker)
            self.marker_pub_gt
        else:
            pass

        if len(vertices_odom_1) >= 4:
            marker = Marker()
            marker.header.frame_id = 'odom'  # CHANGE if your vertices_odom are in another frame
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = 'slope_bboxes'
            marker.id = 0                       # change per box if you publish many
            marker.type = Marker.LINE_STRIP     # draw connected lines
            marker.action = Marker.ADD

            # line width in meters
            marker.scale.x = 0.05               # thickness of the line

            # yellow color (r=1,g=1,b=0)
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 1.0
            marker.color.a = 1.0

            # Fill the points (z set to 0.0 or msg.info.pose.position.z if needed)
            for (X, Y) in vertices_odom_1:
                p = Point()
                p.x = float(X)
                p.y = float(Y)
                p.z = 0.0
                marker.points.append(p)

            # close the loop by appending the first point again
            first = Point()
            first.x = float(vertices_odom_1[0][0])
            first.y = float(vertices_odom_1[0][1])
            first.z = 0.0
            marker.points.append(first)

            # Optional: set lifetime (0 = forever)
            # marker.lifetime = rclpy.duration.Duration(seconds=5).to_msg()
            self.marker_pub_gt.publish(marker)
        else:
            pass

        result_x, result_y = self.find_closest_bbox_edge_to_point(vertices_odom, (origin_x, origin_y))
        print(f"\nMidpoint : {result_x}, {result_y} \n")


        # midpoint coordinates
        mx = float(result_x)
        my = float(result_y)
        mz = 0.0   # choose appropriate z (e.g. msg.info.pose.position.z or 0.0)

        # optional: compute distance from robot origin (or any reference)
        robot_x, robot_y = origin_x, origin_y
        dist = math.hypot(mx - robot_x, my - robot_y)

        # === Sphere marker (visual dot) ===
        sphere = Marker()
        sphere.header.frame_id = 'odom'                     # must match RViz fixed frame or have TF
        sphere.header.stamp = self.get_clock().now().to_msg()
        sphere.ns = 'slope_midpoint'
        sphere.id = 0
        sphere.type = Marker.SPHERE
        sphere.action = Marker.ADD

        # position & orientation
        sphere.pose.position.x = mx
        sphere.pose.position.y = my
        sphere.pose.position.z = mz
        sphere.pose.orientation.x = 0.0
        sphere.pose.orientation.y = 0.0
        sphere.pose.orientation.z = 0.0
        sphere.pose.orientation.w = 1.0

        # size of the sphere (meters)
        sphere.scale.x = 0.2
        sphere.scale.y = 0.2
        sphere.scale.z = 0.2

        # color (yellowish)
        sphere.color.r = 0.0
        sphere.color.g = 0.0
        sphere.color.b = 1.0
        sphere.color.a = 1.0

        # optional lifetime (0 = forever)
        # import builtin rclpy Duration if you want a finite life
        # sphere.lifetime = rclpy.duration.Duration(seconds=5).to_msg()

        self.midpoint_marker_pub.publish(sphere)


        cv2.imshow("Filtered Slope with Bounding Boxes", vis)
        cv2.waitKey(1)



    def closest_point_on_segment(self, p: Point, a: Point, b: Point) -> Tuple[Point, float]:
        """Return (closest_point_on_segment, distance) from point p to segment a-b."""
        px, py = p
        ax, ay = a
        bx, by = b
        dx = bx - ax
        dy = by - ay
        if dx == 0 and dy == 0:
            # a and b are the same
            return (ax, ay), math.hypot(px - ax, py - ay)
        t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
        t = max(0.0, min(1.0, t))
        cx = ax + t * dx
        cy = ay + t * dy
        dist = math.hypot(px - cx, py - cy)
        return (cx, cy), dist
    
    def find_closest_bbox_edge_to_point(self, vertices: List[Point], robot_xy: Point):
        """
        vertices: list of 4 bbox corners in order (any order is OK; we treat edges by consecutive pairs, closed).
        returns: midpoint of closest edge
        """

        # compute bbox center for labeling
        cx = sum(v[0] for v in vertices) / len(vertices)
        cy = sum(v[1] for v in vertices) / len(vertices)

        best = None
        n = len(vertices)
        for i in range(n):
            a = vertices[i]
            b = vertices[(i + 1) % n]
            (cxp, cyp), d = self.closest_point_on_segment(robot_xy, a, b)

            # compute a simple label using midpoint relative to center
            mx = (a[0] + b[0]) / 2.0
            my = (a[1] + b[1]) / 2.0
            dx = mx - cx
            dy = my - cy
            if abs(dx) > abs(dy):
                label = 'left' if dx < 0 else 'right'
            else:
                label = 'top' if dy < 0 else 'bottom'

            info = {
                'edge_index': i,
                'edge_endpoints': (a, b),
                'midpoint': (mx, my),
                'closest_point': (cxp, cyp),
                'distance': d,
                'label': label
            }
            if best is None or d < best['distance']:
                best = info

        return best['midpoint']       


    def elevation_callback(self, msg: GridMap):
        self.get_logger().info(
            f"[ELEVATION MAP] Frame: {msg.header.frame_id}, "
            f"Timestamp: {msg.header.stamp.sec}.{msg.header.stamp.nanosec}, "
            f"Layers: {list(msg.layers)}"
        )


def main(args=None):
    rclpy.init(args=args)
    node = GridMapSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down GridMap subscriber...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()