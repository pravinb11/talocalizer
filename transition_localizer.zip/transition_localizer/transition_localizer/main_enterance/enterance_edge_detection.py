import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage
from sklearn.cluster import DBSCAN

class EnteranceDetector:
    def __init__(self):
        self.debug = True
        self.bbox_tol = 1.2

    def detect_entrance_boundaries(self, image_path):
        """
        Detect boundaries of an entrance door and find the bottom midpoint
        
        Args:
            image_path (str): Path to the door image
        
        Returns:
            tuple: (edges, door_boundaries, bottom_point, processed_image)
        """
        
        # Read the image
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Could not load image from {image_path}")
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
        # Apply edge detection using Canny
        edges = cv2.Canny(blurred, 50, 150, apertureSize=3)
        # Detect door frame lines
        door_lines = self.detect_door_lines(edges)
        
        # Find door boundaries
        door_boundaries = self.find_door_boundaries(door_lines, img.shape)
        
        # Calculate bottom midpoint
        bottom_point = self.find_bottom_point(door_boundaries)
        
        # Create visualization
        result_img = self.create_visualization(img, edges, door_lines, door_boundaries, bottom_point)
        
        return edges, door_boundaries, bottom_point, result_img

    def detect_entrance_boundaries2(self, img,od_msg,label_id):
        """
        Detect boundaries of an entrance door and find the bottom midpoint
        
        Args:
            image_path (str): Path to the door image
        
        Returns:
            tuple: (edges, door_boundaries, bottom_point, processed_image)
        """
        print("inside the enterance callback")
        # Read the image
        if img is None:
            raise ValueError(f"Could not load image from topic")

        self.height = img.shape[0]
        self.width = img.shape[1]

        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
        # Apply edge detection using Canny
        edges = cv2.Canny(blurred, 50, 150, apertureSize=3)
        # Detect door frame lines
        door_lines = self.detect_door_lines(edges)
        
        # Filter based on OD_msg
        door_line_filtered = self.valid_lines(door_lines, od_msg,label_id)

        # Find door boundaries
        door_boundaries = self.find_door_boundaries(door_line_filtered, img.shape)

        # Calculate bottom midpoint
        bottom_point = self.find_bottom_point(door_boundaries)
        
        # Add the pose to the object detection message
        if(bottom_point is not None):
            od_msg = self.update_bbox_pose(od_msg, bottom_point, label_id)

        # Create visualization
        result_img = self.create_visualization(img, edges, door_lines, door_boundaries, bottom_point)
        
        return edges, door_boundaries, bottom_point, od_msg, result_img

    def update_bbox_pose(self, od_msg, bottom_point, label_id):
        """
        Update the bounding box pose in the object detection message
        """
        if od_msg is None or len(od_msg.bboxes) == 0:
            return od_msg
        
        for bbox in od_msg.bboxes:
                if(bbox.id != label_id):  #### change to the new model id
                    continue
                print("taking up the array:" , np.array([min(max(bbox.x-(bbox.width//2)*self.bbox_tol,0),self.width), min(max(bbox.y-(bbox.height//2)*self.bbox_tol,0), self.height), min(max(bbox.x+(bbox.width//2)*self.bbox_tol,0),self.width), min(max(bbox.y+(bbox.height//2)*self.bbox_tol,0), self.height)]))
                i = np.array([min(max(bbox.x-(bbox.width//2)*self.bbox_tol,0),self.width), min(max(bbox.y-(bbox.height//2)*self.bbox_tol,0), self.height), min(max(bbox.x+(bbox.width//2)*self.bbox_tol,0),self.width), min(max(bbox.y+(bbox.height//2)*self.bbox_tol,0), self.height)])
                rect = np.array([[i[0], i[1]], [i[2], i[1]], [i[2], i[3]], [i[0], i[3]]])
                # print("rectable boundaries", rect)
                # print("bottom point", bottom_point)
                # if cv2.pointPolygonTest(rect.astype(int), (bottom_point[0],bottom_point[1]), False) == 1.0:
                bbox.pose_x = float(bottom_point[0])
                bbox.pose_y = float(bottom_point[1])

        return od_msg

    def valid_lines(self, lines, od_msg, label_id):
        vert_lines = lines['vertical']
        hor_lines = lines['horizontal']
        out_lines_vert = []
        out_lines_hor = []
        for line in vert_lines:
            x1, y1, x2, y2 = line['coords']
            xc = (x1+x2)/2
            yc = (y1+y2)/2

            for bbox in od_msg.bboxes:
                if(bbox.id != label_id):  #### change to the new model id
                    continue

                i = np.array([min(max(bbox.x-(bbox.width//2)*self.bbox_tol,0),self.width), min(max(bbox.y-(bbox.height//2)*self.bbox_tol,0), self.height), min(max(bbox.x+(bbox.width//2)*self.bbox_tol,0),self.width), min(max(bbox.y+(bbox.height//2)*self.bbox_tol,0), self.height)])
                rect = np.array([[i[0], i[1]], [i[2], i[1]], [i[2], i[3]], [i[0], i[3]]])
                # print(rect)
                if cv2.pointPolygonTest(rect.astype(int), (xc, yc), False) == 1.0:
                    out_lines_vert.append(line)
        
        for line in hor_lines:
            x1, y1, x2, y2 = line['coords']
            xc = (x1+x2)/2
            yc = (y1+y2)/2

            for bbox in od_msg.bboxes:
                if(bbox.id != label_id):
                    continue

                i = np.array([min(max(bbox.x-bbox.width//2, 0), self.width), min(max(bbox.y-bbox.height//2, 0), self.height), min(max(bbox.x+bbox.width//2, 0), self.width), min(max(bbox.y+bbox.height//2, 0), self.height)])
                rect = np.array([[i[0], i[1]], [i[2], i[1]], [i[2], i[3]], [i[0], i[3]]])
                # print(rect)
                if cv2.pointPolygonTest(rect.astype(int), (xc, yc), False) == 1.0:
                    out_lines_hor.append(line)

        return {'vertical': out_lines_vert, 'horizontal': out_lines_hor, 'all': out_lines_vert + out_lines_hor}

    def get_od_with_pose(self,img,od_msg, label_id=38):
        """
        Main function to process staircase image
        
        Args:
            image_path (str): Path to the staircase image
        """
        try:
            # Detect staircase edges and find midpoint
            edges, door_boundaries, bottom_point, od_msg, result_img = self.detect_entrance_boundaries2(img,od_msg,label_id)

            print(len(od_msg.bboxes))
            return od_msg
            
        except Exception as e:
            print(f"Error processing image: {e}")
            return None


    def multi_scale_edge_detection(self, gray_img):
        """
        Apply multi-scale edge detection for better door boundary detection
        """
        # Apply Gaussian blur with different scales
        blur1 = cv2.GaussianBlur(gray_img, (3, 3), 0)
        blur2 = cv2.GaussianBlur(gray_img, (5, 5), 0)
        blur3 = cv2.GaussianBlur(gray_img, (7, 7), 0)
        
        # Edge detection with different parameters
        edges1 = cv2.Canny(blur1, 30, 100, apertureSize=3)
        edges2 = cv2.Canny(blur2, 50, 150, apertureSize=3)
        edges3 = cv2.Canny(blur3, 70, 200, apertureSize=5)
        
        # Combine edges
        combined_edges = cv2.bitwise_or(edges1, edges2)
        combined_edges = cv2.bitwise_or(combined_edges, edges3)
        
        # Morphological operations to clean up
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        combined_edges = cv2.morphologyEx(combined_edges, cv2.MORPH_CLOSE, kernel)
        combined_edges = cv2.morphologyEx(combined_edges, cv2.MORPH_OPEN, kernel)
        
        return combined_edges
    
    def detect_door_lines(self, edges):
        """
        Detect door frame lines using Hough Transform and filtering
        """
        # Detect all lines
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=80, 
                               minLineLength=100, maxLineGap=20)
        
        if lines is None:
            return {'vertical': [], 'horizontal': [], 'all': []}
        
        # Classify lines
        vertical_lines = []
        horizontal_lines = []
        all_lines = []
        
        for line in lines:
            x1, y1, x2, y2 = line[0]
            
            # Calculate line properties
            length = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
            angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
            
            # Filter by length (door frames are typically long)
            if length < 50:
                continue
            
            all_lines.append({
                'coords': (x1, y1, x2, y2),
                'length': length,
                'angle': angle,
                'midpoint': ((x1 + x2) // 2, (y1 + y2) // 2)
            })
            
            # Classify as vertical or horizontal
            if abs(angle) < 15 or abs(angle) > 165:  # Horizontal lines
                horizontal_lines.append(all_lines[-1])
            elif 75 < abs(angle) < 105:  # Vertical lines
                vertical_lines.append(all_lines[-1])
        
        return {
            'vertical': vertical_lines,
            'horizontal': horizontal_lines,
            'all': all_lines
        }
    
    def find_door_boundaries(self, door_lines, img_shape):
        """
        Find door boundaries by analyzing line positions and relationships
        """
        height, width = img_shape[:2]
        vertical_lines = door_lines['vertical']
        horizontal_lines = door_lines['horizontal']
        
        boundaries = {
            'left_edge': None,
            'right_edge': None,
            'top_edge': None,
            'bottom_edge': None,
            'door_rect': None
        }
        
        if not vertical_lines:
            return boundaries
        
        # Find left and right door edges (vertical lines)
        # Sort vertical lines by x-coordinate
        vertical_lines.sort(key=lambda line: min(line['coords'][0], line['coords'][2]))
        
        # Use clustering to find main vertical edges
        if len(vertical_lines) >= 2:
            # Get x-coordinates of vertical lines
            x_coords = []
            for line in vertical_lines:
                x1, y1, x2, y2 = line['coords']
                x_coords.append(min(x1, x2))
            
            # Cluster x-coordinates to find left and right edges
            x_coords = np.array(x_coords).reshape(-1, 1)
            if len(x_coords) > 1:
                clustering = DBSCAN(eps=width*0.05, min_samples=1).fit(x_coords)
                labels = clustering.labels_
                
                unique_labels = list(set(labels))
                if len(unique_labels) >= 2:
                    # Find leftmost and rightmost clusters
                    cluster_centers = []
                    for label in unique_labels:
                        cluster_points = x_coords[labels == label]
                        center = np.mean(cluster_points)
                        cluster_centers.append((center, label))
                    
                    cluster_centers.sort()
                    left_label = cluster_centers[0][1]
                    right_label = cluster_centers[-1][1]
                    
                    # Get representative lines for left and right edges
                    left_lines = [vertical_lines[i] for i, label in enumerate(labels) if label == left_label]
                    right_lines = [vertical_lines[i] for i, label in enumerate(labels) if label == right_label]
                    
                    if left_lines:
                        # Choose the longest line as the left edge
                        boundaries['left_edge'] = max(left_lines, key=lambda x: x['length'])
                    
                    if right_lines:
                        # Choose the longest line as the right edge
                        boundaries['right_edge'] = max(right_lines, key=lambda x: x['length'])
        
        # Find top and bottom edges (horizontal lines)
        if horizontal_lines:
            # Sort by y-coordinate
            horizontal_lines.sort(key=lambda line: min(line['coords'][1], line['coords'][3]))
            
            # Find lines that span across the door width
            door_width = None
            if boundaries['left_edge'] and boundaries['right_edge']:
                left_x = boundaries['left_edge']['coords'][0]
                right_x = boundaries['right_edge']['coords'][0]
                door_width = abs(right_x - left_x)
            
            # Find top edge (usually the first horizontal line)
            for line in horizontal_lines:
                x1, y1, x2, y2 = line['coords']
                line_width = abs(x2 - x1)
                
                # Check if line spans reasonable width
                if door_width is None or line_width > door_width * 0.5:
                    boundaries['top_edge'] = line
                    break
            
            # Find bottom edge (usually near the bottom of the image)
            for line in reversed(horizontal_lines):
                x1, y1, x2, y2 = line['coords']
                line_width = abs(x2 - x1)
                avg_y = (y1 + y2) // 2
                
                # Check if line is in bottom half and spans reasonable width
                if avg_y > height * 0.6 and (door_width is None or line_width > door_width * 0.5):
                    boundaries['bottom_edge'] = line
                    break
        
        # Create door rectangle if we have enough boundaries
        if boundaries['left_edge'] and boundaries['right_edge']:
            left_x = boundaries['left_edge']['coords'][0]
            right_x = boundaries['right_edge']['coords'][0]
            
            top_y = boundaries['top_edge']['coords'][1] if boundaries['top_edge'] else 0
            bottom_y = boundaries['bottom_edge']['coords'][1] if boundaries['bottom_edge'] else height
            
            boundaries['door_rect'] = {
                'x': min(left_x, right_x),
                'y': top_y,
                'width': abs(right_x - left_x),
                'height': abs(bottom_y - top_y)
            }
        
        return boundaries
    
    def find_bottom_point(self, door_boundaries):
        """
        Find the bottom midpoint of the door
        """
        if not door_boundaries['left_edge'] and not door_boundaries['right_edge']:
            return None
        
        if not door_boundaries['left_edge']:
            right_line = door_boundaries['right_edge']['coords']
            right_bottom_y = max(right_line[1], right_line[3])
            right_x = right_line[0] if right_line[1] >= right_line[3] else right_line[2]
            return (right_x, right_bottom_y)
        
        if not door_boundaries['right_edge']:
            left_line = door_boundaries['left_edge']['coords']
            left_bottom_y = max(left_line[1], left_line[3])
            left_x = left_line[0] if left_line[1] >= left_line[3] else left_line[2]
            return (left_x, left_bottom_y)
        
        left_line = door_boundaries['left_edge']['coords']
        right_line = door_boundaries['right_edge']['coords']
        
        # Get bottom y-coordinates of vertical lines
        left_bottom_y = max(left_line[1], left_line[3])
        right_bottom_y = max(right_line[1], right_line[3])
        
        # Calculate midpoint
        left_x = left_line[0] if left_line[1] >= left_line[3] else left_line[2]
        right_x = right_line[0] if right_line[1] >= right_line[3] else right_line[2]
        
        mid_x = (left_x + right_x) // 2
        mid_y = max(left_bottom_y, right_bottom_y)
        
        # If we have a bottom edge, use its y-coordinate
        if door_boundaries['bottom_edge']:
            bottom_line = door_boundaries['bottom_edge']['coords']
            mid_y = max(bottom_line[1], bottom_line[3])
        
        return (mid_x, mid_y)
    
    def create_visualization(self, original_img, edges, door_lines, boundaries, bottom_point):
        """
        Create comprehensive visualization
        """
        result_img = original_img.copy()
        
        # Draw all detected lines
        for line in door_lines['all']:
            x1, y1, x2, y2 = line['coords']
            cv2.line(result_img, (x1, y1), (x2, y2), (128, 128, 128), 1)
        
        # Draw door boundaries with different colors
        if boundaries['left_edge']:
            coords = boundaries['left_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (0, 255, 0), 3)
            cv2.putText(result_img, "Left", (coords[0] - 30, coords[1]), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        if boundaries['right_edge']:
            coords = boundaries['right_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (255, 0, 0), 3)
            cv2.putText(result_img, "Right", (coords[0] + 10, coords[1]), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
        
        if boundaries['top_edge']:
            coords = boundaries['top_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (0, 255, 255), 3)
            cv2.putText(result_img, "Top", (coords[0], coords[1] - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        
        if boundaries['bottom_edge']:
            coords = boundaries['bottom_edge']['coords']
            cv2.line(result_img, (coords[0], coords[1]), (coords[2], coords[3]), (255, 255, 0), 3)
            cv2.putText(result_img, "Bottom", (coords[0], coords[1] + 20), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        
        # Draw door rectangle
        if boundaries['door_rect']:
            rect = boundaries['door_rect']
            cv2.rectangle(result_img, 
                         (rect['x'], rect['y']), 
                         (rect['x'] + rect['width'], rect['y'] + rect['height']), 
                         (255, 0, 255), 2)
        
        # Draw bottom midpoint
        if bottom_point:
            cv2.circle(result_img, bottom_point, 8, (0, 0, 255), -1)
            cv2.circle(result_img, bottom_point, 12, (255, 255, 255), 2)
            cv2.putText(result_img, f"Entry Point: ({bottom_point[0]}, {bottom_point[1]})", 
                       (bottom_point[0] - 80, bottom_point[1] - 20),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        
        return result_img
    
    def analyze_door_structure(self, door_boundaries, img_shape):
        """
        Analyze door structure and provide measurements
        """
        height, width = img_shape[:2]
        
        analysis = {
            'door_detected': False,
            'door_width_pixels': 0,
            'door_height_pixels': 0,
            'door_center': None,
            'door_area_ratio': 0,
            'confidence_score': 0
        }
        
        if door_boundaries['door_rect']:
            rect = door_boundaries['door_rect']
            analysis['door_detected'] = True
            analysis['door_width_pixels'] = rect['width']
            analysis['door_height_pixels'] = rect['height']
            analysis['door_center'] = (rect['x'] + rect['width']//2, rect['y'] + rect['height']//2)
            analysis['door_area_ratio'] = (rect['width'] * rect['height']) / (width * height)
            
            # Calculate confidence based on detected components
            confidence = 0
            if door_boundaries['left_edge']: confidence += 25
            if door_boundaries['right_edge']: confidence += 25
            if door_boundaries['top_edge']: confidence += 25
            if door_boundaries['bottom_edge']: confidence += 25
            
            analysis['confidence_score'] = confidence
        
        return analysis

def visualize_results(original_img, edges, result_img, analysis):
    """
    Create comprehensive visualization plots
    """
    plt.figure(figsize=(15, 10))
    
    # Original image
    plt.subplot(2, 3, 1)
    plt.imshow(cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB))
    plt.title('Original Door Image')
    plt.axis('off')
    
    # Edge detection
    plt.subplot(2, 3, 2)
    plt.imshow(edges, cmap='gray')
    plt.title('Multi-Scale Edge Detection')
    plt.axis('off')
    
    # Final result
    plt.subplot(2, 3, 3)
    plt.imshow(cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB))
    plt.title('Door Boundary Detection')
    plt.axis('off')
    
    # Analysis visualization
    plt.subplot(2, 3, 4)
    if analysis['door_detected']:
        labels = ['Width', 'Height']
        values = [analysis['door_width_pixels'], analysis['door_height_pixels']]
        plt.bar(labels, values, color=['blue', 'green'])
        plt.title('Door Dimensions (pixels)')
        plt.ylabel('Pixels')
    else:
        plt.text(0.5, 0.5, 'No Door\nDetected', ha='center', va='center', 
                transform=plt.gca().transAxes, fontsize=16)
        plt.title('Door Dimensions')
    
    # Confidence and metrics
    plt.subplot(2, 3, 5)
    metrics = ['Confidence', 'Area Ratio']
    values = [analysis['confidence_score'], analysis['door_area_ratio'] * 100]
    colors = ['red' if analysis['confidence_score'] < 50 else 'green', 'orange']
    plt.bar(metrics, values, color=colors)
    plt.title('Detection Metrics')
    plt.ylabel('Score / Percentage')
    
    # Summary text
    plt.subplot(2, 3, 6)
    summary_text = f"""Door Detection Summary:
    
Status: {'✓ Detected' if analysis['door_detected'] else '✗ Not Found'}
Confidence: {analysis['confidence_score']}%
Width: {analysis['door_width_pixels']} px
Height: {analysis['door_height_pixels']} px
Area Ratio: {analysis['door_area_ratio']:.3f}
"""
    if analysis['door_center']:
        summary_text += f"Center: ({analysis['door_center'][0]}, {analysis['door_center'][1]})"
    
    plt.text(0.1, 0.9, summary_text, transform=plt.gca().transAxes, 
             fontsize=10, verticalalignment='top', fontfamily='monospace')
    plt.axis('off')
    plt.title('Analysis Summary')
    
    plt.tight_layout()
    plt.show()

def main(image_path):
    """
    Main function to process door image
    """
    detector = EnteranceDetector()
    
    try:
        # Load original image
        original_img = cv2.imread(image_path)
        if original_img is None:
            print(f"Error: Could not load image from {image_path}")
            return

        print("Processing entrance image...")

        # Detect entrance boundaries
        edges, boundaries, bottom_point, result_img = detector.detect_entrance_boundaries(image_path)
        
        # Analyze door structure
        analysis = detector.analyze_door_structure(boundaries, original_img.shape)
        
        # Display results
        print(f"\n=== Door Detection Results ===")
        print(f"Door detected: {analysis['door_detected']}")
        print(f"Confidence: {analysis['confidence_score']}%")
        
        if bottom_point:
            print(f"Bottom midpoint: ({bottom_point[0]}, {bottom_point[1]})")
        else:
            print("Bottom midpoint: Not found")
        
        print(f"Door dimensions: {analysis['door_width_pixels']} x {analysis['door_height_pixels']} pixels")
        print(f"Door area ratio: {analysis['door_area_ratio']:.3f}")
        
        # Boundary detection details
        print(f"\n=== Boundary Detection Details ===")
        print(f"Left edge: {'✓' if boundaries['left_edge'] else '✗'}")
        print(f"Right edge: {'✓' if boundaries['right_edge'] else '✗'}")
        print(f"Top edge: {'✓' if boundaries['top_edge'] else '✗'}")
        print(f"Bottom edge: {'✓' if boundaries['bottom_edge'] else '✗'}")
        
        # Visualize results
        visualize_results(original_img, edges, result_img, analysis)
        
        # Save result
        cv2.imwrite("door_detection_result.jpg", result_img)
        print("\nResult saved as 'door_detection_result.jpg'")
        
        return edges, boundaries, bottom_point, analysis
        
    except Exception as e:
        print(f"Error processing image: {e}")
        return None, None, None, None   
    
# Example usage
if __name__ == "__main__":
    # Replace with your door image path
    image_path = "door_image2.jpg"
    
    # Process the image
    edges, boundaries, midpoint, analysis = main(image_path)
    
    if boundaries:
        print("\nProcessing completed successfully!")
    else:
        print("Processing failed!")